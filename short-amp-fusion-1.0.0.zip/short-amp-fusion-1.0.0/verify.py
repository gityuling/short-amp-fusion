"""Replay fixed-seed test F1, its paired interval, and the published case checks."""
import csv
import gzip
import hashlib
import json
from pathlib import Path
import sys

import numpy as np

ROOT = Path(__file__).resolve().parent
REF = ROOT / "reference"
SEEDS = (42, 43, 44)


def read_table(name):
    with (REF / name).open() as handle:
        return list(csv.DictReader(handle))


def test_scores():
    with gzip.open(REF / "test_scores.csv.gz", "rt") as handle:
        rows = list(csv.DictReader(handle))
    labels = np.array([int(r["label"]) for r in rows])
    clusters = np.array([int(r["cluster"]) for r in rows])
    assert len(rows) == 1400 and labels.sum() == 402
    names = ("fusion", "ppsamp", "deep_ampep30", "macrel", "rf_ampep30", "protbert_descriptors")
    counts = {}
    means = {}
    for name in names:
        calls = np.array([[float(row[f"{name}_{seed}"]) > 0.5 for row in rows] for seed in SEEDS]).T
        tp = calls * labels[:, None]
        denominator = calls + labels[:, None]
        counts[name] = (2 * tp, denominator)
        means[name] = (2 * tp.sum(axis=0) / denominator.sum(axis=0)).mean()
        print(f"{name:24s} mean F1 = {100*means[name]:.4f}%")
    expected_names = {"deep_ampep30_reimplementation": "deep_ampep30",
                      "rf_ampep30_reimplementation": "rf_ampep30", "macrel_retrained": "macrel"}
    for row in read_table("S17_primary_five_models_summary.csv"):
        key = expected_names.get(row["model"], row["model"])
        np.testing.assert_allclose(means[key], float(row["f1_mean"]), atol=1e-12)
    groups, index = np.unique(clusters, return_inverse=True)
    terms = np.column_stack((*counts["fusion"], *counts["ppsamp"]))
    grouped = np.zeros((len(groups), terms.shape[1]), dtype=int)
    np.add.at(grouped, index, terms)
    tag = b"original_ppsamp|ours_minus_ppsamp|cluster"
    rng = np.random.default_rng(int.from_bytes(hashlib.sha256(tag).digest()[:8], "little"))
    diffs = []
    for start in range(0, 10000, 96):
        weights = rng.multinomial(len(groups), np.full(len(groups), 1 / len(groups)), size=min(96, 10000-start))
        a, b, c, d = np.split(weights @ grouped, 4, axis=1)
        diffs.extend(np.mean(a / b - c / d, axis=1))
    interval = np.percentile(diffs, [2.5, 97.5])
    expected = next(r for r in read_table("S02_primary_paired_intervals.csv")
                    if r["study"] == "original_ppsamp" and r["metric"] == "f1" and r["resampling"] == "cluster")
    np.testing.assert_allclose(interval, [float(expected["delta_ci_low"]), float(expected["delta_ci_high"])], atol=1e-12)
    print(f"Fusion minus PPsAMP = {100*(means['fusion']-means['ppsamp']):.4f} pp "
          f"(95% paired cluster interval {100*interval[0]:.4f} to {100*interval[1]:.4f})")
    print(f"Fusion minus ProtBERT + descriptors = {100*(means['fusion']-means['protbert_descriptors']):.4f} pp")


def case_checks():
    sys.path.insert(0, str(ROOT / "manuscript_experiments/external_explanations_v2"))
    from agent import validate
    with gzip.open(REF / "case_checks.json.gz", "rt") as handle:
        cases = json.load(handle)
    for case in cases:
        errors = validate(case["report"], case["evidence"])
        if errors:
            raise ValueError((case["case_id"], errors))
    summaries = read_table("S10_case_summary.csv")
    changed = sum(int(row["shuffle_flips"]) > 0 for row in summaries)
    assert len(cases) == len(summaries) == 12 and changed == 7
    print(f"{len(cases)} agent reports passed the archived structured fact checks. "
          f"At least one shuffle changed the assigned class in {changed}/{len(summaries)} cases. "
          "See S11 for the separate human semantic review.")


if __name__ == "__main__":
    test_scores()
    case_checks()
