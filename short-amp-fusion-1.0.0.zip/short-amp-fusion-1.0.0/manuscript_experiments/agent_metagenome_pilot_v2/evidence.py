"""Bounded, provenance-preserving checks on existing AMPSphere candidates."""
from __future__ import annotations
import csv
import datetime as dt
import hashlib
import json
from pathlib import Path
import urllib.request
import xml.etree.ElementTree as ET

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
DATA = ROOT / 'manuscript_experiments/data/metagenomic'
RESULTS = ROOT / 'manuscript_experiments/results/metagenomic'
API = 'https://ampsphere-api.big-data-biology.org/v1'
QUALITY = ['Antifam', 'RNAcode', 'metaproteomes', 'metatranscriptomes', 'coordinates']


def write(path, obj):
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + '.tmp')
    tmp.write_text(json.dumps(obj, ensure_ascii=False, indent=2, allow_nan=False) + '\n')
    tmp.replace(path)


def sha(path):
    h = hashlib.sha256()
    with path.open('rb') as f:
        for block in iter(lambda: f.read(8 << 20), b''):
            h.update(block)
    return h.hexdigest()


def rows(path):
    with path.open(newline='') as f:
        return list(csv.DictReader(f))


def fetch(url, path, kind='json'):
    if path.exists():
        cached = json.loads(path.read_text())
        assert cached['url'] == url
        if 'error' in cached:
            raise RuntimeError('Prior request failed; retained without silent retry: ' + cached['error'])
        return cached['response']
    record = {'url': url, 'retrieved_utc': dt.datetime.now(dt.timezone.utc).isoformat()}
    try:
        with urllib.request.urlopen(url, timeout=25) as response:
            raw = response.read(5_000_001)
        if len(raw) > 5_000_000:
            raise ValueError('Bounded response limit exceeded')
        value = json.loads(raw) if kind == 'json' else raw.decode()
        record.update(response=value, response_sha256=hashlib.sha256(raw).hexdigest())
        write(path, record)
        return value
    except Exception as exc:
        record['error'] = f'{type(exc).__name__}: {exc}'
        write(path, record)
        raise


def coding_match(dna, peptide):
    """Table 11, frame 0, both strands; allow documented Macrel initiator removal."""
    from Bio.Seq import Seq
    from Bio.Data import CodonTable
    dna = str(dna).upper()
    if not dna or set(dna) - set('ACGT') or len(dna) % 3:
        return {'match': False, 'status': 'not_evaluable', 'reason': 'ambiguous_or_non_triplet_DNA'}
    table = CodonTable.unambiguous_dna_by_id[11]
    for strand, seq in [('+', dna), ('-', str(Seq(dna).reverse_complement()))]:
        translated = str(Seq(seq).translate(table=11))
        complete = seq[:3] in table.start_codons and seq[-3:] in table.stop_codons
        if not complete or '*' in translated[:-1]:
            continue
        translated = 'M' + translated[1:-1]
        for mode, protein in [('complete_translation', translated),
                              ('Macrel_initiator_M_removed', translated[1:])]:
            if protein == peptide:
                return {'match': True, 'status': 'matched', 'strand': strand, 'mode': mode}
    return {'match': False, 'status': 'no_match_under_table11',
            'reason': 'No complete exact match in checked orientations; alternative genetic codes or source errors remain possible.'}


