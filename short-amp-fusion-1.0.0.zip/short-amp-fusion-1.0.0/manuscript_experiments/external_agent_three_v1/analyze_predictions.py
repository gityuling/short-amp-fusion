"""Within-study metrics and paired sequence bootstrap. No tuning or pooled ranking."""
from pathlib import Path
import json,warnings
import numpy as np,pandas as pd
from sklearn.metrics import roc_auc_score,average_precision_score
HERE=Path(__file__).resolve().parent; OUT=HERE/'analysis';OUT.mkdir(exist_ok=True)
def metrics(y,p):
    pred=p>=.5;tp=int(((y==1)&pred).sum());tn=int(((y==0)&~pred).sum());fp=int(((y==0)&pred).sum());fn=int(((y==1)&~pred).sum())
    div=lambda a,b:a/b if b else float('nan')
    mccden=((tp+fp)*(tp+fn)*(tn+fp)*(tn+fn))**.5
    return {'n':len(y),'positive_n':int(y.sum()),'TP':tp,'TN':tn,'FP':fp,'FN':fn,'accuracy':(tp+tn)/len(y),
        'precision':div(tp,tp+fp),'recall':div(tp,tp+fn),'specificity':div(tn,tn+fp),
        'f1':div(2*tp,2*tp+fp+fn),'mcc':(tp*tn-fp*fn)/mccden if mccden else 0.,
        'auroc':roc_auc_score(y,p) if len(set(y))==2 else float('nan'),
        'average_precision':average_precision_score(y,p) if y.sum() else float('nan')}
def wilson(k,n):
    if not n:return [None,None]
    z=1.95996398454;p=k/n;den=1+z*z/n;c=(p+z*z/(2*n))/den;h=z*((p*(1-p)/n+z*z/(4*n*n))**.5)/den
    return [c-h,c+h]
def main():
    f=pd.read_csv(HERE/'predictions/all_predictions.csv');rows=[];ci=[];diff=[]
    keys=['f1','auroc','mcc','recall','specificity','average_precision','accuracy','precision']
    for cohort in ['SEP','Archaeasin','APEX']:
        g=f[f.cohort==cohort];y=g.Label.to_numpy();p=g.fusion_mean.to_numpy();q=g.ppsamp_mean.to_numpy()
        for model,col in [('fusion','fusion_mean'),('ppsamp','ppsamp_mean'),('all_positive',None)]:
            m=metrics(y,g[col].to_numpy() if col else np.ones(len(y)));rows.append({'cohort':cohort,'model':model,'estimate':'mean_seed_score',**m})
            for metric,k,n in [('recall',m['TP'],m['TP']+m['FN']),('specificity',m['TN'],m['TN']+m['FP']),('precision',m['TP'],m['TP']+m['FP'])]:
                l,h=wilson(k,n);ci.append({'cohort':cohort,'model':model,'metric':metric,'estimate':m[metric],'low':l,'high':h,'method':'Wilson 95%'})
        for model in ['fusion','ppsamp']:
            for seed in [42,43,44]:rows.append({'cohort':cohort,'model':model,'estimate':f'seed_{seed}',**metrics(y,g[f'{model}_{seed}'].to_numpy())})
        rng=np.random.default_rng(20261115);boot={k:[] for k in keys};modelboot={m:{k:[] for k in keys} for m in ['fusion','ppsamp']}
        for _ in range(2000):
            ix=rng.integers(0,len(y),len(y));a=metrics(y[ix],p[ix]);b=metrics(y[ix],q[ix])
            for k in keys:
                if np.isfinite(a[k]):modelboot['fusion'][k].append(a[k])
                if np.isfinite(b[k]):modelboot['ppsamp'][k].append(b[k])
                if np.isfinite(a[k]) and np.isfinite(b[k]):boot[k].append(a[k]-b[k])
        a,b=metrics(y,p),metrics(y,q)
        for k in keys:
            lo,hi=np.quantile(boot[k],[.025,.975]);diff.append({'cohort':cohort,'metric':k,'fusion_minus_ppsamp':a[k]-b[k],'low':lo,'high':hi,'valid_resamples':len(boot[k]),'requested_resamples':2000})
            for model in ['fusion','ppsamp']:
                lo,hi=np.quantile(modelboot[model][k],[.025,.975]);ci.append({'cohort':cohort,'model':model,'metric':k,'estimate':(a if model=='fusion' else b)[k],'low':lo,'high':hi,'method':'Paired ordinary sequence bootstrap percentile 95%; undefined resamples omitted'})
    pd.DataFrame(rows).to_csv(OUT/'metrics.csv',index=False);pd.DataFrame(ci).to_csv(OUT/'confidence_intervals.csv',index=False);pd.DataFrame(diff).to_csv(OUT/'paired_differences.csv',index=False)
    (OUT/'statistics_notes.txt').write_text('Threshold 0.5 fixed. Ensemble = arithmetic mean of three frozen seed scores. Seed variability is recorded separately, not treated as independent experimental peptides. Ordinary paired sequence bootstrap N=2000, seed=20261115 within each cohort; metrics undefined for one-class resamples are omitted and effective counts reported. Intervals reflect peptide sampling conditional on this predictor-enriched cohort and frozen models; not assay variability or pretraining exposure. MCC zero denominator follows conventional 0 reporting. No aggregate ranking across incompatible assay cutoffs. Archaeasin has only 4 non-active short peptides: specificity and AUROC are especially uncertain.\n')
    print(pd.DataFrame(rows).query("estimate=='mean_seed_score'")[['cohort','model','n','TP','TN','FP','FN','f1','auroc','mcc','recall','specificity']].to_string(index=False))
if __name__=='__main__':main()
