"""Frozen two-model inference only; neither labels nor new sequences fit any transform."""
import os
os.environ.setdefault('OMP_NUM_THREADS','4');os.environ.setdefault('OPENBLAS_NUM_THREADS','4')
from pathlib import Path
import sys,hashlib,json,datetime,random
HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[1]
sys.path.insert(0,str(ROOT/'manuscript_experiments/scripts'))
from external_inference import *
OUT=HERE/'predictions';OUT.mkdir(exist_ok=True)
def main():
    setup();torch.set_num_threads(4);ensure_parity()
    f=pd.read_csv(HERE/'data/eligible_candidates.csv')
    assert f.Sequence.str.len().between(11,30).all()
    assert all(set(s)<=set('ACDEFGHIKLMNPQRSTVWY') for s in f.Sequence)
    cfg=next(x for x in CFG['variants'] if x['name']=='dual64_phys')
    paths=[BASE/'results/core/dual64_phys/transforms.joblib']
    paths += [BASE/f'results/core/dual64_phys/seed_{s}/model.joblib' for s in [42,43,44]]
    paths += [ROOT/f'reproduction/results/official_seed_{s}/best_model.pt' for s in [42,43,44]]
    manifest={'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'threshold':.5,'seeds':[42,43,44],
        'variant':cfg,'fitting_performed':False,
        'frozen_model_hashes':{str(p.relative_to(ROOT)):sha256(p) for p in paths},
        'inputs':{str(p.relative_to(HERE)):sha256(p) for p in [HERE/'data/eligible_candidates.csv',HERE/'PREANALYSIS.json',HERE/'AVAILABILITY_AMENDMENT.txt',Path(__file__)]},
        'extractor':sha256(Path(sys.modules['external_inference'].__file__))}
    old=OUT/'frozen_manifest.json'
    if old.exists():
        prev=json.loads(old.read_text());assert prev['inputs']==manifest['inputs'] and prev['frozen_model_hashes']==manifest['frozen_model_hashes']
    else:write_json(old,manifest)
    raw=extract(f.Sequence,HERE/'embeddings')
    with threadpool_limits(limits=4):xx=transform(raw,joblib.load(paths[0]),cfg)
    for seed in [42,43,44]:
        with threadpool_limits(limits=4):p=joblib.load(BASE/f'results/core/dual64_phys/seed_{seed}/model.joblib').predict_proba(xx)[:,1]
        f[f'fusion_{seed}']=p
    pse=torch.tensor(np.asarray([compute_pseaac(s) for s in f.Sequence],dtype='float32'))
    head=TokenCrossAttentionModel(**{k:CONFIG[k] for k in ['embedding_dim','num_heads','num_layers','dropout']}).eval()
    for seed in [42,43,44]:
        head.load_state_dict(torch.load(ROOT/f'reproduction/results/official_seed_{seed}/best_model.pt',weights_only=True,map_location='cpu'));pp=[]
        with torch.no_grad():
            for i in range(0,len(f),64):pp.extend(head(pse[i:i+64],torch.from_numpy(raw['tokens'][i:i+64]),torch.from_numpy(raw['masks'][i:i+64])).softmax(-1)[:,1].numpy())
        f[f'ppsamp_{seed}']=pp
    for m in ['fusion','ppsamp']:f[m+'_mean']=f[[m+'_'+str(s) for s in [42,43,44]]].mean(axis=1)
    f.to_csv(OUT/'all_predictions.csv',index=False)
    rng=random.Random(20261115);cases=[]
    # Activity outcomes are explicitly omitted before selection and never consulted.
    for cohort in ['SEP','Archaeasin','APEX']:
        subset=f[f.cohort==cohort].copy().sort_values('id')
        subset['stratum']=[('both_positive' if a and b else 'both_negative' if not a and not b else 'fusion_only' if a else 'baseline_only') for a,b in zip(subset.fusion_mean>=.5,subset.ppsamp_mean>=.5)]
        selected=[]
        for st in ['both_positive','both_negative','fusion_only','baseline_only']:
            group=subset[subset.stratum==st].id.tolist()
            if group:selected.append(rng.choice(group))
        remaining=sorted(set(subset.id)-set(selected))
        selected+=rng.sample(remaining,min(4-len(selected),len(remaining)))
        for uid in selected:
            r=subset.set_index('id').loc[uid]
            cases.append({'case_id':f'C{len(cases)+1:02}','id':uid,'cohort':cohort,'Sequence':r.Sequence,'selection_stratum':r.stratum,
                'scores':{m:[float(r[f'{m}_{s}']) for s in [42,43,44]] for m in ['fusion','ppsamp']},
                'overlaps':{k:bool(r[k]) for k in ['exact_train','exact_val','exact_test','previous_BATTLE_overlap','prior_61_overlap','between_cohort_overlap']}})
    write_json(HERE/'data/agent_cases_LOCAL.json',{'seed':20261115,'selection_uses_labels':False,'cases':cases})
    assert all(sha256(ROOT/p)==h for p,h in manifest['frozen_model_hashes'].items())
    print('Completed frozen inference',len(f), 'and selected cases',len(cases),flush=True)
if __name__=='__main__':main()
