"""Re-evaluate frozen fusion scores at two MIC endpoints, per external cohort."""
from pathlib import Path
import csv
import json
import math
import re

import numpy as np
from PIL import Image
from sklearn.metrics import roc_auc_score

OUT = Path(__file__).resolve().parent
RUN = OUT.parent
SOURCES = RUN / "sources"
SEP_SOURCES = SOURCES / "sep_supplements"
MANUSCRIPT = RUN.parents[1] / "JCIM_AMP_manuscript"


def read_rows(path):
    with path.open() as f:
        return list(csv.DictReader(f))


def save_rows(name, rows):
    with (OUT / name).open("w") as f:
        writer = csv.DictWriter(f, fieldnames=rows[0])
        writer.writeheader()
        writer.writerows(rows)


def read_sep_figure():
    # Figure 3A and Table S2 have the same 55 names in the same order.
    # Duplicate display names require the row position as well as the name.
    table = (SEP_SOURCES / "NIHMS2131923-supplement-Supplementary_tables.txt").read_text()
    ids = re.findall(r"^\s*(\d{6})\s+\S+\s+[ACDEFGHIKLMNPQRSTVWY]+\s+\d+\s", table, re.M)
    assert len(ids) == len(set(ids)) == 55
    # Visually transcribed row numbers for rows whose smallest printed MIC is 128.
    only_128 = {4, 10, 15, 24, 25, 39, 47}
    # Independent colour cross-check for every row against the source image.
    image = np.array(Image.open(SEP_SOURCES / "nihms-2131923-f0004.jpg"))
    assert image.shape == (1295, 1800, 3)
    columns = np.rint(np.r_[np.linspace(181, 440, 11), np.linspace(469, 780, 13)]).astype(int)
    labels = {}
    for i, source_id in enumerate(ids):
        y = 281 + 17 * i + int(i >= 26)
        positive_64 = False
        for x in columns:
            pixels = image[y-6:y+7, x-10:x+11].reshape(-1, 3)
            red, _, blue = np.median(pixels, axis=0)
            # White and red cells correspond to MIC <=64 on this figure's legend.
            positive_64 |= red > 110 and red >= blue - 18
        assert bool(positive_64) == (i + 1 not in only_128)
        labels[source_id] = (int(positive_64), i + 1)
    return labels


def score_auc(rows, cutoff):
    known = [r for r in rows if r[f"label_{cutoff}"] is not None]
    y = [r[f"label_{cutoff}"] for r in known]
    if len(set(y)) < 2:
        return None
    return float(roc_auc_score(y, [r["fusion_mean"] for r in known]))


def summarize(cohort, rows, scope):
    paired = [r for r in rows if r["label_128"] is not None and r["label_64"] is not None]
    summary = dict(cohort=cohort, scope=scope, n=len(rows), paired_n=len(paired))
    for t in (64, 128):
        labels = [r[f"label_{t}"] for r in rows]
        for name, value in (("positive", 1), ("negative", 0), ("unknown", None)):
            summary[f"{name}_{t}"] = labels.count(value)
        summary[f"auc_{t}"] = score_auc(rows, t)
        summary[f"paired_auc_{t}"] = score_auc(paired, t)
    summary["known_label_flips"] = sum(r["label_64"] != r["label_128"] for r in paired)
    a, b = summary["paired_auc_64"], summary["paired_auc_128"]
    summary["paired_delta_128_minus_64_pp"] = 100 * (b - a) if a is not None and b is not None else None
    return summary


def main():
    sep = read_sep_figure()
    assays = {r["id"]: r for r in json.loads((RUN / "data/experimental_outcomes_HIDDEN_FROM_AGENT.json").read_text())}
    predictions = read_rows(RUN / "predictions/all_predictions.csv")
    eligible = {r["id"] for r in read_rows(RUN / "data/eligible_candidates.csv")}
    assert len(eligible) == len(predictions) == 212 and {r["id"] for r in predictions} == eligible
    records = []
    for p in predictions:
        cohort, uid = p["cohort"], p["id"]
        assay = assays[uid]
        original = int(p["Label"])
        score = float(p["fusion_mean"])
        assert assay["label"] == original and math.isclose(score, np.mean([float(p[f"fusion_{s}"]) for s in (42, 43, 44)]), abs_tol=1e-7)
        if cohort == "SEP":
            at128 = int(p["source_id"] in sep)
            at64, figure_row = sep.get(p["source_id"], (0, None))
            evidence = f"Fig 3A row {figure_row}, Table S2 order" if at128 else "Original Fig S3D inactive roster"
            if uid == "SEP__434399":
                evidence += "; unresolved S3B/S3D identifier, see exclusion sensitivity"
        else:
            raw = assay["mic_uM_raw"]
            assert len(raw) == 11
            measured = [v for v in raw.values() if isinstance(v, (int, float))]
            at64 = int(any(v <= 64 for v in measured))
            if cohort == "Archaeasin":
                assert all(v is None or v in measured for v in raw.values())
                at128 = 1 if at64 else None
                evidence = "Fig 2a, assay ceiling 64 uM"
            else:
                assert cohort == "APEX" and all(v == "N.A." or v in measured for v in raw.values())
                at128 = original  # Explicit Active/Inactive per Supplementary Dataset 2.
                assert at128 == int(any(v <= 128 for v in measured))
                assert not at128 or at64  # Every original active has numeric support at <=64.
                evidence = "Supplementary Dataset 2, numeric MIC and study activity label"
        assert original == (at64 if cohort == "Archaeasin" else at128)
        assert at128 is None or at64 <= at128
        records.append(dict(id=uid, cohort=cohort, fusion_mean=score, original_label=original,
                            label_64=at64, label_128=at128, evidence=evidence))
    summaries = []
    published = {r["cohort"]: float(r["auroc"]) for r in read_rows(MANUSCRIPT / "supplementary_tables/S14_experimental_panels.csv") if r["model"] == "fusion"}
    for cohort in ("SEP", "Archaeasin", "APEX"):
        rows = [r for r in records if r["cohort"] == cohort]
        result = summarize(cohort, rows, "original cohort")
        original_threshold = 64 if cohort == "Archaeasin" else 128
        assert math.isclose(result[f"auc_{original_threshold}"], published[cohort])
        summaries.append(result)
        if cohort == "SEP":
            summaries.append(summarize(cohort, [r for r in rows if r["id"] != "SEP__434399"], "exclude unresolved identifier"))
    save_rows("per_peptide.csv", records)
    save_rows("summary.csv", summaries)


if __name__ == "__main__":
    main()
