"""Parse primary data. Run with bundled Python (openpyxl); no ML or LLM calls."""
from pathlib import Path
import csv,json,re,hashlib,collections,datetime
import openpyxl
HERE=Path(__file__).resolve().parent; ROOT=HERE.parents[1]; SRC=HERE/'sources'
DATA=HERE/'data'; DATA.mkdir(exist_ok=True)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,d):p.write_text(json.dumps(d,ensure_ascii=False,indent=2,allow_nan=False)+'\n')
def xrows(name,sheet=None):
    w=openpyxl.load_workbook(SRC/name,read_only=True,data_only=True)
    return list((w[sheet] if sheet else w.active).values)
def clean(v):return None if v in [None,'NA','N.A.','None',''] else v
def csvrows(p):return list(csv.DictReader(p.open()))
def main():
    records=[]; evidence={}; assays=[]
    def add(cohort,pid,seq,label,provenance):
        uid=cohort+'__'+pid
        assert uid not in evidence
        assert isinstance(seq,str) and seq==seq.strip().upper()
        records.append({'id':uid,'cohort':cohort,'source_id':pid,'Sequence':seq,'Label':label,'length':len(seq)})
        evidence[uid]=provenance
    # Explicit manual transcription of Fig S3D only. Panel B's legend also contains
    # active controls, so it is deliberately not used to assign inactive labels.
    inactive='415377 420250 420865 425834 426244 426915 429920 436573 422005 429488 440354 209001 426360 427421 429789 430432 434399 436020 439751 443019 443740 426383 420019'.split()
    table=(SRC/'sep_supplements/NIHMS2131923-supplement-Supplementary_tables.txt').read_text()
    pos=re.findall(r'^\s*(\d{6})\s+(\S+)\s+([ACDEFGHIKLMNPQRSTVWY]+)\s+(\d+)\s',table,re.M)
    assert len(pos)==55 and len(inactive)==23 and not set(inactive)&{r[0] for r in pos}
    raw={str(r[0]):r for r in xrows('sep_DataS1.xlsx','Data S1a')[2:] if r[0] is not None}
    ribo={str(r[0]):r for r in xrows('sep_DataS1.xlsx','Data S1c')[2:] if r[0] is not None}
    for pid,name,seq,n in pos:assert raw[pid][6]==seq and len(seq)==int(n)
    for pid,label in [(r[0],1) for r in pos]+[(x,0) for x in inactive]:
        r=raw[pid]; q=ribo.get(pid)
        # No activity labels, names, AmPEP scores or 'Tested?' text in agent evidence.
        pr={'kind':'metagenomic_smORF','paper_doi':'10.1016/j.cell.2024.07.027',
            'source_table':'Data S1a, row '+str(next(i+1 for i,x in enumerate(xrows('sep_DataS1.xlsx','Data S1a')) if str(x[0])==pid)),
            'source_id':pid,'source_organism_reported':clean(r[15]),'body_sites':r[8],
            'family_members':r[1],'smorfinder_positive':r[9],
            'sample_accessions':re.findall(r'(?:SRS|ERS|DRS)\d+',str(r[4])),
            'dna':r[7], 'rna_rpkm':clean(q[4]) if q else None,
            'riboseq_rpkm':clean(q[5]) if q else None,
            'expression_table_present':bool(q),'expression_note':'Data S1c catalog evidence; absence is not evidence of non-expression.',
            'chemistry':'Fmoc synthetic peptide; terminal chemistry not resolved from retrieved tables.'}
        add('SEP',pid,r[6],label,pr)
        assays.append({'id':'SEP__'+pid,'label':label,'label_source':'Table S2 active list' if label else 'Supplement Fig S3D inactive list, PDF page 5 (visually checked)',
                       'endpoint':'Activity against at least one tested pathogen or commensal, reported MIC <=128 uM',
                       'strain_values_available_here':False})
    source={r['']:r for r in csvrows(SRC/'archaeasin_data2.csv')}
    seqs={r[2].lower():r[3] for r in xrows('archaeasin_fig1.xlsx','Fig 1b')[1:] if r[1]=='Validated archaeasins'}
    mic=xrows('archaeasin_fig2.xlsx','Fig 2a'); colors=xrows('archaeasin_fig2.xlsx','Fig 2b')[1:]
    assert len(seqs)==80 and len(mic)==81 and len(colors)==80
    assert sum(c[6]=='#d73027' for c in colors)==75
    for row in mic[1:]:
        pid=row[0].lower(); seq=seqs[pid]; src=source[seq]
        label=int(any(isinstance(x,(int,float)) and x<=64 for x in row[1:]))
        acc=src['ProteinInfo'].split('|')[1]
        add('Archaeasin',pid,seq,label,{'kind':'protein_fragment','paper_doi':'10.1038/s41564-025-02061-0',
            'source_table':'Source Data Fig 1b (sequence/name) and Supplementary Data 2 (exact-sequence source join)',
            'source_id':src['ID'],'parent_accession':acc,'parent_database':'UniProt',
            'source_organism_reported':src['Source'],'parent_annotation_reported':src['ProteinInfo'],
            'chemistry':'Fmoc synthetic peptide; terminal chemistry not resolved from retrieved tables.',
            'expression_note':'Protein substring mining. No candidate-specific natural cleavage or expression evidence supplied.'})
        assays.append({'id':'Archaeasin__'+pid,'label':label,'endpoint':'Any MIC <=64 uM among 11 tested pathogens',
            'label_source':'Fig 2a: at least one reported MIC <=64; all 80 are tested according to paper; 75/5 totals cross-checked with Fig 2b colours. Fig 2b row order is not assumed.',
            'mic_uM_raw':dict(zip(mic[0][1:],row[1:])),
            'censoring_note':'Blank source cells preserved as null, not imputed. All-blank rows mean no MIC reported within the tested 1–64 uM range. Colour totals and published count agree; colour rows cannot individually be mapped to Fig 2a.'})
    assert sum(r['Label'] for r in records if r['cohort']=='Archaeasin')==75
    apex=xrows('apex_dataset2.xlsx'); assert len(apex[2:])==69
    for i,row in enumerate(apex[2:],start=3):
        assert row[16] in ['Active','Inactive']
        label=int(row[16]=='Active')
        assert label==int(any(isinstance(x,(int,float)) and x<=128 for x in row[4:15]))
        pid=row[2];acc=row[3].split('-')[0]
        add('APEX',pid,row[1],label,{'kind':'protein_fragment','paper_doi':'10.1038/s41551-024-01201-x',
            'source_table':f'Supplementary Dataset 2, row {i}',
            'source_id':row[3],'parent_accession':acc,'parent_database':'NCBI Protein',
            'source_organism_reported':row[21],'secreted_status_reported':row[17],
            'source_type_reported':row[15],'chemistry':'Fmoc synthetic peptide; terminal chemistry not resolved from retrieved table.',
            'expression_note':'Protein substring mining. No candidate-specific natural cleavage or expression evidence supplied.'})
        assays.append({'id':'APEX__'+pid,'label':label,'endpoint':'Any MIC <=128 uM among 11 tested pathogens',
            'label_source':f'Supplementary Dataset 2 row {i}, explicit Active/Inactive plus numeric MIC agreement',
            'mic_uM_raw':dict(zip(apex[1][4:15],row[4:15])),
            'censoring_note':'N.A. retained literally; not converted to zero or numeric MIC. Binary label taken from explicit source column.'})
    assert sum(r['Label'] for r in records if r['cohort']=='APEX')==41
    refs={split:{r['Sequence'] for r in csvrows(ROOT/f'reproduction/assets/upstream/data/{split}_dedup_split.csv')} for split in ['train','val','test']}
    battle=set()
    for p in (ROOT/'manuscript_experiments/battle_official_v1/upstream/datasets').rglob('*.fasta'):
        seq=''
        for line in p.read_text().splitlines():
            if line.startswith('>'):
                if seq:battle.add(seq)
                seq=''
            else:seq+=line.strip()
        if seq:battle.add(seq)
    # Include all recorded BATTLE predictions, regardless of method/protocol.
    battle_files=[]
    for d in ['battle_official_v1','battle_amp_v1']:
        for p in (ROOT/'manuscript_experiments'/d).rglob('*.csv'):
            if p.stat().st_size>20_000_000:continue
            try:
                rr=csvrows(p)
                if rr:
                    key=next((k for k in ['sequence','Sequence'] if k in rr[0]),None)
                    if key:battle.update(r[key] for r in rr);battle_files.append(str(p.relative_to(ROOT)))
            except (UnicodeDecodeError,csv.Error):pass
    old=ROOT/'manuscript_experiments/data/metagenomic/evaluation_candidates.csv'
    prior={r['Sequence'] for r in csvrows(old)} if old.exists() else set()
    allseq=collections.defaultdict(set)
    for r in records:allseq[r['Sequence']].add(r['cohort'])
    for r in records:
        for split,ss in refs.items():r['exact_'+split]=r['Sequence'] in ss
        r['previous_BATTLE_overlap']=r['Sequence'] in battle
        r['prior_61_overlap']=r['Sequence'] in prior
        r['between_cohort_overlap']=len(allseq[r['Sequence']])>1
        reasons=[]
        if set(r['Sequence'])-set('ACDEFGHIKLMNPQRSTVWY'):reasons.append('noncanonical_or_unresolved_residue')
        if not 11<=r['length']<=30:reasons.append('outside_11_30_aa')
        if any(r['exact_'+s] for s in refs):reasons.append('exact_original_PPsAMP_split_overlap')
        r['eligible']=not reasons;r['exclusion_reason']=';'.join(reasons)
    def table(name,rr):
        with (DATA/name).open('w') as f:
            w=csv.DictWriter(f,fieldnames=list(rr[0]));w.writeheader();w.writerows(rr)
    table('all_candidates.csv',records);table('eligible_candidates.csv',[r for r in records if r['eligible']])
    save(DATA/'agent_source_fields_LOCAL.json',evidence);save(DATA/'experimental_outcomes_HIDDEN_FROM_AGENT.json',assays)
    summary={}
    for name in ['SEP','Archaeasin','APEX']:
        rr=[r for r in records if r['cohort']==name];el=[r for r in rr if r['eligible']]
        assert len({r['Sequence'] for r in rr})==len(rr)
        summary[name]={'all_n':len(rr),'all_active':sum(r['Label'] for r in rr),'length_eligible':sum(11<=r['length']<=30 for r in rr),
            'primary_n':len(el),'primary_active':sum(r['Label'] for r in el),'original_exact_overlaps':sum(any(r['exact_'+s] for s in refs) for r in rr),
            'prior_BATTLE_n':sum(r['previous_BATTLE_overlap'] for r in el),'prior_61_n':sum(r['prior_61_overlap'] for r in el),
            'cross_cohort_n':sum(r['between_cohort_overlap'] for r in el)}
    save(DATA/'cohort_audit.json',{'cohorts':summary,'BATTLE_csv_sources':battle_files,
        'limitations':['Exact deduplication does not remove distant homology or guarantee absence from encoder pretraining.',
        'Modified terminal chemistry is unresolved; sequence-only model evaluation is conditional on reported assay form.',
        'Retrospective, original-predictor-enriched candidate cohorts; not representative unbiased AMP/non-AMP samples.'],
        'source_hashes':{str(p.relative_to(HERE)):sha(p) for p in SRC.glob('*.xlsx')},
        'data_sha256':{str(p.relative_to(HERE)):sha(p) for p in DATA.glob('*') if p.name!='cohort_audit.json'}})
    print(json.dumps(summary,indent=2))
if __name__=='__main__':main()
