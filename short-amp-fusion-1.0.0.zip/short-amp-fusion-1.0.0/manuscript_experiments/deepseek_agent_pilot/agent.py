#!/usr/bin/env python3
"""DeepSeek tool-calling pilot over already computed, frozen AMP evidence."""
from __future__ import annotations

import argparse
import csv
import datetime as dt
import hashlib
import json
import os
from pathlib import Path
import sys
import urllib.error
import urllib.request

import numpy as np

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
ANALYSIS = ROOT / 'manuscript_experiments' / 'interpretability_v1'
BASE_URL = 'https://api.deepseek.com/chat/completions'
MODEL = 'deepseek-flash'
COHORTS = ('original_short', 'battle_retrained', 'holdout2026')
SEEDS = (42, 43, 44)
GROUPS = {'ESM2': (0, 64), 'ProtBERT': (64, 128), 'explicit_descriptors': (128, 189)}
DEFAULT_QUESTION = '请解释这个案例的预测结果、主要特征来源和长度因素，并指出解释的适用范围。'
SYSTEM = '''你是抗菌肽分类模型的证据整合助手。你只能调用已声明的只读工具并根据工具结果回答；不要编造序列、标签、活性、作用机制或工具未返回的数值。可根据问题决定调用工具；对预测及局部归因问题应调用相应工具。所有 SHAP 数值为正类 log-odds 归因：正值推动正类，负值推动负类；来源加和并非生物贡献百分比，也不是重新计算的组级 Shapley 值。群体长度置换不等同单条序列的长度因果作用。残基属性均值不是整肽实测性质，平均残基 pI 不是肽 pI，残基二级结构倾向不是肽结构。模型分数不是经过验证的临床概率。将输出写为 JSON，字段 answer（字符串）、claims（数组，每项为 {statement:字符串,evidence_ids:证据编号字符串数组}）、limitations（字符串数组）；每个具体论断必须引用调用工具实际返回的证据编号，不可杜撰编号。只返回 JSON。'''
TOOL_SPECS = [
    ('get_prediction', '获取本案例的固定种子模型预测分数、分类及解释设置。'),
    ('get_local_attribution', '获取本案例的特征来源 SHAP 加和、主要显式特征及单位。'),
    ('get_descriptor_summary', '获取本案例序列长度和氨基酸组成统计；不返回原始序列。'),
    ('get_length_context', '获取所选数据集的长度统计与探索性同长度置换的群体结果。'),
]
TOOLS = [{'type': 'function', 'function': {'name': name, 'description': description,
          'parameters': {'type': 'object', 'properties': {}, 'additionalProperties': False}}}
         for name, description in TOOL_SPECS]


def csv_rows(path: Path) -> list[dict]:
    with path.open(encoding='utf-8-sig', newline='') as file:
        return list(csv.DictReader(file))


def load_key() -> str:
    key = os.environ.get('DEEPSEEK_API_KEY', '').strip()
    if key:
        return key
    path = ROOT / '.env.deepseek'
    if path.is_file():
        for line in path.read_text(encoding='utf-8').splitlines():
            if line.strip().startswith('DEEPSEEK_API_KEY='):
                key = line.split('=', 1)[1].strip().strip('"').strip("'")
                if key:
                    return key
    raise RuntimeError('未找到 DEEPSEEK_API_KEY；请配置环境变量或根目录 .env.deepseek。')


class Evidence:
    def __init__(self, cohort: str, row_index: int, seed: int):
        if cohort not in COHORTS or seed not in SEEDS or row_index < 0:
            raise ValueError('无效的数据集、种子或行号。')
        self.cohort, self.row_index, self.seed = cohort, row_index, seed
        rows = csv_rows(ANALYSIS / cohort / 'cohort_predictions.csv')
        if row_index >= len(rows) or int(rows[row_index]['row_index']) != row_index:
            raise ValueError('案例行号不存在或与保存的索引不一致。')
        self.sequence = rows[row_index]['sequence']
        with np.load(ANALYSIS / cohort / f'shap_seed_{seed}.npz', allow_pickle=False) as data:
            if int(data['row_index'][row_index]) != row_index:
                raise ValueError('SHAP 文件中的案例索引不匹配。')
            self.shap = data['values'][row_index].copy()
            self.base = float(data['base'])
            self.probability = float(data['probability'][row_index])
        if self.shap.shape != (189,) or not np.isfinite(self.shap).all():
            raise ValueError('SHAP 数据维度或数值异常。')
        margin = self.base + float(self.shap.sum())
        recovered = float(1 / (1 + np.exp(-margin)))
        if not np.isclose(recovered, self.probability, atol=1e-9):
            raise ValueError('SHAP 加和结果和保存的模型概率不一致。')
        self.features = csv_rows(ANALYSIS / 'feature_dictionary.csv')
        if len(self.features) != 189 or any(int(r['feature_index']) != i for i, r in enumerate(self.features)):
            raise ValueError('特征字典维度或索引错误。')

    def get_prediction(self):
        return {'evidence_id': 'P1', 'cohort': self.cohort, 'row_index': self.row_index,
                'seed': self.seed, 'positive_score': self.probability,
                'threshold_rule': 'positive if score > 0.5',
                'predicted_label': 'AMP' if self.probability > 0.5 else 'non-AMP',
                'note': '固定种子、冻结模型的分类分数，不代表已校准活性概率。'}

    def get_local_attribution(self):
        groups = {name: float(self.shap[start:end].sum()) for name, (start, end) in GROUPS.items()}
        top = np.argsort(np.abs(self.shap[128:]))[-5:][::-1] + 128
        return {'evidence_id': 'S1', 'seed': self.seed, 'method': 'Tree SHAP tree_path_dependent',
                'unit': 'positive-class log-odds', 'base_log_odds': self.base,
                'total_log_odds': self.base + float(self.shap.sum()), 'source_sums': groups,
                'top_explicit_features': [{'feature': self.features[int(j)]['feature'],
                                          'shap_log_odds': float(self.shap[j])} for j in top],
                'note': '来源数值是特征 SHAP 的事后加和；正值推高正类，负值推低正类。'}

    def get_descriptor_summary(self):
        sequence = self.sequence
        return {'evidence_id': 'D1', 'length_aa': len(sequence),
                'amino_acid_fractions': {aa: sequence.count(aa) / len(sequence)
                                         for aa in 'ACDEFGHIKLMNPQRSTVWY'},
                'note': '只返回长度及组成；未返回的属性数值不能臆测。'}

    def get_length_context(self):
        rows = csv_rows(ANALYSIS / 'length_diagnostics.csv')
        d = next(r for r in rows if r['cohort'] == self.cohort)
        s = csv_rows(ANALYSIS / 'length_controlled_summary.csv')
        v = next(r for r in s if r['cohort'] == self.cohort and r['metric'] == 'auroc'
                 and r['experiment'] == 'descriptors_within_exact_length')
        return {'evidence_id': 'L1', 'scope': 'cohort-level retrospective analysis',
                'cohort': self.cohort, 'n': int(d['n']),
                'positive_mean_length_aa': float(d['positive_mean_length']),
                'negative_mean_length_aa': float(d['negative_mean_length']),
                'length_only_auroc': float(d['length_only_auroc']),
                'within_length_descriptor_permutation_auroc_decrease': float(v['mean']),
                'within_length_non_singleton_fraction': float(d['within_length_non_singleton_fraction']),
                'note': '方向由训练集确定；长度置换结果是队列级、回顾性探索，不是单条肽的因果效应。'}

    def call(self, name: str, arguments: dict):
        if name not in {n for n, _ in TOOL_SPECS} or arguments != {}:
            raise ValueError('工具名称或参数不合法。')
        return getattr(self, name)()


def request_deepseek(key: str, messages: list[dict], max_tokens=1800, tools=None) -> dict:
    payload = {'model': MODEL, 'messages': messages, 'tools': TOOLS if tools is None else tools,
               'response_format': {'type': 'json_object'}, 'temperature': 0,
               'max_tokens': max_tokens, 'stream': False,
               'thinking': {'type': 'disabled'}}
    req = urllib.request.Request(BASE_URL, data=json.dumps(payload, ensure_ascii=False).encode(),
        headers={'Authorization': f'Bearer {key}', 'Content-Type': 'application/json'}, method='POST')
    try:
        with urllib.request.urlopen(req, timeout=60) as response:
            return json.load(response)
    except urllib.error.HTTPError as exc:
        raise RuntimeError(f'DeepSeek API HTTP {exc.code}；请检查密钥、账户余额和 API 状态。') from None
    except urllib.error.URLError as exc:
        raise RuntimeError(f'DeepSeek API 网络连接失败：{type(exc.reason).__name__}。') from None


def validate_report(content: str, evidence: dict) -> dict:
    errors = []
    try:
        report = json.loads(content)
    except (TypeError, json.JSONDecodeError):
        return {'passed': False, 'errors': ['报告不是有效 JSON'], 'semantic_accuracy_checked': False}
    if not isinstance(report, dict):
        return {'passed': False, 'errors': ['报告必须为 JSON 对象'], 'semantic_accuracy_checked': False}
    if not isinstance(report.get('answer'), str) or not report['answer'].strip():
        errors.append('缺少 answer')
    if not isinstance(report.get('limitations'), list) or not report['limitations'] or not all(isinstance(x, str) and x.strip() for x in report['limitations']):
        errors.append('缺少 limitations')
    claims = report.get('claims')
    if not isinstance(claims, list) or not claims:
        errors.append('缺少 claims')
    else:
        for i, claim in enumerate(claims):
            if not isinstance(claim, dict) or not isinstance(claim.get('statement'), str) or not claim['statement'].strip():
                errors.append(f'第 {i+1} 条论断格式错误'); continue
            ids = claim.get('evidence_ids')
            if not isinstance(ids, list) or not ids or not all(isinstance(k, str) and k in evidence for k in ids):
                errors.append(f'第 {i+1} 条论断引用了不存在的证据')
    if not evidence:
        errors.append('没有调用证据工具')
    return {'passed': not errors, 'errors': errors, 'semantic_accuracy_checked': False,
            'note': '仅验证结构与证据编号，不验证事实、数值、方向或生物学含义；须人工核对。'}


def run(evidence_source: Evidence, question: str, request_fn, max_rounds=6,
        system_prompt=None, validator=validate_report, max_repairs=0, max_tools_per_round=4) -> dict:
    messages = [{'role': 'system', 'content': system_prompt or SYSTEM},
                {'role': 'user', 'content': f'案例 {evidence_source.cohort}:{evidence_source.row_index}，固定种子 {evidence_source.seed}。{question}'}]
    evidence, trace, usages, models = {}, [], [], []
    report_text = ''
    attempts = []
    for round_no in range(1, max_rounds + 1):
        response = request_fn(messages)
        usages.append(response.get('usage', {})); models.append(response.get('model', 'unknown'))
        choices = response.get('choices') or []
        if not choices:
            raise RuntimeError('API 未返回 choices。')
        message = choices[0].get('message') or {}
        calls = message.get('tool_calls') or []
        if calls:
            if len(calls) > max_tools_per_round:
                raise RuntimeError('单轮工具调用超过上限。')
            messages.append(message)
            for call in calls:
                function = call.get('function', {})
                name = function.get('name', '')
                try:
                    arguments = json.loads(function.get('arguments') or '{}')
                    result = evidence_source.call(name, arguments)
                except (ValueError, TypeError, json.JSONDecodeError) as exc:
                    result = {'error': str(exc)}
                if 'evidence_id' in result:
                    evidence[result['evidence_id']] = result
                trace.append({'round': round_no, 'tool': name, 'result': result})
                messages.append({'role': 'tool', 'tool_call_id': call['id'],
                                 'content': json.dumps(result, ensure_ascii=False, allow_nan=False)})
        else:
            report_text = message.get('content') or ''
            validation = validator(report_text, evidence)
            if choices[0].get('finish_reason') == 'length':
                validation['passed'] = False
                validation['errors'].append('API 输出达到 token 上限而截断')
            attempts.append({'report_text': report_text, 'validation': validation})
            if not validation['passed'] and len(attempts) <= max_repairs and round_no < max_rounds:
                messages.append({'role': 'assistant', 'content': report_text})
                messages.append({'role': 'user', 'content': '本地规则检查发现以下问题，请依据已返回证据修正并重新输出完整 JSON；这是核查反馈，不是新证据。' + json.dumps(validation['errors'], ensure_ascii=False)})
                continue
            break
    if not report_text:
        raise RuntimeError('达到调用轮数上限或 API 未输出报告。')
    return {'report_text': report_text, 'evidence': evidence, 'tool_trace': trace,
            'validation': attempts[-1]['validation'] if attempts else validator(report_text, evidence),
            'report_attempts': attempts, 'usage_by_round': usages,
            'returned_model_by_round': models}


def self_test():
    for cohort in COHORTS:
        for seed in SEEDS:
            ev = Evidence(cohort, 0, seed)
            assert ev.get_prediction()['evidence_id'] == 'P1'
            assert ev.get_local_attribution()['evidence_id'] == 'S1'
            assert ev.get_length_context()['evidence_id'] == 'L1'
            assert abs(sum(ev.get_descriptor_summary()['amino_acid_fractions'].values()) - 1) < 1e-9
    ev = Evidence('original_short', 1307, 42)
    def mock(messages):
        if not any(x.get('role') == 'tool' for x in messages):
            return {'model': 'mock', 'choices': [{'message': {'role': 'assistant', 'tool_calls': [
                {'id': 'c1', 'type': 'function', 'function': {'name': 'get_prediction', 'arguments': '{}'}},
                {'id': 'c2', 'type': 'function', 'function': {'name': 'get_local_attribution', 'arguments': '{}'}}]}}]}
        return {'model': 'mock', 'choices': [{'message': {'role': 'assistant', 'content': json.dumps(
            {'answer': '测试', 'claims': [{'statement': '模型预测', 'evidence_ids': ['P1', 'S1']}],
             'limitations': ['此为模拟测试']}, ensure_ascii=False)}}]}
    result = run(ev, '模拟测试', mock)
    assert result['validation']['passed'] and len(result['tool_trace']) == 2
    bad = validate_report('{"answer":"x","claims":[{"statement":"x","evidence_ids":["X"]}],"limitations":["x"]}', result['evidence'])
    assert not bad['passed']
    try:
        ev.call('get_prediction', {'unexpected': 1})
        raise AssertionError('无效参数不应通过')
    except ValueError:
        pass
    print('本地自检通过：3 个队列 × 3 个种子预测/归因加和，多轮工具调用、证据编号和参数校验。')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--cohort', choices=COHORTS, default='original_short')
    parser.add_argument('--row-index', type=int, default=1307)
    parser.add_argument('--seed', type=int, choices=SEEDS, default=42)
    parser.add_argument('--question', default=DEFAULT_QUESTION)
    parser.add_argument('--self-test', action='store_true')
    args = parser.parse_args()
    if args.self_test:
        self_test(); return
    key = load_key()
    evidence_source = Evidence(args.cohort, args.row_index, args.seed)
    result = run(evidence_source, args.question, lambda messages: request_deepseek(key, messages))
    timestamp = dt.datetime.now(dt.timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')
    output_dir = HERE / 'output'
    output_dir.mkdir(mode=0o700, exist_ok=True)
    output = output_dir / f'{args.cohort}_row{args.row_index}_seed{args.seed}_{timestamp}.json'
    record = {'created_utc': timestamp, 'requested_model': MODEL, 'cohort': args.cohort,
              'row_index': args.row_index, 'seed': args.seed, 'question': args.question,
              'system_prompt_sha256': hashlib.sha256(SYSTEM.encode()).hexdigest(),
              'settings': {'temperature': 0, 'thinking': 'disabled', 'max_output_tokens': 1800,
                           'max_rounds': 6, 'max_tool_calls_per_round': 4}, **result}
    output.write_text(json.dumps(record, ensure_ascii=False, indent=2, allow_nan=False) + '\n', encoding='utf-8')
    output.chmod(0o600)
    print(f'报告文件：{output}')
    print(f"自动结构/证据编号检查：{'通过' if result['validation']['passed'] else '未通过'}；数值和科学含义仍须人工复核。")
    if not result['validation']['passed']:
        print('检查问题：' + '；'.join(result['validation']['errors']))
        sys.exit(2)


if __name__ == '__main__':
    try:
        main()
    except (RuntimeError, ValueError, OSError, KeyError) as exc:
        print(f'运行失败：{exc}', file=sys.stderr)
        sys.exit(1)
