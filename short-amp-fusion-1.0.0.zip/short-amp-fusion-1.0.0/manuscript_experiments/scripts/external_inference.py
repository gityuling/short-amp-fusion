from common_study import *
import gc,gzip
from transformers import BertModel,BertTokenizer,AutoTokenizer,EsmModel
from threadpoolctl import threadpool_limits
from compute_features import compute_pseaac
from train_token_attn import TokenCrossAttentionModel
from common import CONFIG

def extract(sequences,dest):
 if (dest/'features.npz').exists():
  meta=json.loads((dest/'extraction.json').read_text());assert meta.get('extractor_version')=='case_sensitive_v2', 'Stale extraction cache';assert meta.get('extraction_code_sha256')==sha256(__file__), 'Extractor changed';assert meta['cache_sha256']==sha256(dest/'features.npz');z=dict(np.load(dest/'features.npz'));assert z['sequences'].tolist()==list(sequences);return z
 dest.mkdir(parents=True,exist_ok=True);seqs=list(sequences);result={};cost={}
 for key,loc,klass,tokklass in [('prot',ASSETS/'models/protbert_finetuned',BertModel,BertTokenizer),('esm',ROOT/'optimization/assets/esm2_150m',EsmModel,AutoTokenizer)]:
  start=time.perf_counter();tok=tokklass.from_pretrained(loc,local_files_only=True,**({'do_lower_case':False} if key=='prot' else {}));model=klass.from_pretrained(loc,local_files_only=True,add_pooling_layer=False).cuda().eval();torch.cuda.synchronize();load=time.perf_counter()-start;torch.cuda.reset_peak_memory_stats();start=time.perf_counter();chunks=[];ts=[];ms=[]
  with torch.no_grad():
   for i in range(0,len(seqs),16):
    batch=seqs[i:i+16];text=[' '.join(s) for s in batch] if key=='prot' else batch
    enc=tok(text,padding='max_length',max_length=32,truncation=False,return_tensors='pt');assert enc['input_ids'].shape[1]==32
    assert not (enc['input_ids']==tok.unk_token_id).any(), 'Unexpected unknown amino-acid token';assert torch.equal(enc['attention_mask'].sum(1),torch.tensor([len(s)+2 for s in batch]));enc={k:v.cuda() for k,v in enc.items() if k in ['input_ids','attention_mask']};h=model(**enc).last_hidden_state
    lens=torch.tensor([len(s) for s in batch],device='cuda');mask=(torch.arange(32,device='cuda')[None,:]>0)&(torch.arange(32,device='cuda')[None,:]<=lens[:,None]);mean=(h*mask[:,:,None]).sum(1)/lens[:,None];maximum=h.masked_fill(~mask[:,:,None],-torch.inf).max(1).values;chunks.append(torch.cat([h[:,0],mean,maximum],1).cpu().numpy())
    if key=='prot':ts.append(h.cpu().numpy());ms.append(enc['attention_mask'].cpu().numpy())
  torch.cuda.synchronize();cost[key]={'load_seconds':load,'forward_seconds':time.perf_counter()-start,'peak_allocated_bytes':torch.cuda.max_memory_allocated(),'batch_size':16,'n':len(seqs)};result[key]=np.concatenate(chunks).astype('float64')
  if key=='prot':result['tokens']=np.concatenate(ts);result['masks']=np.concatenate(ms)
  del model;gc.collect();torch.cuda.empty_cache()
 result.update(phys=phys_raw(seqs),sequences=np.array(seqs,dtype=str));np.savez(dest/'features.npz',**result);write_json(dest/'extraction.json',{'extractor_version':'case_sensitive_v2','extraction_code_sha256':sha256(__file__),'cost':cost,'cache_sha256':sha256(dest/'features.npz'),'encoder_manifests':{str(p.relative_to(ROOT)):sha256(p) for p in [ROOT/'optimization/assets/esm2_150m/manifest.json',ROOT/'reproduction/reports/asset_manifest.json']}});return result

def predict_all(frame,raw,dest,include_comparators=True):
 ensure_parity()
 dest.mkdir(parents=True,exist_ok=True);rows=[]
 def save(name,seed,p):
  table=pd.DataFrame({'sequence':frame.Sequence,'probability_amp':p})
  if 'Label' in frame:table['label']=frame.Label.values
  if 'id' in frame:table['id']=frame.id.values
  table.to_csv(dest/f'{name}_seed_{seed}.csv',index=False)
  for cohort in ['all','homology_filtered'] if 'homology_filtered' in frame else ['all']:
   mask=np.ones(len(frame),bool) if cohort=='all' else frame.homology_filtered.values.astype(bool)
   if 'Label' in frame and mask.sum() and frame.Label[mask].nunique()==2:
    score=metrics(frame.Label.values[mask],p[mask]);rows.append({'model':name,'seed':seed,'cohort':cohort,'n':int(mask.sum()),**{k:v for k,v in score.items() if k!='confusion'}})
 for cfg in CFG['variants']:
  # Full fixed feature ablation on external source: no selection.
  tf=joblib.load(BASE/f"results/core/{cfg['name']}/transforms.joblib")
  with threadpool_limits(limits=4):xx=transform(raw,tf,cfg)
  for seed in CFG['seeds']:
   with threadpool_limits(limits=4):p=joblib.load(BASE/f"results/core/{cfg['name']}/seed_{seed}/model.joblib").predict_proba(xx)[:,1]
   save(cfg['name'],seed,p)
 pse=torch.tensor(np.asarray([compute_pseaac(s) for s in frame.Sequence],dtype='float32'));head=TokenCrossAttentionModel(**{k:CONFIG[k] for k in ['embedding_dim','num_heads','num_layers','dropout']}).eval()
 for seed in CFG['seeds']:
  head.load_state_dict(torch.load(ROOT/f'reproduction/results/official_seed_{seed}/best_model.pt',weights_only=True,map_location='cpu'));pp=[]
  with torch.no_grad():
   for i in range(0,len(frame),64):pp.extend(head(pse[i:i+64],torch.from_numpy(raw['tokens'][i:i+64]),torch.from_numpy(raw['masks'][i:i+64])).softmax(-1)[:,1].numpy())
  save('ppsamp',seed,np.array(pp))
 if include_comparators:
  import run_comparators as comp
  comp.ALPH=json.loads((BASE/'results/comparators/raac_alphabets.json').read_text());rx=comp.raac(frame.Sequence);mx=comp.macrel_x(frame.Sequence)
  for name in ['deep_ampep30_reimplementation','rf_ampep30_reimplementation','macrel_retrained']:
   for seed in CFG['seeds']:
    sd=BASE/f'results/comparators/{name}/seed_{seed}'
    if not (sd/'result.json').exists():continue
    if name.startswith('deep'):
     m=comp.Deep30();m.load_state_dict(torch.load(sd/'model.pt',weights_only=True));m.eval()
     with torch.no_grad():p=m(torch.from_numpy(rx)).sigmoid().numpy()
    else:p=joblib.load(sd/'model.joblib').predict_proba(mx if name=='macrel_retrained' else rx)[:,1]
    save(name,seed,p)
 pd.DataFrame(rows).to_csv(dest/'metrics.csv',index=False)
 return rows

def ensure_parity():
 parity=BASE/'reports/external_extraction_parity.json'
 if parity.exists():
  verified=json.loads(parity.read_text());assert verified['extractor_sha256']==sha256(__file__);assert verified['passed'];return
 f,r=raw_official('val');z=extract(f.Sequence.iloc[:16],BASE/'data/external/parity');errors={k:float(np.max(np.abs(z[k]-r[k][:16]))) for k in ['prot','esm','phys']};assert max(errors.values())<.002,errors
 cfg=next(c for c in CFG['variants'] if c['name']=='dual64_phys');tf=joblib.load(BASE/'results/core/dual64_phys/transforms.joblib');prob_errors={}
 with threadpool_limits(limits=4):
  xx=transform(z,tf,cfg)
  for seed in CFG['seeds']:
   p=joblib.load(BASE/f'results/core/dual64_phys/seed_{seed}/model.joblib').predict_proba(xx)[:,1];old=pd.read_csv(BASE/f'results/core/dual64_phys/seed_{seed}/val_predictions.csv').probability_amp.values[:16];error=float(np.max(np.abs(p-old)));assert error<1e-12,error;prob_errors[str(seed)]=error
 write_json(parity,{'passed':True,'extractor_sha256':sha256(__file__),'feature_errors':errors,'champion_probability_errors':prob_errors})

def main():
 setup();frame=pd.read_csv(BASE/'data/external/uniprolcad_exact_removed.csv');assert len(frame)>0,'No eligible external sequences'
 ensure_parity()
 dest=BASE/'results/external';dest.mkdir(parents=True,exist_ok=True)
 write_json(dest/'frozen_models_before_external.json',{'models':{str(p.relative_to(BASE)):sha256(p) for p in (BASE/'results/core').rglob('model.joblib')},'protocol':sha256(BASE/'protocols/study.json'),'input':sha256(BASE/'data/external/uniprolcad_exact_removed.csv')})
 raw=extract(frame.Sequence,BASE/'data/external/embeddings');rows=predict_all(frame,raw,dest)
 print(pd.DataFrame(rows).groupby(['model','cohort']).f1.mean().to_string(),flush=True)
if __name__=='__main__':main()
