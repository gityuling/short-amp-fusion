from common_study import *
import copy,gzip,importlib.util,traceback
from sklearn.ensemble import RandomForestClassifier
from threadpoolctl import threadpool_limits
sys.path.insert(0,str(BASE/'sources/macrel'))
from macrel.macrel_features import compute_all,normalize_seq
ALPH=[]  # Extracted from the archived paper Table 1 before use.
class Deep30(torch.nn.Module):
 def __init__(self):
  super().__init__();self.net=torch.nn.Sequential(torch.nn.BatchNorm1d(1,eps=.001,momentum=.01),torch.nn.Conv1d(1,128,3),torch.nn.ReLU(),torch.nn.MaxPool1d(2),torch.nn.Dropout(.2),torch.nn.Conv1d(128,128,3),torch.nn.ReLU(),torch.nn.MaxPool1d(2),torch.nn.Dropout(.2),torch.nn.Flatten(),torch.nn.Linear(128*20,10),torch.nn.ReLU(),torch.nn.Linear(10,1))
 def forward(self,x):return self.net(x[:,None,:]).flatten()
def raac(seqs):return np.asarray([[sum(seq.count(a) for a in group) for alph in ALPH for group in alph] for seq in seqs],dtype='float32')
def macrel_x(seqs):return np.asarray([compute_all(normalize_seq(s)) for s in seqs],dtype='float64')
def main():
 setup();out=BASE/'results/comparators';out.mkdir(parents=True,exist_ok=True)
 # Alphabet source is extracted directly from Table 1, avoiding transcription errors.
 import xml.etree.ElementTree as ET,re
 root=ET.parse(BASE/'sources/deep_ampep30.xml').getroot();table=next(t for t in root.findall('.//table-wrap') if t.get('id')=='tbl1')
 al=[]
 for tr in table.findall('.//tbody/tr'):
  text=''.join(tr.findall('td')[-1].itertext());groups=re.findall(r'\(([A-Z]+)\)',text);al.append(groups)
 assert [len(a) for a in al]==[19,15,17,17,18]
 # Correct internally inconsistent printed alphabets using pinned iFeature implementation.
 # Table 1 type8 repeats V and omits Y; type12 repeats T. Preserve group order.
 al[2]=['AT','C','DE','F','G','H','IV','K','L','M','N','P','Q','R','S','W','Y']
 al[3][0]='IVL';al[4][0]='IVL'
 global ALPH;ALPH=al
 for a in ALPH:assert sorted(''.join(a))==sorted('ACDEFGHIKLMNPQRSTVWY')
 write_json(out/'raac_alphabets.json',ALPH)
 # Paper example FVKKRAAT has counts sum8 in each block. CNN valid convolution: 86->84->42->40->20.
 assert raac(['FVKKRAAT']).shape==(1,86)
 frames={s:pd.read_csv(ASSETS/'data'/f'{s}_dedup_split.csv') for s in ['train','val']}
 rx={s:raac(f.Sequence) for s,f in frames.items()};mx={s:macrel_x(f.Sequence) for s,f in frames.items()}
 for name in ['rf_ampep30_reimplementation','deep_ampep30_reimplementation','macrel_retrained']:
  for seed in CFG['seeds']:
   dest=out/name/f'seed_{seed}';dest.mkdir(parents=True,exist_ok=True)
   if (dest/'result.json').exists():continue
   setup(seed);start=time.time();hist=[];y=frames['train'].Label.values
   if name=='deep_ampep30_reimplementation':
    model=Deep30().cuda()
    # Keras default glorot uniform kernels and zero biases.
    for m in model.modules():
     if isinstance(m,(torch.nn.Conv1d,torch.nn.Linear)):torch.nn.init.xavier_uniform_(m.weight);torch.nn.init.zeros_(m.bias)
    opt=torch.optim.RMSprop(model.parameters(),lr=.001,alpha=.9,eps=1e-7);lossfn=torch.nn.BCEWithLogitsLoss()
    loader=torch.utils.data.DataLoader(torch.utils.data.TensorDataset(torch.from_numpy(rx['train']),torch.tensor(y,dtype=torch.float32)),batch_size=64,shuffle=True)
    for ep in range(100):
     model.train();losses=[]
     for xx,yy in loader:opt.zero_grad();loss=lossfn(model(xx.cuda()),yy.cuda());loss.backward();opt.step();losses.append(float(loss.detach()))
     model.eval()
     with torch.no_grad():p=model(torch.from_numpy(rx['val']).cuda()).sigmoid().cpu().numpy()
     hist.append({'epoch':ep+1,'loss':float(np.mean(losses)),'val_f1':metrics(frames['val'].Label.values,p)['f1']})
    torch.save(model.cpu().state_dict(),dest/'model.pt');write_json(dest/'history.json',hist)
   else:
    x=mx if name=='macrel_retrained' else rx
    model=RandomForestClassifier(n_estimators=101 if name=='macrel_retrained' else 1200,max_features='sqrt' if name=='macrel_retrained' else 1,random_state=seed,n_jobs=4).fit(x['train'],y)
    p=model.predict_proba(x['val'])[:,1];joblib.dump(model,dest/'model.joblib')
   save_pred(dest/'val_predictions.csv',frames['val'],p);write_json(dest/'result.json',{'name':name,'seed':seed,'validation':metrics(frames['val'].Label.values,p),'seconds_fit_and_val':time.time()-start,'checkpoint_sha256':sha256(dest/('model.pt' if name.startswith('deep') else 'model.joblib'))})
   print('DONE',name,seed,flush=True)
 write_json(out/'frozen_before_test.json',{'files':{str(p.relative_to(BASE)):sha256(p) for p in out.rglob('*') if p.suffix in ['.pt','.joblib']},'protocol_sha256':sha256(BASE/'protocols/comparators.json'),'code_sha256':sha256(__file__)})
 frames['test']=pd.read_csv(ASSETS/'data/test_dedup_split.csv');rx['test']=raac(frames['test'].Sequence);mx['test']=macrel_x(frames['test'].Sequence)
 rows=[]
 for dest in out.glob('*/seed_*'):
  r=json.loads((dest/'result.json').read_text());name=r['name']
  if name.startswith('deep'):
   model=Deep30();model.load_state_dict(torch.load(dest/'model.pt',weights_only=True));model.eval()
   with torch.no_grad():p=model(torch.from_numpy(rx['test'])).sigmoid().numpy()
  else:p=joblib.load(dest/'model.joblib').predict_proba(mx['test'] if name=='macrel_retrained' else rx['test'])[:,1]
  save_pred(dest/'test_predictions.csv',frames['test'],p);score=metrics(frames['test'].Label.values,p);write_json(dest/'test_metrics.json',score)
  for split,m in [('val',r['validation']),('test',score)]:rows.append({'model':name,'seed':r['seed'],'split':split,**{k:v for k,v in m.items() if k!='confusion'}})
 pd.DataFrame(rows).to_csv(out/'same_training_test_metrics.csv',index=False)
if __name__=='__main__':main()
