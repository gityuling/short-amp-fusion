import json,time,copy,warnings
from common_study import *
from sklearn.ensemble import HistGradientBoostingClassifier
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from threadpoolctl import threadpool_limits

def main():
 setup(); frames={}; raw={}
 for s in ['train','val']:frames[s],raw[s]=raw_official(s)
 out=BASE/'results/core';out.mkdir(parents=True,exist_ok=True)
 reused={'phys':'phase5/tree_physics_only','prot128_phys':'phase5/tree_global_pca128','esm128_phys':'phase8/esm128_global','dual64_phys':'phase8/dual64_global'}
 rows=[]
 # Freeze every model before any supplementary test evaluation.
 for cfg in CFG['variants']:
  name=cfg['name'];dest=out/name;dest.mkdir(exist_ok=True)
  print('FEATURES',name,flush=True)
  with threadpool_limits(limits=4):
   if (dest/'transforms.joblib').exists():tf=joblib.load(dest/'transforms.joblib')
   elif name in reused:
    p=ROOT/'optimization'/reused[name]/'transforms.joblib';old=joblib.load(p);tf={'phys':old['phys_scaler']}
    for k in ['prot','esm']:
     if cfg[k]:
      if 'semantic_scaler' in old:tf[k]={'scaler':old['semantic_scaler'],'pca':old['pca']}
      else:tf[k]=old['protbert' if k=='prot' else k]
    joblib.dump(tf,dest/'transforms.joblib')
   else:tf=fit_transform(raw['train'],cfg);joblib.dump(tf,dest/'transforms.joblib')
   x=transform(raw['train'],tf,cfg);v=transform(raw['val'],tf,cfg)
   for seed in CFG['seeds']:
    sd=dest/f'seed_{seed}';sd.mkdir(exist_ok=True)
    if (sd/'result.json').exists():continue
    start=time.time();model=joblib.load(ROOT/'optimization'/reused[name]/f'seed_{seed}/model.joblib') if name in reused else HistGradientBoostingClassifier(**CFG['hgb'],random_state=seed).fit(x,raw['train']['labels'])
    p=model.predict_proba(v)[:,1]
    if name in reused:
     old=pd.read_csv(ROOT/'optimization'/reused[name]/f'seed_{seed}/validation_predictions.csv');np.testing.assert_allclose(p,old.probability_amp,atol=1e-12,rtol=0)
    joblib.dump(model,sd/'model.joblib');save_pred(sd/'val_predictions.csv',frames['val'],p)
    write_json(sd/'result.json',{'name':name,'seed':seed,'validation':metrics(raw['val']['labels'],p),'seconds_fit_and_val':time.time()-start,'reused':reused.get(name),'n_features':x.shape[1],'checkpoint_sha256':sha256(sd/'model.joblib')})
    print(name,seed,metrics(raw['val']['labels'],p)['f1'],flush=True)
 # Matched classifier controls.
 cfg=next(c for c in CFG['variants'] if c['name']=='dual64_phys');tf=joblib.load(out/'dual64_phys/transforms.joblib')
 x=transform(raw['train'],tf,cfg);v=transform(raw['val'],tf,cfg)
 sc=StandardScaler();x=sc.fit_transform(x).astype('float32');v=sc.transform(v).astype('float32')
 for kind in ['logistic','mlp']:
  dest=out/f'dual64_phys_{kind}';dest.mkdir(exist_ok=True);joblib.dump(sc,dest/'classifier_scaler.joblib')
  for seed in CFG['seeds']:
   sd=dest/f'seed_{seed}';sd.mkdir(exist_ok=True)
   if (sd/'result.json').exists():continue
   setup(seed);start=time.time();hist=[]
   if kind=='logistic':
    with threadpool_limits(limits=4):model=LogisticRegression(**CFG['classifiers']['logistic'],random_state=seed).fit(x,raw['train']['labels']);p=model.predict_proba(v)[:,1]
    joblib.dump(model,sd/'model.joblib')
   else:
    model=MLP(x.shape[1]);opt=torch.optim.AdamW(model.parameters(),lr=.001,weight_decay=.0001)
    y=raw['train']['labels'];lossfn=torch.nn.BCEWithLogitsLoss(pos_weight=torch.tensor((y==0).sum()/(y==1).sum()))
    loader=torch.utils.data.DataLoader(torch.utils.data.TensorDataset(torch.from_numpy(x),torch.tensor(y,dtype=torch.float32)),batch_size=64,shuffle=True)
    best=-1.;stale=0
    for ep in range(150):
     model.train()
     for bx,by in loader:opt.zero_grad();loss=lossfn(model(bx),by);loss.backward();opt.step()
     model.eval()
     with torch.no_grad():pv=model(torch.from_numpy(v)).sigmoid().numpy()
     score=metrics(raw['val']['labels'],pv)['f1'];hist.append({'epoch':ep+1,'validation_f1':score})
     if score>best:best=score;state=copy.deepcopy(model.state_dict());p=pv.copy();stale=0
     else:stale+=1
     if stale>=20:break
    torch.save(state,sd/'model.pt');write_json(sd/'history.json',hist)
   save_pred(sd/'val_predictions.csv',frames['val'],p)
   write_json(sd/'result.json',{'name':f'dual64_phys_{kind}','seed':seed,'validation':metrics(raw['val']['labels'],p),'seconds_fit_and_val':time.time()-start,'n_features':x.shape[1],'checkpoint_sha256':sha256(sd/('model.pt' if kind=='mlp' else 'model.joblib'))})
   print(kind,seed,metrics(raw['val']['labels'],p)['f1'],flush=True)
 files={str(p.relative_to(BASE)):sha256(p) for p in out.rglob('*') if p.is_file() and p.suffix in ['.joblib','.pt']}
 write_json(out/'frozen_before_test.json',{'files':files,'protocol_sha256':sha256(BASE/'protocols/study.json'),'code_sha256':sha256(__file__)})
 frames['test'],raw['test']=raw_official('test')
 for dest in sorted(out.iterdir()):
  if not dest.is_dir():continue
  name=dest.name;kind='mlp' if name.endswith('_mlp') else 'logistic' if name.endswith('_logistic') else 'hgb'
  cfg=next(c for c in CFG['variants'] if c['name']==(name if kind=='hgb' else 'dual64_phys'))
  tf=joblib.load(out/cfg['name']/'transforms.joblib')
  with threadpool_limits(limits=4):xx=transform(raw['test'],tf,cfg)
  if kind!='hgb':xx=joblib.load(dest/'classifier_scaler.joblib').transform(xx).astype('float32')
  for seed in CFG['seeds']:
   sd=dest/f'seed_{seed}';r=json.loads((sd/'result.json').read_text())
   if kind=='mlp':
    model=MLP(xx.shape[1]);model.load_state_dict(torch.load(sd/'model.pt',weights_only=True));model.eval()
    with torch.no_grad():p=model(torch.from_numpy(xx)).sigmoid().numpy()
   else:
    with threadpool_limits(limits=4):p=joblib.load(sd/'model.joblib').predict_proba(xx)[:,1]
   save_pred(sd/'test_predictions.csv',frames['test'],p)
   write_json(sd/'test_metrics.json',metrics(raw['test']['labels'],p))
   for split,m in [('val',r['validation']),('test',metrics(raw['test']['labels'],p))]:rows.append({'model':name,'seed':seed,'split':split,**{k:v for k,v in m.items() if k!='confusion'}})
 pd.DataFrame(rows).to_csv(out/'all_metrics.csv',index=False)
 pd.DataFrame(rows).groupby(['model','split']).agg(['mean','std']).to_csv(out/'summary.csv')
 print('CORE COMPLETE',flush=True)
if __name__=='__main__':main()
