"""Evaluate frozen local models with pinned BATTLE-AMP tasks and official metric functions.

No fitting, label changes, new splits, or threshold selection. Reference predictions
are the author's checksum-verified archive, not newly reproduced model runs.
"""
from common_study import *
import os, gc, fcntl, argparse, importlib.util, contextlib, traceback
import yaml
from threadpoolctl import threadpool_limits
import battle_amp_study as previous
from compute_features import compute_pseaac
import train_token_attn as baseline

OUT=BASE/'battle_official_v1'; UP=OUT/'upstream'
CONFIG=yaml.safe_load((UP/'config/config.yaml').read_text())
TASKS={k:v for k,v in CONFIG['tasks'].items() if v['type']=='classification' and k!='example_classification'}
SPEC=importlib.util.spec_from_file_location('battle_official_metrics',UP/'workflow/scripts/evaluate.py')
EVAL=importlib.util.module_from_spec(SPEC);SPEC.loader.exec_module(EVAL)
VARIANT=next(v for v in CFG['variants'] if v['name']=='dual64_phys')
SCOPES={'short':(11,30),'extended':(10,100)}
SEEDS=[42,43,44]

def stamp():return previous.stamp()
def checkpoint(scope,kind,seed):
    if scope=='extended':return BASE/f'battle_amp_v1/results/{"ppsamp" if kind=="ppsamp" else "dual64_phys"}/seed_{seed}'/('model.pt' if kind=='ppsamp' else 'model.joblib')
    if kind=='ppsamp':return ROOT/f'reproduction/results/official_seed_{seed}/best_model.pt'
    return BASE/f'results/core/dual64_phys/seed_{seed}/model.joblib'
def transforms(scope):return BASE/('battle_amp_v1/results/dual64_phys/transforms.joblib' if scope=='extended' else 'results/core/dual64_phys/transforms.joblib')

def freeze():
    OUT.mkdir(exist_ok=True)
    assert json.loads((OUT/'cache/archive_verified.json').read_text())['sha256']=='b3faa3e9221596ecf70713f80981599acea2234801ded2694f84bdf8ee5d9b64'
    assert json.loads((OUT/'reference_parity.json').read_text())['passed']
    pub=pd.read_csv(UP/'results/aggregated/classification_results.tsv',sep='\t')
    refs=sorted(set(pub.variant)-{'example-model','mole-amp'})
    files=[checkpoint(s,k,n) for s in SCOPES for k in ['ppsamp','dual'] for n in SEEDS]+[transforms(s) for s in SCOPES]
    protocol={'created':stamp(),'upstream_commit':'8c659c0cc3d69a260b1865984dbea9d1199f651d',
      'reference_prediction_commit':'42f5f169ae25b6d21d9a945d1233efe07c8a0734','references':refs,
      'official_tasks':TASKS,'scope':SCOPES,'seeds':SEEDS,'threshold':.5,
      'checkpoints':{str(p.relative_to(ROOT)):sha256(p) for p in files},
      'label_hashes':{v['labels']:sha256(UP/v['labels']) for v in TASKS.values()},
      'evaluator_sha256':sha256(UP/'workflow/scripts/evaluate.py'),'code_sha256':sha256(__file__),
      'primary_tasks':[k for k in TASKS if k.startswith('holdout2026_')],
      'primary_interpretation':'Fixed checkpoint evaluation. 2026 holdout is primary for observed exact non-overlap; no guarantee of encoder-supervision or homology independence.',
      'native_table':'Unmodified official task labels and evaluator; native supported lengths per model; display sample coverage and grey-zone abstention. Not a common-cohort ranking.',
      'matched_table':'Supplement: per reference/task/local scope intersection of evaluated sequences; includes regressor grey-zone exclusion for BOTH sides. Compare identical sequence/label rows; no global ranking across different pairwise cohorts.',
      'training_exposure':'Retain all official task sequences; annotate overlap against local train+validation and all prior splits. Extended AMP-task scores include training sequences and cannot establish generalization.',
      'checkpoint_definitions':{'short':'Original 11–30 aa PPsAMP-data fitted heads and scalers, frozen encoders.','extended':'Previously fitted BATTLE AMP-task 10–100 aa heads/scalers, frozen encoders.'},
      'duplicate_labels':'Preserve official label rows, including 1 conflict in full AMP task and 3415 conflicting sequences in synthetic_shuffled; disclose and do not interpret shuffled task as clean syntax discrimination.',
      'reference_source':'Author cached raw predictions, SHA256 verified; inference for these methods is NOT rerun locally.',
      'excluded_tasks':'Example toy, MIC regression, molecular dynamics and paired-vignette analyses: local binary models do not predict MIC or MD.',
      'model_output_semantics':'Native Probability_score+Prediction => classifier; MIC+MIC_unit => regressor, including AMPredictor despite README classifier label; verified against published metrics.',
      'limitations':['Adapted ProtBERT supervised provenance incomplete.','Source negative class not automatically assay-confirmed inactive.','Different tasks can reuse sequences and are not independent datasets.',
        'Official shuffled task contains contradictory sequence labels; interpret its results only as reproduction diagnostics.','Regressor grey-zone exclusion is retained as official behavior; coverage must accompany metrics.','No model fitting, threshold tuning or selection from these outputs.']}
    path=OUT/'protocol.json'
    if path.exists():
        old=json.loads(path.read_text())
        # JSON round-trip normalizes tuple/list scope values.
        normalized=json.loads(json.dumps(protocol))
        assert all(old[k]==normalized[k] for k in old if k!='created'),'Frozen evaluation protocol changed'
    else:write_json(path,protocol)

def exposure_sets():
    result={}
    for scope in SCOPES:
        for subset in ['development','all']:
            seqs=set()
            for split in (['train','val'] if subset=='development' else ['train','val','test']):
                p=(BASE/f'battle_amp_v1/data/{split}.csv') if scope=='extended' else ASSETS/f'data/{split}_dedup_split.csv'
                seqs.update(pd.read_csv(p).Sequence)
            result[(scope,subset)]=seqs
    return result

def prepare():
    if (OUT/'data/audit.json').exists():return
    dest=OUT/'data';dest.mkdir(exist_ok=True)
    union=set();holdout=set();core=set();rows=[];exposure=exposure_sets()
    for name,tc in TASKS.items():
        df=pd.read_csv(UP/tc['labels'],sep='\t')
        duplicate_rows=int(df.sequence.duplicated().sum());conflicts=int((df.groupby('sequence')[tc.get('label_column','label')].nunique()>1).sum())
        seq=set(df.sequence);union.update(seq)
        if name.startswith('holdout2026'):holdout.update(seq)
        if name!='slay':core.update(seq)
        for scope,(lo,hi) in SCOPES.items():
            mask=df.sequence.map(lambda s:lo<=len(s)<=hi and set(s)<=set('ACDEFGHIKLMNPQRSTVWY'))
            part=df[mask];y=part[tc.get('label_column','label')]==tc.get('positive_label','AMP')
            rows.append({'task':name,'scope':scope,'n_labels':len(df),'duplicate_label_rows':duplicate_rows,'conflicting_label_sequences':conflicts,'n_supported':len(part),'positive':int(y.sum()),'negative':int((~y).sum()),
              'development_overlap':int(part.sequence.isin(exposure[(scope,'development')]).sum()),'prior_all_split_overlap':int(part.sequence.isin(exposure[(scope,'all')]).sum())})
    seqs=sorted((s for s in union if 10<=len(s)<=100 and set(s)<=set('ACDEFGHIKLMNPQRSTVWY')),key=lambda s:(0 if s in holdout else 1 if s in core else 2,len(s),s))
    df=pd.DataFrame({'sequence':seqs});df['length']=df.sequence.str.len();df['priority']=df.sequence.map(lambda s:0 if s in holdout else 1 if s in core else 2)
    df.to_csv(dest/'sequences.csv',index=False);pd.DataFrame(rows).to_csv(dest/'task_coverage_and_overlap.csv',index=False)
    write_json(dest/'audit.json',{'tasks':len(TASKS),'union_all_lengths':len(union),'inference_sequences':len(df),'priority_counts':{str(k):int(v) for k,v in df.priority.value_counts().items()},'sequence_sha256':sha256(dest/'sequences.csv'),'no_labels_modified':True,'no_overlap_removal':True})
    print('PREPARED',len(TASKS),'tasks;',len(df),'sequences',flush=True)

def fast_pseaac(s):
    ix=np.asarray([AA_TO_IDX[a] for a in s]);values=AA_PROPERTIES[:,ix];theta=np.zeros((20,20))
    for lag in range(1,min(20,len(s)-1)+1):theta[:,lag-1]=np.mean((values[:,:-lag]-values[:,lag:])**2,axis=1)
    denom=1+.05*theta.sum();return np.concatenate([np.bincount(ix,minlength=20)/len(s)/denom,.05*theta.ravel()/denom]).astype(np.float32)

def preflight():
    if (OUT/'adapter_parity.json').exists():return
    previous.parity()
    seqs=pd.read_csv(ASSETS/'data/val_dedup_split.csv').Sequence.iloc[:16].tolist()+['ACDEFGHIKLMNPQRSTVWY'*5,'ACDEFGHIKL']
    error=max(float(np.max(np.abs(fast_pseaac(s)-compute_pseaac(s)))) for s in seqs);assert error<1e-7,error
    # Check archived evaluator behavior on local earlier predictions, using official label schema.
    p=BASE/'battle_amp_v1/results/dual64_phys/seed_42/test_predictions.csv';d=pd.read_csv(p);n=OUT/'preflight_local_predictions.tsv';labels=OUT/'preflight_local_labels.tsv'
    pd.DataFrame({'sequence':d.sequence,'Prediction':np.where(d.probability_amp>.5,'AMP','non-AMP'),'Probability_score':d.probability_amp}).to_csv(n,sep='\t',index=False)
    pd.DataFrame({'sequence':d.sequence,'label':np.where(d.label==1,'AMP','non-AMP')}).to_csv(labels,sep='\t',index=False)
    report=EVAL.evaluate_task(n,labels,OUT/'preflight_local_metrics.json',{'type':'classification'},'classifier')
    old=metrics(d.label,d.probability_amp.values);err=max(abs(report['metrics'][a]-old[b]) for a,b in [('f1','f1'),('mcc','mcc'),('auroc','auc'),('auprc','average_precision')]);assert err<1e-12
    write_json(OUT/'adapter_parity.json',{'passed':True,'pseaac_max_error':error,'metric_max_error':err,'long_sequence_and_encoder_parity':str(BASE/'battle_amp_v1/parity.json'),'code_sha256':sha256(__file__)})

def extract():
    df=pd.read_csv(OUT/'data/sequences.csv');dest=OUT/'features';dest.mkdir(exist_ok=True)
    old_df=pd.read_csv(BASE/'battle_amp_v1/data/all_sequences.csv');old_ix={s:i for i,s in enumerate(old_df.Sequence)}
    # No persistent token cache for the large official collection; compute head scores while ProtBERT is resident.
    for key,dim in [('prot',3072),('esm',1920)]:
        done=dest/f'{key}_complete.json'
        if done.exists():continue
        statepath=dest/f'{key}_progress.json';start=json.loads(statepath.read_text())['next_row'] if statepath.exists() else 0;mode='r+' if statepath.exists() else 'w+'
        pool=np.lib.format.open_memmap(dest/f'{key}.npy',mode=mode,dtype=np.float32,shape=(len(df),dim))
        cached=np.load(BASE/f'battle_amp_v1/features/{key}.npy',mmap_mode='r')
        if key=='prot':
            cached_tokens=np.load(BASE/'battle_amp_v1/features/tokens.npy',mmap_mode='r')
            probs=np.lib.format.open_memmap(dest/'ppsamp.npy',mode=mode,dtype=np.float32,shape=(len(df),6))
            physics=np.lib.format.open_memmap(dest/'phys.npy',mode=mode,dtype=np.float32,shape=(len(df),61))
            if mode=='w+':probs[:]=np.nan
            heads={}
            for scope in SCOPES:
                for seed in SEEDS:
                    h=previous.new_head();h.load_state_dict(torch.load(checkpoint(scope,'ppsamp',seed),map_location='cuda',weights_only=True));heads[scope,seed]=h.eval()
        tok,model=previous.encoder(key)
        for i in range(start,len(df),16):
            batch=df.iloc[i:i+16];seqs=batch.sequence.tolist();length=batch.length.values
            if all(s in old_ix for s in seqs):
                ix=[old_ix[s] for s in seqs];p=cached[ix]
                if key=='prot':t=cached_tokens[ix,:int(max(length))+2];m=np.arange(t.shape[1])[None,:]<(length[:,None]+2)
            else:p,t,m=previous.encode_batch(key,tok,model,seqs)
            pool[i:i+len(seqs)]=p
            if key=='prot':
                physics[i:i+len(seqs)]=phys_raw(seqs)
                pse=torch.tensor(np.asarray([fast_pseaac(s) for s in seqs]),device='cuda');tokens=torch.tensor(t,device='cuda');mask=torch.tensor(m,device='cuda')
                with torch.no_grad():
                    for scope,(lo,hi) in SCOPES.items():
                        valid=(length>=lo)&(length<=hi)
                        if not valid.any():continue
                        v=torch.tensor(valid,device='cuda');offset=0 if scope=='short' else 3
                        for j,seed in enumerate(SEEDS):
                            scores=heads[scope,seed](pse[v],tokens[v],mask[v]).softmax(-1)[:,1].cpu().numpy()
                            probs[i+np.flatnonzero(valid),offset+j]=scores
                del pse,tokens,mask
            if (i//16)%500==0 or i+16>=len(df):
                pool.flush()
                if key=='prot':probs.flush();physics.flush()
                write_json(statepath,{'next_row':min(i+16,len(df)),'n':len(df),'updated':stamp()});print('EXTRACT',key,min(i+16,len(df)),len(df),flush=True)
        del model,cached;gc.collect();torch.cuda.empty_cache();pool.flush();del pool
        if key=='prot':
            probs.flush();physics.flush();del probs,physics,cached_tokens,heads;gc.collect();torch.cuda.empty_cache()
        write_json(done,{'n':len(df),'pooled_sha256':sha256(dest/f'{key}.npy'),'code_sha256':sha256(__file__)})

def score():
    df=pd.read_csv(OUT/'data/sequences.csv');dest=OUT/'predictions';dest.mkdir(exist_ok=True)
    raw={k:np.load(OUT/f'features/{k}.npy',mmap_mode='r') for k in ['prot','esm','phys']};bp=np.load(OUT/'features/ppsamp.npy',mmap_mode='r')
    for scope,(lo,hi) in SCOPES.items():
        ids=np.flatnonzero(df.length.between(lo,hi));part=df.iloc[ids];offset=0 if scope=='short' else 3
        tf=joblib.load(transforms(scope))
        for kind in ['ppsamp','dual']:
            for j,seed in enumerate(SEEDS):
                path=dest/f'{scope}_{kind}_{seed}.tsv'
                if path.exists():continue
                if kind=='ppsamp':p=np.asarray(bp[ids,offset+j])
                else:
                    mdl=joblib.load(checkpoint(scope,kind,seed));chunks=[]
                    with threadpool_limits(limits=4):
                        for start in range(0,len(ids),4096):
                            ix=ids[start:start+4096];x={k:np.asarray(v[ix],dtype=np.float64 if k!='phys' else np.float32) for k,v in raw.items()}
                            chunks.append(mdl.predict_proba(transform(x,tf,VARIANT))[:,1])
                    p=np.concatenate(chunks)
                assert len(p)==len(part) and np.isfinite(p).all()
                result=pd.DataFrame({'sequence':part.sequence.values,'Prediction':np.where(p>.5,'AMP','non-AMP'),'Probability_score':p})
                temp=path.with_suffix('.pending');result.to_csv(temp,sep='\t',index=False);temp.replace(path);print('SCORED',scope,kind,seed,len(p),flush=True)
    write_json(dest/'manifest.json',{p.name:sha256(p) for p in dest.glob('*.tsv')})

def evaluated_arrays(pred,labels,tc):
    """Official join, labels, native hard predictions, and MIC grey-zone behavior."""
    m=pd.merge(pred,labels,on='sequence',how='inner',suffixes=('_pred','_label'))
    y=(m[tc.get('label_column','label')]==tc.get('positive_label','AMP')).astype(int).values
    if 'MIC' in pred.columns:
        vals,_=EVAL.extract_mic_predictions(m,'sequence',CONFIG['benchmark_unit']);a=CONFIG['activity_thresholds']
        yp,prob,keep,_=EVAL.regressor_to_classification(vals,m.sequence.values,CONFIG['benchmark_unit'],a['active'],a['inactive'],a['unit'])
        return m.sequence.values[keep],y[keep],yp[keep],prob[keep]
    return m.sequence.values,y,(m.Prediction=='AMP').astype(int).values,pd.to_numeric(m.Probability_score,errors='coerce').values

def calc(y,pred,prob,tc):return EVAL.compute_classification_metrics(y,pred,prob,tc.get('metrics') or EVAL.DEFAULT_CLASSIFICATION_METRICS,tc)

def evaluate():
    dest=OUT/'evaluation';dest.mkdir(exist_ok=True);exposures=exposure_sets()
    protocol=json.loads((OUT/'protocol.json').read_text());refs=protocol['references'];rows=[];paired=[];validation=[];missing=[]
    pub=pd.read_csv(UP/'results/aggregated/classification_results.tsv',sep='\t')
    # Load local score tables once. 12 x ~0.5M rows fit within host RAM; probability arrays retained, strings shared by pandas indexing.
    ours={}
    for scope in SCOPES:
        for kind in ['ppsamp','dual']:
            for seed in SEEDS:
                name=f'{scope}_{kind}_{seed}';ours[name]=pd.read_csv(OUT/f'predictions/{name}.tsv',sep='\t').set_index('sequence')
    for task,tc in TASKS.items():
        cache=dest/f'{task}.json'
        if cache.exists():
            saved=json.loads(cache.read_text());rows+=saved['native'];paired+=saved['paired'];validation+=saved['reference_validation'];missing+=saved['missing'];continue
        native=[];pairs=[];checks=[];miss=[]
        labels=pd.read_csv(UP/tc['labels'],sep='\t')
        for name,table in ours.items():
            scope=name.split('_')[0];part=table.reindex(labels.sequence);mask=part.Probability_score.notna().values
            lab=labels[mask];p=part.Probability_score.values[mask];y=(lab[tc.get('label_column','label')]==tc.get('positive_label','AMP')).astype(int).values
            m=calc(y,(p>.5).astype(int),p,tc)
            native.append({'task':task,'variant':name,'source':'local_frozen','scope':scope,'n_labels':len(labels),'coverage':len(lab)/len(labels),
              'development_overlap':int(lab.sequence.isin(exposures[scope,'development']).sum()),'prior_all_split_overlap':int(lab.sequence.isin(exposures[scope,'all']).sum()),**m})
        for name in refs:
            path=UP/f'results/inference/{name}/{tc["dataset"]}/predictions.tsv'
            if not path.exists():miss.append({'variant':name,'task':task,'reason':'No archived predictions'});continue
            pred=pd.read_csv(path,sep='\t');assert not pred.sequence.duplicated().any(),(name,task)
            seq,y,yp,prob=evaluated_arrays(pred,labels,tc);m=calc(y,yp,prob,tc)
            matched=int(pred.sequence.isin(labels.sequence).sum());native.append({'task':task,'variant':name,'source':'author_cached','scope':'native','n_labels':len(labels),'n_matched_before_grey_zone':matched,'coverage':len(seq)/len(labels),**m})
            previous_row=pub[(pub.variant==name)&(pub.task==task)]
            if len(previous_row)==1:
                delta={k:abs(float(m[k])-float(previous_row.iloc[0][k])) for k in ['f1','mcc','auroc','auprc'] if m.get(k) is not None and pd.notna(previous_row.iloc[0][k])}
                checks.append({'variant':name,'task':task,'max_metric_difference':max(delta.values(),default=0.),'n_evaluated':len(seq),'published_n':float(previous_row.iloc[0].n_samples)})
            # Pairwise common evaluated cohort. The official regressor abstention mask is applied to both sides.
            for scope in SCOPES:
                local_keys=[f'{scope}_{kind}_{seed}' for kind in ['ppsamp','dual'] for seed in SEEDS]
                ix=ours[local_keys[0]].index.get_indexer(seq);valid=ix>=0
                if not valid.any():continue
                common=seq[valid];yy=y[valid];refm=calc(yy,yp[valid],prob[valid],tc)
                for local_name in local_keys:
                    pp=ours[local_name].loc[common,'Probability_score'].values;lm=calc(yy,(pp>.5).astype(int),pp,tc)
                    pairs.append({'task':task,'reference':name,'local_variant':local_name,'scope':scope,'n_common':len(common),
                      'local_development_overlap':sum(s in exposures[scope,'development'] for s in common),
                      **{f'reference_{k}':v for k,v in refm.items()},**{f'local_{k}':v for k,v in lm.items()}})
            del pred
        payload={'native':native,'paired':pairs,'reference_validation':checks,'missing':miss};write_json(cache,payload)
        rows+=native;paired+=pairs;validation+=checks;missing+=miss
        pd.DataFrame(rows).to_csv(OUT/'native_metrics.csv',index=False);print('EVALUATED',task,flush=True)
    pd.DataFrame(rows).to_csv(OUT/'native_metrics.csv',index=False);pd.DataFrame(paired).to_csv(OUT/'matched_comparisons.csv',index=False)
    write_json(OUT/'reference_reproduction.json',{'checks':validation,'missing':missing,'max_metric_difference':max((r['max_metric_difference'] for r in validation),default=0.),'n_mismatched_sample_counts':sum(r['n_evaluated']!=r['published_n'] for r in validation)})
    write_json(OUT/'evaluation_complete.json',{'completed':stamp(),'tasks':len(TASKS),'native_rows':len(rows),'paired_rows':len(paired)})

def report():
    df=pd.read_csv(OUT/'native_metrics.csv');pair=pd.read_csv(OUT/'matched_comparisons.csv')
    local=df[df.source=='local_frozen'].copy();local['model']=local.variant.str.replace(r'_\d+$','',regex=True)
    cols=['mcc','f1','precision','tpr','tnr','auroc','auprc','precision_at_k','pauroc_01','pauroc_001','n_samples','development_overlap']
    summary=local.groupby(['task','model'])[cols].agg(['mean','std']);summary.to_csv(OUT/'local_summary.csv')
    pair['local_model']=pair.local_variant.str.replace(r'_\d+$','',regex=True)
    pcols=['n_common','local_development_overlap','reference_f1','local_f1','reference_mcc','local_mcc','reference_auroc','local_auroc','reference_auprc','local_auprc','reference_precision_at_k','local_precision_at_k']
    ps=pair.groupby(['task','reference','local_model'])[pcols].mean().reset_index()
    for m in ['f1','mcc','auroc','auprc','precision_at_k']:ps['delta_'+m]=ps['local_'+m]-ps['reference_'+m]
    ps.to_csv(OUT/'matched_summary.csv',index=False)
    meta=json.loads((OUT/'reference_reproduction.json').read_text())
    lines=['# BATTLE-AMP 官方分类任务评估','',f'完成：{stamp()}','',
      '固定本地模型，官方标签与评分函数；参评方法使用作者公开、校验过SHA256的原始预测。没有重新训练参评方法，没有重新划分、调参或选阈值。',
      '', '覆盖39项实际分类任务；不包含示例任务、MIC回归、MD或配对案例复现。官方原生范围表与同序列配对比较分别保存。',
      '', '**解释规则：** extended模型在BATTLE AMP识别数据上训练过，AMP任务成绩包含训练重合，不能当独立泛化证据。重点查看2026 holdout并核查development_overlap。各模型原生长度及MIC灰区剔除不同，native表不能直接整体排名。matched表每一对使用完全相同的实际评估序列，但不同配对间样本集合仍可不同。',
      '',f'作者参考结果复算最大核心指标误差：{meta["max_metric_difference"]:.3g}；样本数不一致项：{meta["n_mismatched_sample_counts"]}。任何不一致需核查后再做论文结论。',
      '', '## 2026 holdout broad activity：本地模型原生支持范围','', '| 模型 | n | 开发集重合 | F1均值 | MCC均值 | AUROC均值 |','|---|---:|---:|---:|---:|---:|']
    h=local[local.task=='holdout2026_broad_activity'].groupby('model')[cols].mean()
    for name,row in h.iterrows():lines.append(f'| {name} | {int(row.n_samples)} | {int(row.development_overlap)} | {row.f1:.4f} | {row.mcc:.4f} | {row.auroc:.4f} |')
    lines+=['','## 同序列比较：extended_dual vs 官方参评方法（holdout broad activity）','','| 对照 | 共同n | 对照F1 | 我们F1（三种子均值） | 对照AUROC | 我们AUROC |','|---|---:|---:|---:|---:|---:|']
    h=ps[(ps.task=='holdout2026_broad_activity')&(ps.local_model=='extended_dual')]
    for _,row in h.iterrows():lines.append(f'| {row.reference} | {int(row.n_common)} | {row.reference_f1:.4f} | {row.local_f1:.4f} | {row.reference_auroc:.4f} | {row.local_auroc:.4f} |')
    lines+=['','全部结果：native_metrics.csv、local_summary.csv、matched_comparisons.csv、matched_summary.csv。数据覆盖与训练重合：data/task_coverage_and_overlap.csv。',
      '', '局限：官方synthetic_shuffled任务含3415条序列的冲突标签，结果只作协议复算诊断，不能作为干净的语序判别证据。原始短肽模型开发/测试集此前已被使用；作者适配ProtBERT历史监督数据不完整。此处0精确重合不证明同源或编码器独立。标签按官方任务保留，活性阈值任务与通用AMP识别属于不同终点。']
    (OUT/'RESULTS.md').write_text('\n'.join(lines)+'\n')

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--preflight',action='store_true');args=parser.parse_args()
    lock=open(OUT/'runner.lock','w');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB);setup();freeze()
    tasks=[('01_tasks_and_exposure',prepare),('02_adapter_parity',preflight),('03_frozen_encoder_inference',extract),('04_frozen_head_scores',score),('05_official_and_matched_evaluation',evaluate),('06_report',report)]
    if args.preflight:tasks=tasks[:2]
    p=OUT/'status.json';state=json.loads(p.read_text()) if p.exists() else {'tasks':{}}
    state.update(status='running',pid=os.getpid(),updated=stamp(),mode='strictly_serial_no_chat_polling');write_json(p,state)
    for name,fn in tasks:
        if state['tasks'].get(name,{}).get('status')=='complete':continue
        state['current_task']=name;state['tasks'][name]={'status':'running','started':stamp()};write_json(p,state);print('START',name,flush=True)
        try:fn()
        except Exception as e:
            state['tasks'][name].update(status='failed',error=str(e),finished=stamp());state.update(status='failed',updated=stamp());write_json(p,state);raise
        state['tasks'][name].update(status='complete',finished=stamp());state['updated']=stamp();write_json(p,state);print('END',name,flush=True)
    state.update(status='preflight_complete' if args.preflight else 'complete',current_task=None,updated=stamp());write_json(p,state)

if __name__=='__main__':main()
