"""Global, gap-aware homology audit; no claim to recreate the upstream CD-HIT protocol."""
import numpy as np
from Bio.Align import PairwiseAligner,substitution_matrices
from concurrent.futures import ProcessPoolExecutor
A=None;REF=None

def init(ref):
 global A,REF
 REF=ref;A=PairwiseAligner();A.mode='global';A.substitution_matrix=substitution_matrices.load('BLOSUM62');A.open_gap_score=-10;A.extend_gap_score=-.5

def identity(a,b):
 if min(len(a),len(b))/max(len(a),len(b))<.8:return 0.
 ali=A.align(a,b)[0];ix=ali.indices;paired=(ix[0]>=0)&(ix[1]>=0);n=int(paired.sum())
 if n/len(a)<.8 or n/len(b)<.8:return 0.
 aa=np.frombuffer(a.encode(),dtype=np.uint8);bb=np.frombuffer(b.encode(),dtype=np.uint8)
 return float((aa[ix[0,paired]]==bb[ix[1,paired]]).sum()/ix.shape[1])
def nearest(seq):
 best=0.;hit=''
 for ref in REF:
  if seq==ref:return 1.,ref
  v=identity(seq,ref)
  if v>best:best=v;hit=ref
 return best,hit

def scan(seqs,refs,workers=4):
 with ProcessPoolExecutor(max_workers=workers,initializer=init,initargs=(list(refs),)) as pool:return list(pool.map(nearest,list(seqs),chunksize=16))
