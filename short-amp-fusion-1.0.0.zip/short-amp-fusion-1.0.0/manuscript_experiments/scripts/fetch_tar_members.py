"""Read an uncompressed public tar by HTTP byte range; save selected research inputs only."""
import requests,tarfile,time,json,pathlib
base=pathlib.Path(__file__).resolve().parents[1]; out=base/'sources/AMPSphere';out.mkdir(exist_ok=True)
url='https://zenodo.org/api/records/7742544/files/data_folder.tar/content'
s=requests.Session();index=[];pos=0; cache=b'';cache_start=0
wanted=['selected_candidates.tsv','selected_peptides.fasta','active_AMP_renames.tsv','AMP_coprediction_AMPSphere.tsv.xz']
def get(start,end):
 for attempt in range(6):
  r=s.get(url,headers={'Range':f'bytes={start}-{end}'},timeout=45)
  if r.status_code==429:time.sleep(min(45,int(r.headers.get('retry-after','10'))));continue
  r.raise_for_status();assert r.status_code==206;assert r.headers['Content-Range'].startswith(f'bytes {start}-');return r.content
 raise RuntimeError('rate limited')
while pos<7797288960:
 if not cache_start<=pos<=cache_start+len(cache)-512:cache_start=pos;cache=get(pos,min(pos+65535,7797288959))
 header=cache[pos-cache_start:pos-cache_start+512]
 if not header.strip(b'\0'):break
 info=tarfile.TarInfo.frombuf(header,'utf8','surrogateescape');index.append({'name':info.name,'size':info.size,'offset':pos+512})
 print(info.name,info.size,flush=True)
 if pathlib.Path(info.name).name in wanted:
  (out/pathlib.Path(info.name).name).write_bytes(get(pos+512,pos+511+info.size))
 pos+=512+((info.size+511)//512)*512
 (out/'tar_index.json').write_text(json.dumps(index,indent=2))
 time.sleep(.3)
print('DONE',flush=True)
