"""Serial second-dataset retraining. No original-test-driven model selection."""
from common_study import *
import os, gc, argparse, subprocess, traceback, fcntl, functools
from sklearn.model_selection import StratifiedGroupKFold
from sklearn.ensemble import HistGradientBoostingClassifier
from threadpoolctl import threadpool_limits
from transformers import BertModel, BertTokenizer, EsmModel, AutoTokenizer
import train_token_attn as upstream
from compute_features import compute_pseaac
from common import CONFIG as ORIGINAL

OUT=BASE/'battle_amp_v1'
SOURCE=BASE/'dataset_survey/BATTLE-AMP/tasks/amp/labels.tsv'
TOOLS=BASE/'tools/mmseqs2/unpacked'
MMSEQS=TOOLS/'usr/bin/mmseqs-avx2'
VARIANT=next(x for x in CFG['variants'] if x['name']=='dual64_phys')
SEEDS=[42,43,44]

def stamp():
    from datetime import datetime
    from zoneinfo import ZoneInfo
    return datetime.now(ZoneInfo('Asia/Shanghai')).isoformat()

def freeze_protocol():
    OUT.mkdir(exist_ok=True)
    protocol={'created':stamp(),'purpose':'BATTLE-AMP second-dataset retraining, not fixed-model external evaluation',
      'source_commit':'8c659c0cc3d69a260b1865984dbea9d1199f651d','source_sha256':sha256(SOURCE),
      'length':[10,100],'standard_amino_acids_only':True,'keep_overlap_with_original_ppsamp':True,
      'split':'MMseqs2 all-v-all detected >=80% identity and >=80% bidirectional coverage edges; connected components; StratifiedGroupKFold 5 folds shuffle random_state=20261102; fold0 test, fold1 val, folds2-4 train',
      'similarity_search':{'min_seq_id':.4,'coverage':.8,'cov_mode':0,'sensitivity':7.5,'evalue':1000,'mask':0,'comp_bias_corr':0,'alignment_mode':3,'max_seqs':100000},
      'group_identity_threshold':.8,
      'grouping_caveat':'Heuristic local alignment search; no guarantee all global low-identity pairs detected; not identical to previous global Needleman-Wunsch analysis.',
      'seeds':SEEDS,'threshold':.5,'primary':'F1','secondary':['MCC','AUROC','AP','accuracy','precision','recall','specificity'],
      'length_strata':[[10,30],[31,50],[51,100]],'split_ratios_target':[.6,.2,.2],
      'encoders':'Frozen author-adapted PPsAMP ProtBERT and frozen public ESM2 t30_150M; no encoder fitting on this dataset.',
      'ppsamp':ORIGINAL,'dual_variant':VARIANT,'hgb':CFG['hgb'],
      'selection':'PPsAMP epoch by validation F1 with upstream scheduler and patience; fixed HGB settings; no threshold tuning; all six models frozen before any test prediction.',
      'adaptations':['Complete sequences up to 100 aa, no truncation; token buffer102; dynamic batch padding and masks.',
        'Streaming memory-mapped token dataset instead of upstream full-memory loading; upstream network and train/evaluate functions retained.',
        'Remove obsolete scheduler verbose argument; class weights recomputed from new training labels.',
        'PCA/scalers fitted on new training only; length/30 feature retained and standardized using new train only.'],
      'limitations':['Not the original short-peptide PPsAMP evaluation protocol.','Original adapted encoder supervised exposure remains incompletely documented.',
        'Original PPsAMP sequence overlap is retained; this is not proof of source-independent generalization.',
        'BATTLE-AMP AMP/non-AMP labels retained; negative construction provenance requires further audit and is not assumed experimentally verified inactivity.'],
      'code_sha256':sha256(__file__),'upstream_training_sha256':sha256(ROOT/'PPsAMP/pipeline/train_token_attn.py'),
      'mmseqs_binary_sha256':sha256(MMSEQS),'encoder_weights_sha256':{str(p.relative_to(ROOT)):sha256(p) for p in [ASSETS/'models/protbert_finetuned/model.safetensors',ROOT/'optimization/assets/esm2_150m/model.safetensors']}}
    path=OUT/'protocol.json'
    if path.exists():
        previous=json.loads(path.read_text())
        for k in protocol:
            if k!='created':assert previous[k]==protocol[k],f'Frozen protocol changed: {k}'
    else:write_json(path,protocol)

def prepare():
    if (OUT/'data/audit.json').exists():return
    dest=OUT/'data';dest.mkdir(exist_ok=True)
    df=pd.read_csv(SOURCE,sep='\t').rename(columns={'sequence':'Sequence','label':'Label'})
    df['Label']=df.Label.map({'AMP':1,'non-AMP':0});assert df.Label.notna().all()
    df=df[df.Sequence.map(lambda s:10<=len(s)<=100 and set(s)<=set('ACDEFGHIKLMNPQRSTVWY'))].copy()
    assert not df.Sequence.duplicated().any(), 'Resolve duplicate/conflicting source labels before splitting'
    df=df.sort_values('Sequence').reset_index(drop=True);df['row_id']=np.arange(len(df));df['length']=df.Sequence.str.len()
    ref=set()
    for s in ['train','val','test']:ref.update(pd.read_csv(ASSETS/f'data/{s}_dedup_split.csv').Sequence)
    df['overlap_original_ppsamp']=df.Sequence.isin(ref)
    fasta=dest/'all.fasta';fasta.write_text(''.join(f'>s{i}\n{s}\n' for i,s in enumerate(df.Sequence)))
    edges=dest/'similarity_edges.tsv'
    if not edges.exists():
        temp=dest/'similarity_edges.pending.tsv'
        cmd=[str(MMSEQS),'easy-search',str(fasta),str(fasta),str(temp),str(dest/'mmseqs_tmp'),
            '--min-seq-id','0.4','-c','0.8','--cov-mode','0','-s','7.5','-e','1000','--mask','0','--comp-bias-corr','0',
            '--alignment-mode','3','--max-seqs','100000','--threads','4','--split-memory-limit','6G',
            '--format-output','query,target,fident,qcov,tcov','--remove-tmp-files','1']
        env={**os.environ,'LD_LIBRARY_PATH':str(TOOLS/'usr/lib/x86_64-linux-gnu')}
        with (OUT/'mmseqs.log').open('w') as log:subprocess.run(cmd,env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
        temp.replace(edges)
    parent=np.arange(len(df))
    def find(i):
        while parent[i]!=i:parent[i]=parent[parent[i]];i=int(parent[i])
        return i
    accepted=0
    with edges.open() as f:
        for line in f:
            a,b,identity,qcov,tcov=line.rstrip().split('\t')
            if float(identity)+1e-9<.8 or min(float(qcov),float(tcov))+1e-9<.8:continue
            i,j=int(a[1:]),int(b[1:]);x,y=find(i),find(j)
            if x!=y:parent[y]=x
            accepted+=1
    df['group']=[find(i) for i in range(len(df))]
    strata=df.Label.astype(str)+'_'+pd.cut(df.length,[9,30,50,100],labels=['short','medium','long']).astype(str)
    splitter=StratifiedGroupKFold(n_splits=5,shuffle=True,random_state=20261102)
    df['split']='train'
    for fold,(_,ix) in enumerate(splitter.split(df,strata,df.group)):
        if fold<2:df.loc[ix,'split']=['test','val'][fold]
    assert df.groupby('group').split.nunique().max()==1
    df.to_csv(dest/'all_sequences.csv',index=False)
    for split in ['train','val','test']:
        part=df[df.split==split];assert part.Label.nunique()==2
        part.to_csv(dest/f'{split}.csv',index=False)
    audit={'n':len(df),'groups':int(df.group.nunique()),'largest_group':int(df.groupby('group').size().max()),
      'retained_original_overlap':int(df.overlap_original_ppsamp.sum()),'accepted_similarity_edges':accepted,
      'cross_split_detected_similarity_edges':0,'cross_split_identical_sequences':0,
      'split_counts':df.groupby(['split','Label']).size().unstack(fill_value=0).to_dict('index'),
      'files':{str(p.relative_to(OUT)):sha256(p) for p in dest.glob('*.csv')},'edge_file_sha256':sha256(edges)}
    write_json(dest/'audit.json',audit);print('DATA',json.dumps(audit),flush=True)

def encoder(key):
    if key=='prot':
        loc=ASSETS/'models/protbert_finetuned'
        tok=BertTokenizer.from_pretrained(loc,local_files_only=True,do_lower_case=False)
        model=BertModel.from_pretrained(loc,local_files_only=True,add_pooling_layer=False)
    else:
        loc=ROOT/'optimization/assets/esm2_150m';tok=AutoTokenizer.from_pretrained(loc,local_files_only=True)
        model=EsmModel.from_pretrained(loc,local_files_only=True,add_pooling_layer=False)
    return tok,model.cuda().eval()

@torch.no_grad()
def encode_batch(key,tok,model,seqs):
    text=[' '.join(s) for s in seqs] if key=='prot' else list(seqs)
    enc=tok(text,padding=True,truncation=False,return_tensors='pt')
    lens=torch.tensor([len(s) for s in seqs])
    assert not (enc['input_ids']==tok.unk_token_id).any()
    assert torch.equal(enc['attention_mask'].sum(1),lens+2)
    assert enc['input_ids'].shape[1]<=102
    enc={k:v.cuda() for k,v in enc.items() if k in ['input_ids','attention_mask']}
    h=model(**enc).last_hidden_state;lens=lens.cuda()
    pos=torch.arange(h.shape[1],device='cuda')[None,:]
    mask=(pos>0)&(pos<=lens[:,None]);mean=(h*mask[:,:,None]).sum(1)/lens[:,None]
    maximum=h.masked_fill(~mask[:,:,None],-torch.inf).max(1).values
    return torch.cat([h[:,0],mean,maximum],1).cpu().numpy(),h.cpu().numpy(),enc['attention_mask'].cpu().numpy()

def parity():
    if (OUT/'parity.json').exists():return
    frame,raw=raw_official('val');seqs=frame.Sequence.iloc[:16].tolist();errors={}
    for key in ['prot','esm']:
        tok,model=encoder(key);pooled,tokens,masks=encode_batch(key,tok,model,seqs)
        error=float(np.max(np.abs(pooled-raw[key][:16])));assert error<.002,(key,error);errors[key]=error
        # Long-sequence smoke check ensures every residue is represented.
        longseqs=['ACDEFGHIKLMNPQRSTVWY'*5,'ACDEFGHIKL']
        lp,lt,lm=encode_batch(key,tok,model,longseqs)
        assert lt.shape[1]==102 and lm.sum(1).tolist()==[102,12] and np.isfinite(lp).all()
        if key=='prot':
            head=upstream.TokenCrossAttentionModel(**{k:ORIGINAL[k] for k in ['embedding_dim','num_heads','num_layers','dropout']}).eval()
            head.load_state_dict(torch.load(ROOT/'reproduction/results/official_seed_42/best_model.pt',weights_only=True,map_location='cpu'))
            with h5py.File(FEATURES/'val_tokens.h5') as h:oldtokens=h['embeddings'][:16];oldmasks=h['masks'][:16]
            pse=torch.tensor(np.asarray([compute_pseaac(s) for s in seqs],dtype=np.float32))
            with torch.no_grad():
                a=head(pse,torch.from_numpy(tokens),torch.from_numpy(masks)).softmax(-1)[:,1]
                b=head(pse,torch.from_numpy(oldtokens),torch.from_numpy(oldmasks)).softmax(-1)[:,1]
                longout=head(torch.tensor(np.asarray([compute_pseaac(s) for s in longseqs],dtype=np.float32)),torch.from_numpy(lt),torch.from_numpy(lm))
            err=float((a-b).abs().max());assert err<2e-5 and torch.isfinite(longout).all();errors['ppsamp_probability']=err
            del head
        del model;gc.collect();torch.cuda.empty_cache()
    write_json(OUT/'parity.json',{'passed':True,'errors':errors,'long_sequence_no_truncation_passed':True,'code_sha256':sha256(__file__)})

def extract():
    df=pd.read_csv(OUT/'data/all_sequences.csv');dest=OUT/'features';dest.mkdir(exist_ok=True)
    for key,dim in [('prot',3072),('esm',1920)]:
        done=dest/f'{key}_complete.json'
        if done.exists():continue
        statepath=dest/f'{key}_progress.json';start=json.loads(statepath.read_text())['next_row'] if statepath.exists() else 0
        mode='r+' if statepath.exists() else 'w+'
        pooled=np.lib.format.open_memmap(dest/f'{key}.npy',mode=mode,dtype=np.float32,shape=(len(df),dim))
        if key=='prot':tokens=np.lib.format.open_memmap(dest/'tokens.npy',mode=mode,dtype=np.float32,shape=(len(df),102,1024))
        tok,model=encoder(key)
        for i in range(start,len(df),16):
            seqs=df.Sequence.iloc[i:i+16].tolist();p,t,m=encode_batch(key,tok,model,seqs);pooled[i:i+len(seqs)]=p
            if key=='prot':tokens[i:i+len(seqs)]=0;tokens[i:i+len(seqs),:t.shape[1]]=t
            if (i//16)%100==0 or i+16>=len(df):
                pooled.flush()
                if key=='prot':tokens.flush()
                write_json(statepath,{'next_row':min(i+16,len(df)),'n':len(df),'updated':stamp()})
                print('EXTRACT',key,min(i+16,len(df)),len(df),flush=True)
        del model;gc.collect();torch.cuda.empty_cache();pooled.flush()
        if key=='prot':tokens.flush();del tokens
        del pooled
        write_json(done,{'sha256':sha256(dest/f'{key}.npy'),'n':len(df),'code_sha256':sha256(__file__)})
    if not (dest/'physics_complete.json').exists():
        np.save(dest/'phys.npy',phys_raw(df.Sequence));pse=[]
        for i,s in enumerate(df.Sequence):
            pse.append(compute_pseaac(s))
            if i%5000==0:print('PSEAAC',i,len(df),flush=True)
        np.save(dest/'pse.npy',np.asarray(pse,dtype=np.float32))
        write_json(dest/'physics_complete.json',{'n':len(df),'pse_sha256':sha256(dest/'pse.npy'),'phys_sha256':sha256(dest/'phys.npy'),'tokens_sha256':sha256(dest/'tokens.npy')})

class TokenDataset(torch.utils.data.Dataset):
    def __init__(self,split):
        self.frame=pd.read_csv(OUT/f'data/{split}.csv');self.indices=self.frame.row_id.values
        self.labels=torch.tensor(self.frame.Label.values,dtype=torch.long)
        self.tokens=np.load(OUT/'features/tokens.npy',mmap_mode='r');self.pse=np.load(OUT/'features/pse.npy',mmap_mode='r')
    def __len__(self):return len(self.frame)
    def __getitem__(self,i):
        row=int(self.indices[i]);length=int(self.frame.length.iloc[i])+2
        return torch.from_numpy(self.pse[row].copy()),torch.from_numpy(self.tokens[row].copy()),torch.arange(102)<length,self.labels[i]

def collate(items):
    pse,tokens,masks,y=torch.utils.data.default_collate(items);n=int(masks.sum(1).max())
    return pse,tokens[:,:n],masks[:,:n],y

def loaders(split,shuffle=False):
    return torch.utils.data.DataLoader(TokenDataset(split),batch_size=32 if shuffle else 64,shuffle=shuffle,collate_fn=collate,num_workers=0)

def new_head():return upstream.TokenCrossAttentionModel(**{k:ORIGINAL[k] for k in ['embedding_dim','num_heads','num_layers','dropout']}).cuda()

def train_baseline(seed):
    dest=OUT/f'results/ppsamp/seed_{seed}';dest.mkdir(parents=True,exist_ok=True)
    if (dest/'frozen.json').exists():return
    setup(seed);tr=loaders('train',True);va=loaders('val');y=tr.dataset.labels.numpy()
    criterion=torch.nn.CrossEntropyLoss(weight=torch.tensor([1.,(y==0).sum()/(y==1).sum()],dtype=torch.float32,device='cuda'))
    model=new_head();opt=torch.optim.AdamW(model.parameters(),lr=ORIGINAL['lr'],weight_decay=ORIGINAL['weight_decay'])
    scheduler=torch.optim.lr_scheduler.ReduceLROnPlateau(opt,mode='max',factor=.5,patience=5)
    upstream.tqdm=functools.partial(upstream.tqdm,disable=True)
    best=-1.;stale=0;history=[];start=time.time()
    for epoch in range(1,ORIGINAL['epochs']+1):
        loss=upstream.train_epoch(model,tr,opt,criterion,'cuda')
        tm=upstream.evaluate(model,tr,'cuda',criterion);vm=upstream.evaluate(model,va,'cuda',criterion)
        scheduler.step(vm['f1']);history.append({'epoch':epoch,'train_loss':loss,'train_f1':tm['f1'],'val_f1':vm['f1'],'val_auc':vm['auc']})
        if vm['f1']>best:
            best=vm['f1'];best_epoch=epoch;stale=0;torch.save(model.state_dict(),dest/'model.pt')
            save_pred(dest/'val_predictions.csv',va.dataset.frame,vm['probs'])
        else:stale+=1
        write_json(dest/'history.json',history);print('TRAIN PPsAMP',seed,epoch,'val_f1',vm['f1'],flush=True)
        if stale>=ORIGINAL['patience']:break
    write_json(dest/'frozen.json',{'seed':seed,'best_epoch':best_epoch,'best_val_f1':best,'checkpoint_sha256':sha256(dest/'model.pt'),'seconds':time.time()-start})
    del model,tr,va;gc.collect();torch.cuda.empty_cache()

def pooled(split):
    df=pd.read_csv(OUT/f'data/{split}.csv');ix=df.row_id.values
    return df,{k:np.asarray(np.load(OUT/f'features/{k}.npy',mmap_mode='r')[ix],dtype=np.float64 if k!='phys' else np.float32) for k in ['prot','esm','phys']}

def train_dual():
    dest=OUT/'results/dual64_phys';dest.mkdir(parents=True,exist_ok=True)
    tr,r=pooled('train');va,v=pooled('val')
    with threadpool_limits(limits=4):
        if (dest/'transforms.joblib').exists():tf=joblib.load(dest/'transforms.joblib')
        else:tf=fit_transform(r,VARIANT);joblib.dump(tf,dest/'transforms.joblib')
        x=transform(r,tf,VARIANT);vx=transform(v,tf,VARIANT)
        for seed in SEEDS:
            sd=dest/f'seed_{seed}';sd.mkdir(exist_ok=True)
            if (sd/'frozen.json').exists():continue
            start=time.time();model=HistGradientBoostingClassifier(**CFG['hgb'],random_state=seed).fit(x,tr.Label)
            p=model.predict_proba(vx)[:,1];joblib.dump(model,sd/'model.joblib');save_pred(sd/'val_predictions.csv',va,p)
            write_json(sd/'frozen.json',{'seed':seed,'validation':metrics(va.Label,p),'seconds':time.time()-start,'checkpoint_sha256':sha256(sd/'model.joblib')})
            print('TRAIN DUAL',seed,metrics(va.Label,p)['f1'],flush=True)

def evaluate_all():
    frozen=OUT/'frozen_before_test.json'
    files=list((OUT/'results').glob('*/seed_*/frozen.json'));assert len(files)==6
    if not frozen.exists():write_json(frozen,{'time':stamp(),'protocol_sha256':sha256(OUT/'protocol.json'),'files':{str(p.relative_to(OUT)):sha256(p) for p in (OUT/'results').rglob('*') if p.suffix in ['.pt','.joblib']}})
    te,r=pooled('test');tf=joblib.load(OUT/'results/dual64_phys/transforms.joblib')
    with threadpool_limits(limits=4):tx=transform(r,tf,VARIANT)
    loader=loaders('test');loss=torch.nn.CrossEntropyLoss();rows=[]
    for name in ['ppsamp','dual64_phys']:
        for seed in SEEDS:
            sd=OUT/f'results/{name}/seed_{seed}';pred=sd/'test_predictions.csv'
            if not pred.exists():
                if name=='ppsamp':
                    model=new_head();model.load_state_dict(torch.load(sd/'model.pt',weights_only=True,map_location='cuda'))
                    p=upstream.evaluate(model,loader,'cuda',loss)['probs'];del model;torch.cuda.empty_cache()
                else:
                    with threadpool_limits(limits=4):p=joblib.load(sd/'model.joblib').predict_proba(tx)[:,1]
                save_pred(pred,te,p)
            predictions=pd.read_csv(pred);assert predictions.sequence.tolist()==te.Sequence.tolist();p=predictions.probability_amp.values
            for lo,hi in [(10,100),(10,30),(31,50),(51,100)]:
                mask=te.length.between(lo,hi).values
                if te.Label[mask].nunique()!=2:continue
                m=metrics(te.Label.values[mask],p[mask]);rows.append({'model':name,'seed':seed,'length':f'{lo}-{hi}','n':int(mask.sum()),**{k:v for k,v in m.items() if k!='confusion'}})
    table=pd.DataFrame(rows);table.to_csv(OUT/'metrics.csv',index=False)
    summary=table.groupby(['model','length'])[['f1','mcc','auc','average_precision','accuracy','precision','recall','specificity']].agg(['mean','std']);summary.to_csv(OUT/'summary.csv')
    # Paired cluster bootstrap of three-seed mean F1 difference. No model reselection.
    groups,gi=np.unique(te.group.values,return_inverse=True);counts=np.zeros((2,3,len(groups),3))
    for m,name in enumerate(['ppsamp','dual64_phys']):
        for j,seed in enumerate(SEEDS):
            p=pd.read_csv(OUT/f'results/{name}/seed_{seed}/test_predictions.csv').probability_amp.values>.5;y=te.Label.values==1
            for k,flag in enumerate([p&y,p&~y,~p&y]):counts[m,j,:,k]=np.bincount(gi,weights=flag,minlength=len(groups))
    rng=np.random.default_rng(20261102);deltas=[]
    for _ in range(2000):
        ix=rng.integers(0,len(groups),len(groups));c=counts[:,:,ix,:].sum(2);f1=2*c[:,:,0]/np.maximum(2*c[:,:,0]+c[:,:,1]+c[:,:,2],1)
        deltas.append(float(f1[1].mean()-f1[0].mean()))
    ci=np.quantile(deltas,[.025,.975]).tolist();write_json(OUT/'paired_statistics.json',{'method':'paired homology-component bootstrap; three-seed mean F1 difference','n_bootstrap':2000,'f1_delta_95ci':ci})
    lines=['# BATTLE-AMP 第二数据集重新训练结果','',f'完成：{stamp()}','',
      '范围10–100 aa；保留与原PPsAMP重合序列；相同新划分；3个种子；阈值0.5。此为扩展长度后的重新训练，不能称为原短肽模型零样本泛化。','',
      '| 长度 | PPsAMP F1均值 | 改进模型F1均值 | 提升百分点 |','|---|---:|---:|---:|']
    means=table.groupby(['model','length']).f1.mean()
    for length in ['10-100','10-30','31-50','51-100']:
        a=means.loc[('ppsamp',length)];b=means.loc[('dual64_phys',length)];lines.append(f'| {length} | {a:.4f} | {b:.4f} | {(b-a)*100:+.3f} |')
    lines+=['',f'整体F1差值的配对分组bootstrap 95%区间：[{ci[0]*100:.3f}, {ci[1]*100:.3f}] 个百分点。',
      '', '限制：作者适配ProtBERT的历史监督训练范围不完整；阴性标签不等于实验确认无活性；MMseqs2为启发式相似性搜索。',
      '', '详见 protocol.json、data/audit.json、parity.json、metrics.csv、summary.csv、paired_statistics.json 和每次训练的 history.json。']
    (OUT/'RESULTS.md').write_text('\n'.join(lines)+'\n');print('EVALUATION COMPLETE',flush=True)

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--stage',choices=['prepare','parity','all'],default='all');args=parser.parse_args()
    OUT.mkdir(exist_ok=True);lock=open(OUT/'runner.lock','w');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
    setup();freeze_protocol()
    tasks=[('01_prepare',prepare),('02_parity',parity),('03_features',extract)]
    tasks += [(f'04_baseline_{seed}',functools.partial(train_baseline,seed)) for seed in SEEDS]
    tasks += [('05_dual',train_dual),('06_evaluate_and_report',evaluate_all)]
    if args.stage!='all':tasks=[(k,f) for k,f in tasks if k==('01_prepare' if args.stage=='prepare' else '02_parity')]
    path=OUT/'status.json';state=json.loads(path.read_text()) if path.exists() else {'tasks':{}}
    state.update(status='running',pid=os.getpid(),updated=stamp(),mode='strictly_serial_files_only_no_polling');write_json(path,state)
    for key,fn in tasks:
        if state['tasks'].get(key,{}).get('status')=='complete':continue
        state['current_task']=key;state['tasks'][key]={'status':'running','started':stamp()};write_json(path,state);print('START',key,stamp(),flush=True)
        try:fn()
        except Exception as e:
            state['tasks'][key].update(status='failed',error=str(e),finished=stamp());state.update(status='failed',updated=stamp());write_json(path,state);raise
        state['tasks'][key].update(status='complete',finished=stamp());state['updated']=stamp();write_json(path,state);print('END',key,flush=True)
    state.update(status='complete' if args.stage=='all' else 'preflight_complete',current_task=None,updated=stamp());write_json(path,state)

if __name__=='__main__':main()
