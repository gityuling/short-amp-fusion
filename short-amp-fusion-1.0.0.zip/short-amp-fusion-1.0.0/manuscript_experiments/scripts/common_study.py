from pathlib import Path
import sys,json,time
ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'optimization'))
from run_phase1 import setup,sha256,write_json,metrics,ASSETS,FEATURES,AA_PROPERTIES,AA_TO_IDX
import numpy as np,pandas as pd,torch,h5py,joblib
BASE=ROOT/'manuscript_experiments'
CFG=json.loads((BASE/'protocols/study.json').read_text())

def phys_raw(sequences):
    props=(AA_PROPERTIES-AA_PROPERTIES.mean(1,keepdims=True))/AA_PROPERTIES.std(1,keepdims=True)
    result=[]
    for seq in sequences:
        ix=np.array([AA_TO_IDX[a] for a in seq]); p=props[:,ix].T
        result.append(np.concatenate([np.bincount(ix,minlength=20)/len(ix),p.mean(0),p.std(0),[len(ix)/30]]))
    return np.asarray(result,dtype=np.float32)

def raw_official(split):
    dest=BASE/'data'/f'official_{split}_pooled.npz'
    frame=pd.read_csv(ASSETS/'data'/f'{split}_dedup_split.csv')
    if dest.exists():
        z=np.load(dest);assert z['sequences'].tolist()==frame.Sequence.tolist();return frame,dict(z)
    chunks=[]
    with h5py.File(FEATURES/f'{split}_tokens.h5') as h:
        assert h['sequences'].asstr()[:].tolist()==frame.Sequence.tolist()
        for start in range(0,len(frame),128):
            t=torch.from_numpy(h['embeddings'][start:start+128]); lens=torch.tensor(frame.Sequence.iloc[start:start+128].str.len().values)
            t30=t[:,1:31]; mask=(torch.arange(30)[None,:]<lens[:,None]).unsqueeze(-1)
            mean=(t30*mask).sum(1)/lens[:,None];maximum=t30.masked_fill(~mask,-torch.inf).max(1).values
            chunks.append(torch.cat([t[:,0],mean,maximum],1).numpy())
    ep=ROOT/'optimization/features/esm2_150m'/f'{split}.npz' if split!='test' else ROOT/'optimization/stage2_official_evaluation/test_esm_features.npz'
    e=np.load(ep)
    assert e['sequences'].tolist()==frame.Sequence.tolist()
    data={'prot':np.concatenate(chunks).astype(np.float64),'esm':e['embeddings'].astype(np.float64),'phys':phys_raw(frame.Sequence),'labels':frame.Label.values,'sequences':frame.Sequence.values.astype(str)}
    np.savez(dest,**data)
    write_json(dest.with_suffix('.json'),{'sha256':sha256(dest),'source_csv_sha256':sha256(ASSETS/'data'/f'{split}_dedup_split.csv'),'esm_sha256':sha256(ep),'prot_tokens_sha256':sha256(FEATURES/f'{split}_tokens.h5')})
    return frame,data

def transform(raw,tf,cfg):
    parts=[]
    for key in ['esm','prot']:
        if cfg[key]:
            z=raw[key]
            if cfg['pool']=='mean':d=z.shape[1]//3;z=z[:,d:2*d]
            parts.append(tf[key]['pca'].transform(tf[key]['scaler'].transform(z)))
    if cfg['phys']!='none':
        x=(raw['phys']-tf['phys'][0])/tf['phys'][1]
        parts.append(x if cfg['phys']=='full' else x[:,list(range(20))+[60]])
    return np.concatenate(parts,axis=1)

def fit_transform(raw,cfg):
    from sklearn.preprocessing import StandardScaler
    from sklearn.decomposition import PCA
    tf={'phys':(raw['phys'].mean(0),np.maximum(raw['phys'].std(0),1e-6))}
    for key in ['esm','prot']:
        if cfg[key]:
            x=raw[key]
            if cfg['pool']=='mean':d=x.shape[1]//3;x=x[:,d:2*d]
            sc=StandardScaler();pca=PCA(n_components=cfg[key],svd_solver='randomized',random_state=42,iterated_power=3)
            pca.fit(sc.fit_transform(x));tf[key]={'scaler':sc,'pca':pca}
    return tf

def save_pred(path,frame,p):
    pd.DataFrame({'sequence':frame.Sequence,'label':frame.Label,'probability_amp':p}).to_csv(path,index=False)

class MLP(torch.nn.Module):
    def __init__(self,d):
        super().__init__();self.net=torch.nn.Sequential(torch.nn.Linear(d,128),torch.nn.ReLU(),torch.nn.Dropout(.3),torch.nn.Linear(128,1))
    def forward(self,x):return self.net(x).flatten()
