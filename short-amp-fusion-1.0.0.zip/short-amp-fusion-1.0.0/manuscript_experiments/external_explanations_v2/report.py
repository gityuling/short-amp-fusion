"""Offline reviewed summaries, a deterministic evidence control, and figures.

Activity labels are joined here only, after the agent workflow has finished.
The baseline is a mechanical evidence-card reference, not an independent
measure of narrative/scientific quality or an agent-performance benchmark.
"""
from pathlib import Path
import os
os.environ.setdefault('MPLBACKEND','Agg')
import json, csv, datetime, sys, collections, hashlib
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
OLD=ROOT/'manuscript_experiments/external_agent_three_v1'
sys.path.insert(0,str(HERE))
import agent
NAMES={'ESM2':'ESM2表征','ProtBERT':'ProtBERT表征','Descriptors':'组成、理化统计与长度'}

def fixed_report(cid):
    evidence={v['evidence_id']:v for v in agent.packets(cid).values()}
    g=evidence['G']; dominant=g['dominant_source']
    expected='decrease' if g['groups'][dominant]['contribution_mean_score']>0 else 'increase'
    evidence['T']=agent.source_test(cid,dominant,expected)
    paths=[('P','/mean_score'),('G','/baseline_mean_score'),
           *[('G',f'/groups/{s}/contribution_mean_score') for s in NAMES],
           ('D','/top_features/0/mean_shap_logodds'),('S','/shuffle_mean_absolute_delta'),
           ('O','/origin_status'),('T','/observed_delta')]
    facts=[{'evidence_id':e,'path':p,'value':agent.prior.pointer(evidence[e],p)} for e,p in paths]
    report={'answer':'固定流程直接整理所有工具结果，按贡献绝对值最大输入块进行方向检查；不生成自由生物学推断。',
        'claims':[{'statement':'该字段由已存工具事实直接生成：'+f['path'],'evidence_ids':[f['evidence_id']]} for f in facts[:4]],
        'facts':facts,
        'conclusion':{'dominant_source':dominant,
            'source_directions':{s:d['direction'] for s,d in g['groups'].items()},
            'shuffle_mean_absolute_delta':evidence['S']['shuffle_mean_absolute_delta'],
            'origin_status':evidence['O']['origin_status'],'source_test_verdict':evidence['T']['verdict'],
            'activity_status':'not_assessed'},
        'limitations':['仅为确定性证据卡与规则参照，不具备自由文本科学判断能力。'],
        'next_step':'核查模型行为证据与生物学验证之间仍存在的缺口。'}
    assert not agent.validate(report,evidence)
    return {'case_id':cid,'report':report,'evidence':evidence,'checks_passed':True,
            'llm_api_calls':0,'rule':'Choose largest absolute primary group Shapley; replacement predicted to reverse its signed contribution.',
            'timing':'Constructed offline from existing tools after computations; not prospective validation.'}

def figures(group, variants, summary):
    plt.rcParams.update({'font.size':10,'pdf.fonttype':42,'ps.fonttype':42})
    cids=[f'C{i:02}' for i in range(1,13)]
    prim=group[group.reference=='primary'].pivot(index='case_id',columns='source',values='contribution_mean_score').loc[cids,list(NAMES)]
    yy=np.arange(12)
    fig,axes=plt.subplots(1,3,figsize=(15,7.3),gridspec_kw={'width_ratios':[1.1,1.25,1.15]})
    ax=axes[0]; mat=prim.values*100
    lim=max(10,float(np.abs(mat).max()))
    im=ax.imshow(mat,cmap='RdBu_r',vmin=-lim,vmax=lim,aspect='auto')
    for i in range(12):
        for j in range(3):
            ax.text(j,i,f'{mat[i,j]:+.1f}',ha='center',va='center',color='white' if abs(mat[i,j])>lim*.55 else '#111111',fontsize=10)
    ax.set_xticks(range(3),['ESM2','ProtBERT','Descriptors']);ax.set_yticks(yy,cids)
    ax.set_title('A  Source contributions',loc='left',fontweight='bold',pad=14)
    ax=axes[1]
    sh=summary[summary.kind=='shuffle'].set_index('case_id').loc[cids]
    for i,(_,r) in enumerate(sh.iterrows()):
        ax.plot([r.minimum_score,r.maximum_score],[i,i],color='#a6adb5',lw=2)
        ax.plot([r.original_score,r.mean_score],[i,i],color='#64748b',lw=1)
    ax.scatter(sh.original_score,yy,s=36,color='#151e38',label='Original',zorder=3)
    ax.scatter(sh.mean_score,yy,s=42,color='#dd7c28',marker='D',label='Mean of 10 shuffles',zorder=3)
    ax.axvline(.5,color='#909090',ls='--',lw=1)
    ax.set_xlim(-.03,1.03);ax.set_ylim(11.5,-.5);ax.set_yticks(yy,cids)
    ax.set_xlabel('Frozen fusion score');ax.grid(axis='x',alpha=.15)
    ax.set_title('B  Order sensitivity at fixed composition',loc='left',fontweight='bold',pad=14)
    ax.legend(loc='lower center',bbox_to_anchor=(.5,-.20),frameon=False,fontsize=8)
    ax=axes[2]
    aa=summary[summary.kind=='alanine'].set_index('case_id').loc[cids]
    ax.barh(yy-.17,aa.mean_absolute_delta_score*100,height=.3,color='#4388a2',label='Single-residue A scan')
    ax.barh(yy+.17,sh.mean_absolute_delta_score*100,height=.3,color='#dd7c28',label='Composition-preserving shuffle')
    ax.set_ylim(11.5,-.5);ax.set_yticks(yy,cids);ax.set_xlabel('Mean absolute score change (percentage points)')
    ax.set_title('C  Perturbation response',loc='left',fontweight='bold',pad=14)
    ax.grid(axis='x',alpha=.15);ax.legend(loc='lower center',bbox_to_anchor=(.5,-.20),frameon=False,fontsize=8)
    for ax in axes:
        for boundary in [3.5,7.5]:ax.axhline(boundary,color='#667085',lw=.7,ls=':')
        ax.spines[['top','right']].set_visible(False)
    fig.suptitle('Twelve external cases: source attribution and model-behaviour checks',fontsize=15,y=.98)
    fig.text(.5,.025,'C01–C04: SEP   |   C05–C08: Archaeasin   |   C09–C12: APEX\nAll results use three frozen seeds. Perturbations measure classifier response, not experimental antimicrobial activity.',ha='center',fontsize=9)
    fig.subplots_adjust(left=.05,right=.985,top=.88,bottom=.22,wspace=.32)
    pos=axes[0].get_position()
    cax=fig.add_axes([pos.x0,.12,pos.width,.025])
    cb=fig.colorbar(im,cax=cax,orientation='horizontal')
    cb.set_label('Score percentage points relative to training reference',fontsize=8)
    fig.savefig(HERE/'model_behaviour.png',dpi=180)
    fig.savefig(HERE/'model_behaviour.pdf')
    plt.close(fig)

def main():
    status=json.loads((HERE/'agent_status.json').read_text())
    assert status['stage']=='finished','Do not join assay outcomes before agent completion'
    cases=json.loads((OLD/'data/agent_cases_LOCAL.json').read_text())['cases']
    old=pd.read_csv(OLD/'analysis/joint_candidate_evidence.csv').set_index('case_id')
    group=pd.read_csv(HERE/'source_contributions.csv')
    variants=pd.read_csv(HERE/'sequence_tests_LOCAL.csv')
    sensitivity=pd.read_csv(HERE/'sequence_sensitivity.csv')
    descriptors=pd.read_csv(HERE/'descriptor_contributions.csv')
    reviewpath=HERE/'semantic_review.json'
    reviews=json.loads(reviewpath.read_text()) if reviewpath.exists() else {}
    evaluations=[]; fixed=[]; cardlines=[]; joined=[]; usage=collections.Counter(); totalcalls=0
    group_disagreements=0
    for case in cases:
        cid=case['case_id']; f=fixed_report(cid);fixed.append(f)
        ev=f['evidence']; p,g,d,s,o=map(ev.get,['P','G','D','S','O'])
        rpath=HERE/'agent_output'/cid/'result.json'
        result=json.loads(rpath.read_text()) if rpath.exists() else None
        review=reviews.get(cid,{})
        valid=bool(result and result['checks_passed'])
        forecast=result['evidence'].get('T',{}) if result else {}
        calls=result.get('api_calls',[]) if result else []
        if result is None:
            ep=HERE/'agent_output'/cid/'error.json'
            if ep.exists():calls=json.loads(ep.read_text()).get('api_calls',[])
        totalcalls+=len(calls)
        for c in calls:
            usage.update({k:v for k,v in c.get('usage',{}).items() if isinstance(v,int)})
        evaluations.append({'case_id':cid,'completed':bool(result),'strict_fact_checks_passed':valid,
            'first_pass':bool(result and result['first_pass']),
            'agent_selected_group':forecast.get('group'), 'agent_source_test':forecast.get('verdict'),
            'fixed_rule_group':f['evidence']['T']['group'],'fixed_rule_source_test':f['evidence']['T']['verdict'],
            'same_group_as_rule':forecast.get('group')==f['evidence']['T']['group'],
            'agent_api_calls':len(calls),'agent_seconds':result.get('elapsed_seconds') if result else None,
            'semantic_status':review.get('status','pending'),
            'semantic_notes':' | '.join(review.get('notes',[]))})
        label=int(old.loc[cid,'published_activity_POSTHOC'])
        top=d['top_features'][0]
        unstable=[name for name,item in g['groups'].items() if not item['reference_sign_agrees']]
        group_disagreements+=len(unstable)
        a=variants[(variants.case_id==cid)&(variants.kind=='alanine')]
        row={'case_id':cid,'cohort':case['cohort'],'source_id':case['id'],
            'model_score':p['mean_score'],'length_aa':p['length_aa'],
            'published_activity_POSTHOC':label,'dominant_source':g['dominant_source'],
            'top_explicit_feature':top['feature'],'top_explicit_shap_logodds':top['mean_shap_logodds'],
            'shuffle_mean_abs_delta':s['shuffle_mean_absolute_delta'],
            'shuffle_mean_delta':s['shuffle_mean_delta'],'shuffle_flips':s['shuffle_flip_count'],
            'alanine_flips':s['alanine_flip_count'],'origin_status':o['origin_status'],
            'unstable_reference_sources':'|'.join(unstable),
            **{name+'_score_contribution':item['contribution_mean_score'] for name,item in g['groups'].items()}}
        joined.append(row)
        origin=o['origin_check']
        if o['kind']=='metagenomic_smORF':
            source_line='公开表内DNA按指定遗传密码表翻译后与候选肽一致。来源物种为文献基因注释；档案样本为'+str(o.get('sample_level',{}).get('scientific_name'))+'，两者属于不同层级。'
        else:
            source_line=f"母蛋白{origin.get('parent_accession')}准确包含候选片段；起始位置{origin.get('start_positions_1based')}，结束位置{origin.get('end_positions_1based')}（1-based，包含端点）。"
        seed_unstable=[name for name,item in g['groups'].items() if min(item['contributions_by_seed'])*max(item['contributions_by_seed'])<0]
        reviewed=(f'该候选的冻结分类分数为{p["mean_score"]:.6f}。相对64条训练参考，贡献绝对值最大的是{NAMES[g["dominant_source"]]}；'
            f'其组贡献为{g["groups"][g["dominant_source"]]["contribution_mean_score"]:+.6f}分类分数单位。'
            f'显式特征中长度归因绝对值最大，平均Tree SHAP为{top["mean_shap_logodds"]:+.4f} log-odds。'
            f'保持长度和全部显式描述符不变的10次打乱，平均绝对分数变化为{s["shuffle_mean_absolute_delta"]:.6f}，其中{s["shuffle_flip_count"]}次跨越阈值；'
            '这说明该模型在这些扰动下如何响应顺序变化。'+source_line+
            '来源核对与模型解释分别提供证据；新扰动序列未测活性。')
        if unstable:reviewed+='更换等长参考后，'+ '、'.join(NAMES[n] for n in unstable)+'的贡献符号改变。'
        if seed_unstable:reviewed+='三个种子间，'+ '、'.join(NAMES[n] for n in seed_unstable)+'的贡献符号不一致。'
        cardlines.extend([f'【{cid}｜{case["cohort"]}｜{case["id"]}】',
            '复核版解释：'+reviewed,
            f'1. 模型判断：分数{p["mean_score"]:.6f}；三个种子为'+', '.join(f'{v:.6f}' for v in p['seed_scores'])+f'；长度{p["length_aa"]} aa。分类阈值0.5，分数不是活性概率。',
            f'2. 输入依据：参考分数{g["baseline_mean_score"]:.6f}；'+ '，'.join(f'{NAMES[name]}贡献{item["contribution_mean_score"]:+.6f}' for name,item in g['groups'].items())+'；加总还原模型分数。',
            '   贡献绝对值最大：'+NAMES[g['dominant_source']]+'。更换为等长训练背景后符号变化的输入块：'+('、'.join(NAMES[n] for n in unstable) if unstable else '无')+'。',
            '3. 显式特征：'+'；'.join(f'{t["feature"]}，原始特征值{t["raw_value"]:.4f}，平均SHAP {t["mean_shap_logodds"]:+.4f} log-odds' for t in d['top_features'][:3])+'。',
            f'4. 顺序检验：10次打乱均保持长度与全部61个显式描述符不变；分数范围{s["shuffle_minimum_score"]:.6f}–{s["shuffle_maximum_score"]:.6f}，平均变化{s["shuffle_mean_delta"]:+.6f}，平均绝对变化{s["shuffle_mean_absolute_delta"]:.6f}，分类翻转{s["shuffle_flip_count"]}/10。',
            f'   单A替换：共{s["alanine_scan_n"]}个非A位点，平均绝对分数变化{s["alanine_mean_absolute_delta"]:.6f}；翻转{s["alanine_flip_count"]}/{s["alanine_scan_n"]}。这些是模型诊断，不是活性或残基机制结论。',
            '   最大响应位点：'+'；'.join(f'第{t["position_1based"]}位，变化{t["delta_score"]:+.6f}' for t in s['top_alanine_positions'])+'。',
            '5. 来源核验：'+source_line,
            '   来源注释：'+str(o['reported_gene_or_parent_source']),
            '   表达证据：'+str(o['expression_evidence'].get('expression_note')),
            '6. 智能体方向检查：'+(f'选择{forecast["group"]}，事先预期{forecast["predicted_change"]}，观察变化{forecast["observed_delta"]:+.6f}，判定{forecast["verdict"]}。' if forecast else '未完成。'),
            f'7. 原论文实验（智能体运行后接入）：{("在原受试条件下有活性" if label else "在原受试条件下未显示活性")}。这只是回顾性核对；新扰动序列没有实验标签。',
            '8. 原始智能体报告：'+(result['report'].get('answer','') if result and result.get('report') else '未产生有效报告。'),
            '9. 科学语义复核：'+review.get('status','pending')+'；'+'；'.join(review.get('notes',[])),
            ''])
    pd.DataFrame(joined).to_csv(HERE/'case_summary.csv',index=False)
    pd.DataFrame(evaluations).to_csv(HERE/'agent_evaluation.csv',index=False)
    agent.write(HERE/'fixed_workflow_control.json',fixed)
    (HERE/'CASEBOOK_REVIEWED.txt').write_text('十二例解释证据册\n事实卡由已核验工具数值直接生成；保留DeepSeek原文和另列复核意见。原实验标签仅事后连接。\n\n'+'\n'.join(cardlines))
    frame=pd.DataFrame(joined); evaluation=pd.DataFrame(evaluations)
    checks=json.loads((HERE/'COMPUTATION_VERIFICATION.json').read_text())
    top_all_length=int((frame.top_explicit_feature=='length_div30').sum())
    totalcalls=int(totalcalls)
    summary={'cases':12,'alanine_substitutions':checks['alanine_substitutions'],
        'shuffles':checks['composition_preserving_shuffles'],
        'dominant_sources':dict(collections.Counter(frame.dominant_source)),
        'largest_explicit_feature_is_length_n':top_all_length,
        'group_reference_sign_disagreements':group_disagreements,'group_reference_comparisons':36,
        'cases_with_shuffle_classification_flips':int((frame.shuffle_flips>0).sum()),
        'cases_with_alanine_classification_flips':int((frame.alanine_flips>0).sum()),
        'agent_completed':int(evaluation.completed.sum()),'agent_strict_passed':int(evaluation.strict_fact_checks_passed.sum()),
        'agent_first_pass':int(evaluation.first_pass.sum()),'agent_source_tests':dict(collections.Counter(evaluation.agent_source_test.dropna())),
        'fixed_rule_source_tests':dict(collections.Counter(evaluation.fixed_rule_source_test)),
        'agent_same_group_as_rule':int(evaluation.same_group_as_rule.sum()),
        'semantic_review_status':dict(collections.Counter(evaluation.semantic_status)),
        'api_calls':totalcalls,'usage':dict(usage),
        'independent_human_review':False,'new_activity_experiments':False,
        'agent_superiority_demonstrated':False,
        'code_sha256':agent.sha(Path(__file__))}
    agent.write(HERE/'SUMMARY.json',summary)
    lines=[
        '十二例外部候选：模型解释、扰动核验与DeepSeek证据整合',
        '日期：2026-11-15。该分析为同一批已观察案例的回顾性解释性扩展。',
        '',
        '一、完成内容',
        '保留此前12例（每篇论文4例），沿用冻结融合模型的3个种子；不训练、不调阈值、不按新解释结果重新挑选案例。本轮不进行PPsAMP分数比较。',
        f'完成精确3输入块归因（全部8种组合）、189特征Tree SHAP、{checks["alanine_substitutions"]}次单A替换、120次保持组成与长度的打乱，以及已有来源证据的重用与分层展示。',
        f'原始预测误差{checks["prediction_parity_error"]}；重新提取原序列表征后的分数误差{checks["original_reembedding_score_error"]}；归因加和误差{checks["coalition_additivity_max_error"]:.3g}。',
        '',
        '二、可以报告的模型行为发现',
        '1. 三类输入的贡献方向依候选而变。按主参考下贡献绝对值最大计算：'+str(summary['dominant_sources'])+'。贡献按三种子平均分类分数计量，不能写成抗菌机制贡献百分比。',
        f'2. 长度是{top_all_length}/12例中绝对Tree SHAP值最大的显式特征（仅61个显式特征内比较）。这提示长度依赖，不能把所有理化贡献都包装成机制发现。',
        f'3. 更换为等长训练参考后，36个“案例×输入块”中有{group_disagreements}项贡献符号改变。说明归因有参考依赖；主要与敏感性结果一并展示。',
        f'4. 长度和组成不变时，{summary["cases_with_shuffle_classification_flips"]}/12例在10次打乱中至少一次跨越0.5阈值；单A替换有{summary["cases_with_alanine_classification_flips"]}/12例至少一次跨阈值。顺序信息确实影响模型，但敏感性不保证判断正确。',
        '',
        '重点例子：',
        'C01原分数0.788908，打乱后平均分数约0.437519；5/10次跨阈值。组成保持不变，因此仅靠组成不能解释该模型行为。',
        'C06原分数0.017038，打乱后平均约0.660486；8/10次跨阈值。原论文原肽实测阳性，该案例同时展示模型漏检与顺序敏感性，不能宣称打乱改善了实际抗菌活性。',
        'C08原分数0.995891，单A替换平均绝对分数变化约0.001130，打乱后分数均高于0.9。在本批诊断中对这些扰动较稳定。',
        'C09原分数0.974486，来源匹配，单A替换与10次打乱均未改变阳性分类；但原实验阴性。稳定解释和正确来源不能消除模型误报。',
        '',
        '三、智能体作用与实际表现',
        'DeepSeek根据问题调用6类证据工具；在看到归因后先选一个输入块并预测替换方向，再查询实际分数变化。工具使用真实冻结模型计算；来源核验复用先前的原始档案，记录重用，未假装重新获取。',
        f'完成{summary["agent_completed"]}/12；严格数值、类型、方向和证据指针检查通过{summary["agent_strict_passed"]}/12；首次通过{summary["agent_first_pass"]}/12。',
        '智能体方向预期与同模型替换检查：'+str(summary['agent_source_tests'])+'。固定规则参照：'+str(summary['fixed_rule_source_tests'])+'。',
        f'智能体在{summary["agent_same_group_as_rule"]}/12例选择了与“最大绝对归因”规则相同的输入块。该方向检验共享归因的模型、背景和组合计算，不能当独立验证，更不能当活性预测准确率。',
        f'共{totalcalls}次API调用，token记录{dict(usage)}。实际别名以响应为准，不宣称不可变的DeepSeek v4.1权重版本。',
        '科学语义复核：'+str(summary['semantic_review_status'])+'。机器事实检查不能替代逐条科学语义核对。复核由Codex完成，不是独立人工盲评。',
        '固定流程直接复制同样的数值证据就能生成完整事实卡。本轮没有证明智能体超过固定流程；其展示价值是组织、解释并核查证据，不能据此声称自主科学发现。',
        '',
        '四、论文中适合的定位',
        '可作为“外部候选的模型行为解释与来源证据整合”小节：展示信息依赖、扰动响应、来源链及失败案例。先陈述实际模型行为，再说明智能体如何调用并整合这些证据。',
        '12例为已有两模型分数分层抽样的探索性案例，当前研究人员已经知道原实验结果。LLM工具不接入标签和原始序列，但公开出处可能在其训练中出现；不宣称前瞻或严格盲测。',
        '未验证新候选活性、抗菌机制、临床适用性或天然释放。编码器先前训练暴露仍有未解之处。合成肽测试不以天然切割已证实为必要条件。',
        '',
        '文件：CASEBOOK_REVIEWED.txt为逐例说明；case_summary.csv为联合表；source_contributions.csv、descriptor_contributions.csv和sequence_tests_LOCAL.csv保留完整计算；agent_output保留逐轮请求、响应、工具记录、原始报告和修复记录；PROTOCOL.json/AGENT_PROTOCOL.json记录参数与哈希。']
    (HERE/'RESULTS_REVIEWED.txt').write_text('\n'.join(lines)+'\n')
    figures(group,variants,sensitivity)
    (HERE/'FIGURE_CAPTION.txt').write_text(
        'Figure. Frozen-model explanation of 12 external peptide cases. '
        '(A) Exact three-block Shapley values for the arithmetic mean of three frozen classifier scores, '
        'using 64 uniformly sampled training sequences as the common reference and enumerating all eight feature-block coalitions. '
        'Values are score percentage points; positive values raise the score relative to the reference mean, '
        'not percentages of biological contribution. Missing blocks are jointly replaced from the same donor; retained/replaced hybrids can break inter-block dependencies. '
        '(B) Original score (dark circle) and mean score after 10 distinct composition- and length-preserving shuffles (orange diamond). '
        'Gray intervals show the minimum-to-maximum shuffle scores, NOT confidence intervals. '
        'The dashed vertical line marks the fixed 0.5 classification threshold. '
        '(C) Mean absolute score change over all non-A to A single-residue substitutions and over the 10 shuffles, in score percentage points. '
        'All embeddings and descriptors were recomputed for each synthetic input. Explicit descriptors are exactly unchanged by shuffling. '
        'There are 224 substitutions and 120 shuffles in total. The same 12 cases were retained from the earlier score-stratified pilot, '
        'with four cases from each source. These diagnostics measure model behaviour and do not establish antimicrobial activity of the perturbed sequences.\n')
    (HERE/'README.txt').write_text('复现顺序与交付说明\n\n'
        '1. 使用项目现有.venv。analyze.py只读取旧12例、冻结模型、已有编码器与训练参考，计算归因和扰动。无需下载新数据。\n'
        '2. 主模型、编码器与来源数据下载方式沿用reproduction/README.md以及external_agent_three_v1/DOWNLOAD_AND_REPRODUCE.txt。新目录不复制checkpoint。\n'
        '3. 运行：.venv/bin/python manuscript_experiments/external_explanations_v2/analyze.py\n'
        '4. agent.py读取本机原有密钥配置；不把密钥写入协议、日志或请求体。会发生实际API调用；完整结果存在时复用，部分失败禁止静默付费重跑。\n'
        '   .venv/bin/python manuscript_experiments/external_explanations_v2/agent.py\n'
        '5. 复核原始报告并维护semantic_review.json，然后离线运行report.py和verify.py。\n'
        '6. 参数：三种子42/43/44，阈值0.5，主训练参考64条/RNG20261112，等长参考最多64条/RNG20261115+案例序号；全非A位点单A替换；每例10次组成保持打乱；编码器batch16/max_tokens32。\n'
        '7. LLM：deepseek-flash官方API，temperature0，thinking disabled，每例最多8轮/6工具，每轮最多3工具，输出上限4000 token，最多一次报告修复，无自动API重试。别名不等于固定模型版本。\n'
        '8. 结果局限及归因单位见RESULTS_REVIEWED.txt。先前案例来源与下载协议沿用旧目录，原模型与原报告保持不变。\n')
    print(json.dumps(summary,ensure_ascii=False,indent=2),flush=True)

if __name__=='__main__':
    main()
