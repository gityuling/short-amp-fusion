"""Frozen 12-case model-behaviour analysis, with no outcome labels or fitting.

Exact three-block Shapley values explain the mean probability score. Tree SHAP
describes individual features in per-model log-odds. Sequence interventions are
diagnostics, not an activity optimization or a biological mechanism experiment.
"""
from pathlib import Path
import os
os.environ.setdefault('OMP_NUM_THREADS', '4')
os.environ.setdefault('OPENBLAS_NUM_THREADS', '4')
import sys, json, hashlib, datetime, math, time, traceback
HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
OLD = ROOT / 'manuscript_experiments/external_agent_three_v1'
INTERP = ROOT / 'manuscript_experiments/interpretability_v1'
sys.path.insert(0, str(INTERP / 'deps'))
sys.path.insert(0, str(ROOT / 'manuscript_experiments/scripts'))
from external_inference import extract, ensure_parity
from common_study import raw_official, transform, CFG, phys_raw, setup
import numpy as np
import pandas as pd
import joblib, shap, torch
from threadpoolctl import threadpool_limits

SEEDS = [42, 43, 44]
RNG = 20261115
CORE = ROOT / 'manuscript_experiments/results/core/dual64_phys'
GROUPS = {'ESM2': (0, 64), 'ProtBERT': (64, 128), 'Descriptors': (128, 189)}

def write(path, obj):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, ensure_ascii=False, indent=2, allow_nan=False) + '\n')

def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for block in iter(lambda: f.read(8 << 20), b''):
            h.update(block)
    return h.hexdigest()

def state(stage):
    write(HERE / 'status.json', {'stage': stage, 'pid': os.getpid(),
          'updated_utc': datetime.datetime.now(datetime.timezone.utc).isoformat()})
    print(stage, flush=True)

def group_game(x, background, models):
    """All 2**3 coalitions, shared donors for missing feature blocks."""
    batches = []
    for mask in range(8):
        b = background.copy()
        for j, (lo, hi) in enumerate(GROUPS.values()):
            if mask & (1 << j):
                b[:, lo:hi] = x[lo:hi]
        batches.append(b)
    stacked = np.concatenate(batches)
    values = np.array([m.predict_proba(stacked)[:, 1].reshape(8, len(background)).mean(1)
                       for m in models])
    phi = np.zeros((3, 3))  # seed, source
    for j in range(3):
        for mask in range(8):
            if not mask & (1 << j):
                k = mask.bit_count()
                weight = math.factorial(k) * math.factorial(2-k) / math.factorial(3)
                phi[:, j] += weight * (values[:, mask | (1 << j)] - values[:, mask])
    err = float(np.abs(values[:, 0] + phi.sum(1) - values[:, 7]).max())
    assert err < 1e-12
    return values, phi, err

def direction(v, eps=1e-9):
    return 'positive' if v > eps else 'negative' if v < -eps else 'zero'

def main():
    started = time.monotonic()
    setup()
    torch.set_num_threads(4)
    ensure_parity()
    cases = json.loads((OLD / 'data/agent_cases_LOCAL.json').read_text())['cases']
    assert len(cases) == 12
    paths = [CORE / 'transforms.joblib'] + [CORE / f'seed_{s}/model.joblib' for s in SEEDS]
    inputs = [OLD / 'data/agent_cases_LOCAL.json', OLD / 'embeddings/features.npz',
              INTERP / 'feature_dictionary.csv', Path(__file__),
              ROOT / 'manuscript_experiments/scripts/external_inference.py',
              ROOT / 'manuscript_experiments/scripts/common_study.py']
    proto = {
        'created_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'purpose': 'Retrospective explanation of the same 12 cases; labels previously exposed to researchers, excluded from analysis and agent inputs.',
        'case_selection': 'Inherited all 12 cases without reselection; prior two-model score strata, not activity labels.',
        'seeds': SEEDS, 'analysis_seed': RNG, 'model': 'frozen dual64_phys',
        'fit_or_threshold_tuning': False, 'threshold': 0.5,
        'primary_group_explanation': {
            'method': 'Exact Shapley over all 8 coalitions of 3 feature blocks',
            'output': 'Mean of three frozen probability scores; not calibrated activity probability',
            'background': '64 uniform training rows, RNG 20261112, without labels',
            'donor_rule': 'All missing blocks from the same donor; same donors for every coalition and case',
            'warning': 'Hybrid feature vectors break dependence between retained and replaced blocks; attribution depends on reference, not biological causality.'},
        'group_reference_sensitivity': 'Up to 64 exactly same-length training donors per case, without labels, RNG 20261115+case_index; separate reference, not a confidence interval.',
        'descriptor_explanation': '189-feature Tree SHAP, path-dependent raw log-odds per seed; sensitivity interventional with same 64 training rows. Means of margins are not logit(mean probability).',
        'sequence_tests': {
            'alanine_scan': 'Every non-A residue independently replaced by A; original A positions excluded as no-op. All three feature blocks recomputed.',
            'shuffle': '10 distinct uniform random permutations per case, preserving full length and composition; all representations recomputed.',
            'random_seed': RNG, 'originals': 'Re-embed all 12 originals with variants; require exact score parity and near-identical features.',
            'interpretation': 'Model response to synthetic inputs only; no claims of residue necessity, improved activity, natural expression, mechanism or validated new peptides.'},
        'model_hashes': {str(p.relative_to(ROOT)): sha(p) for p in paths},
        'input_hashes': {str(p.relative_to(ROOT)): sha(p) for p in inputs},
        'software': {'numpy': np.__version__, 'shap': shap.__version__, 'torch': torch.__version__},
        'no_new_ppsamp_comparison': True,
    }
    pp = HERE / 'PROTOCOL.json'
    if pp.exists():
        previous = json.loads(pp.read_text())
        assert previous['model_hashes'] == proto['model_hashes']
        assert previous['input_hashes'] == proto['input_hashes'], 'Create a new version after changing analysis code or inputs.'
    else:
        write(pp, proto)
    state('loading frozen features and training reference')
    tf = joblib.load(paths[0])
    cfg = next(c for c in CFG['variants'] if c['name'] == 'dual64_phys')
    models = [joblib.load(p) for p in paths[1:]]
    raw = dict(np.load(OLD / 'embeddings/features.npz'))
    lookup = {s: i for i, s in enumerate(raw['sequences'].tolist())}
    idx = [lookup[c['Sequence']] for c in cases]
    original_raw = {k: raw[k][idx] for k in ['esm', 'prot', 'phys']}
    x = transform(original_raw, tf, cfg)
    tr, tr_raw = raw_official('train')
    tx = transform(tr_raw, tf, cfg)
    bgids = np.random.default_rng(20261112).choice(len(tr), 64, replace=False)
    bg = tx[bgids]
    write(HERE / 'training_reference_LOCAL.json', {'primary_row_indices': bgids.tolist(),
          'training_sequences_sha256': hashlib.sha256('\n'.join(tr.Sequence).encode()).hexdigest()})
    names = pd.read_csv(INTERP / 'feature_dictionary.csv').feature.tolist()
    original_p = np.array([m.predict_proba(x)[:, 1] for m in models])
    stored = np.array([c['scores']['fusion'] for c in cases]).T
    parity = float(np.abs(original_p-stored).max())
    assert parity < 1e-12
    local, bases, inter, ibases, checks = [], [], [], [], []
    for seed, model in zip(SEEDS, models):
        state(f'Tree SHAP and reference sensitivity, seed {seed}')
        ex = shap.TreeExplainer(model, feature_perturbation='tree_path_dependent', model_output='raw')
        sv = ex.shap_values(x, check_additivity=True)
        base = float(np.asarray(ex.expected_value).reshape(-1)[0])
        ev = shap.TreeExplainer(model, data=bg, feature_perturbation='interventional', model_output='raw')
        iv = ev.shap_values(x, check_additivity=True)
        ib = float(np.asarray(ev.expected_value).reshape(-1)[0])
        margin = model.decision_function(x)
        aerr = float(np.abs(base+sv.sum(1)-margin).max())
        ierr = float(np.abs(ib+iv.sum(1)-margin).max())
        assert aerr < 1e-7 and ierr < 1e-4
        np.savez_compressed(HERE / f'shap_seed_{seed}.npz', path=sv, base=base,
                            interventional=iv, interventional_base=ib, probability=original_p[SEEDS.index(seed)])
        local.append(sv); bases.append(base); inter.append(iv); ibases.append(ib)
        checks.append({'seed': seed, 'path_additivity_error': aerr, 'interventional_additivity_error': ierr})
    local, inter = np.asarray(local), np.asarray(inter)
    descriptor_rows, group_rows, games = [], [], {}
    state('exact source coalitions and same-length reference checks')
    for i, case in enumerate(cases):
        cid = case['case_id']
        exactids = np.flatnonzero(tr.Sequence.str.len().values == len(case['Sequence']))
        assert len(exactids)
        exactids = np.random.default_rng(RNG+i).choice(exactids, min(64, len(exactids)), replace=False)
        both = {}
        for kind, reference in [('primary', bg), ('same_length', tx[exactids])]:
            values, phi, err = group_game(x[i], reference, models)
            both[kind] = {'coalition_values_by_seed': values.tolist(), 'phi_by_seed': phi.tolist(),
                          'background_n': len(reference), 'additivity_error': err}
            for j, g in enumerate(GROUPS):
                group_rows.append({'case_id': cid, 'reference': kind, 'source': g,
                    'contribution_mean_score': float(phi[:, j].mean()),
                    'baseline_mean_score': float(values[:, 0].mean()),
                    'original_mean_score': float(values[:, 7].mean()),
                    'leave_source_out_delta': float((values[:, 7 ^ (1 << j)]-values[:, 7]).mean()),
                    'positive_seed_count': int((phi[:, j]>0).sum()),
                    **{f'contribution_{s}': float(phi[k, j]) for k, s in enumerate(SEEDS)}})
        both['same_length_training_row_indices'] = exactids.tolist()
        games[cid] = both
        for j in range(128, 189):
            descriptor_rows.append({'case_id': cid, 'feature_index': j, 'feature': names[j],
                'raw_value': float(original_raw['phys'][i, j-128]),
                'path_mean_logodds': float(local[:, i, j].mean()),
                'interventional_mean_logodds': float(inter[:, i, j].mean()),
                'positive_seed_count': int((local[:, i, j]>0).sum()),
                'negative_seed_count': int((local[:, i, j]<0).sum()),
                **{f'path_{s}': float(local[k, i, j]) for k, s in enumerate(SEEDS)}})
    pd.DataFrame(group_rows).to_csv(HERE / 'source_contributions.csv', index=False)
    pd.DataFrame(descriptor_rows).to_csv(HERE / 'descriptor_contributions.csv', index=False)
    write(HERE / 'coalitions.json', games)

    state('constructing exhaustive single-A scan and composition-preserving controls')
    interventions = []
    for i, case in enumerate(cases):
        seq = case['Sequence']
        shared = {'case_id': case['case_id']}
        interventions.append({**shared, 'kind': 'original', 'position_1based': 0, 'replicate': 0, 'Sequence': seq})
        for j, aa in enumerate(seq):
            if aa != 'A':
                interventions.append({**shared, 'kind': 'alanine', 'position_1based': j+1, 'replicate': 0,
                                      'Sequence': seq[:j]+'A'+seq[j+1:]})
        rng = np.random.default_rng(RNG+i)
        seen = {seq}
        while len(seen) < 11:
            s = ''.join(rng.permutation(list(seq)))
            if s in seen:
                continue
            seen.add(s)
            assert sorted(seq) == sorted(s)
            interventions.append({**shared, 'kind': 'shuffle', 'position_1based': 0,
                                  'replicate': len(seen)-1, 'Sequence': s})
    variants = pd.DataFrame(interventions)
    variants.to_csv(HERE / 'sequence_tests_LOCAL.csv', index=False)
    unique = list(dict.fromkeys(variants.Sequence))
    state(f'extracting frozen representations for {len(unique)} unique diagnostic sequences')
    perturb_raw = extract(unique, HERE / 'perturbation_embeddings')
    zx = transform(perturb_raw, tf, cfg)
    zp = np.array([m.predict_proba(zx)[:, 1] for m in models])
    ixmap = {s: j for j, s in enumerate(unique)}
    indices = [ixmap[s] for s in variants.Sequence]
    for k, seed in enumerate(SEEDS):
        variants[f'score_{seed}'] = zp[k, indices]
    variants['score_mean'] = variants[[f'score_{s}' for s in SEEDS]].mean(axis=1)
    maxfeature, maxoriginal, maxshufflephys = 0., 0., 0.
    summaries = []
    for i, case in enumerate(cases):
        mask = variants.case_id == case['case_id']
        sub = variants[mask]
        basep = original_p[:, i].mean()
        variants.loc[mask, 'delta_mean_score'] = sub.score_mean.values-basep
        for k, seed in enumerate(SEEDS):
            variants.loc[mask, f'delta_{seed}'] = sub[f'score_{seed}'].values-original_p[k, i]
        origidx = ixmap[case['Sequence']]
        for key in ['esm', 'prot', 'phys']:
            maxfeature = max(maxfeature, float(np.abs(perturb_raw[key][origidx]-original_raw[key][i]).max()))
        maxoriginal = max(maxoriginal, float(np.abs(zp[:, origidx]-original_p[:, i]).max()))
        shuffleids = [ixmap[s] for s in sub[sub.kind=='shuffle'].Sequence]
        err = float(np.abs(perturb_raw['phys'][shuffleids]-original_raw['phys'][i]).max())
        maxshufflephys = max(maxshufflephys, err)
        assert err < 1e-6
        for kind in ['alanine', 'shuffle']:
            a = variants[mask & (variants.kind == kind)]
            summaries.append({'case_id': case['case_id'], 'kind': kind, 'n': len(a),
                'original_score': float(basep), 'mean_score': float(a.score_mean.mean()),
                'mean_delta_score': float(a.delta_mean_score.mean()),
                'mean_absolute_delta_score': float(a.delta_mean_score.abs().mean()),
                'minimum_score': float(a.score_mean.min()), 'maximum_score': float(a.score_mean.max()),
                'classification_flips': int(((a.score_mean>=.5)!=(basep>=.5)).sum())})
    assert maxfeature < 0.002 and maxoriginal < 1e-12
    variants.to_csv(HERE / 'sequence_tests_LOCAL.csv', index=False)
    pd.DataFrame(summaries).to_csv(HERE / 'sequence_sensitivity.csv', index=False)

    state('building label-free tool evidence packets')
    gd, dd = pd.DataFrame(group_rows), pd.DataFrame(descriptor_rows)
    summaries = pd.DataFrame(summaries)
    for i, case in enumerate(cases):
        cid = case['case_id']
        g = gd[(gd.case_id==cid) & (gd.reference=='primary')].set_index('source')
        gl = gd[(gd.case_id==cid) & (gd.reference=='same_length')].set_index('source')
        d = dd[dd.case_id==cid].copy()
        d = d.iloc[np.argsort(-d.path_mean_logodds.abs().values)].head(5)
        a = variants[(variants.case_id==cid) & (variants.kind=='alanine')].copy()
        a = a.iloc[np.argsort(-a.delta_mean_score.abs().values)].head(3)
        ss = summaries[(summaries.case_id==cid) & (summaries.kind=='shuffle')].iloc[0]
        aa = summaries[(summaries.case_id==cid) & (summaries.kind=='alanine')].iloc[0]
        groups = {name: {'contribution_mean_score': float(r.contribution_mean_score),
            'direction': direction(r.contribution_mean_score),
            'contributions_by_seed': [float(r[f'contribution_{s}']) for s in SEEDS],
            'same_length_reference_contribution': float(gl.loc[name].contribution_mean_score),
            'reference_sign_agrees': direction(r.contribution_mean_score)==direction(gl.loc[name].contribution_mean_score),
            'leave_source_out_delta': float(r.leave_source_out_delta)} for name, r in g.iterrows()}
        top_features = []
        for _, r in d.iterrows():
            top_features.append({'feature': r.feature, 'feature_index': int(r.feature_index),
                'raw_value': float(r.raw_value), 'mean_shap_logodds': float(r.path_mean_logodds),
                'direction': direction(r.path_mean_logodds), 'positive_seed_count': int(r.positive_seed_count),
                'negative_seed_count': int(r.negative_seed_count),
                'interventional_mean_shap_logodds': float(r.interventional_mean_logodds),
                'reference_sign_agrees': direction(r.path_mean_logodds)==direction(r.interventional_mean_logodds)})
        evidence = {
            'get_prediction': {'evidence_id': 'P', 'mean_score': float(original_p[:, i].mean()),
                'seed_scores': original_p[:, i].tolist(), 'seeds': SEEDS, 'threshold': .5,
                'positive_votes': int((original_p[:, i]>=.5).sum()), 'length_aa': len(case['Sequence']),
                'meaning': 'Frozen fusion only; uncalibrated AMP classification score, not activity probability or MIC.'},
            'get_source_attribution': {'evidence_id': 'G', 'method': 'Exact 3-block Shapley, all 8 coalitions',
                'unit': 'classification score (0 to 1), not percent of biological effect',
                'baseline_mean_score': float(g.baseline_mean_score.iloc[0]),
                'groups': groups, 'dominant_source': g.contribution_mean_score.abs().idxmax(),
                'background_n': 64, 'same_length_background_n': games[cid]['same_length']['background_n'],
                'meaning': 'Baseline plus the three contributions equals mean model score. Signed effects relative to chosen training reference. Hybrid features may lie outside the observed manifold. Neither independent information nor biological causality.'},
            'get_descriptor_attribution': {'evidence_id': 'D', 'method': 'Per-seed Tree SHAP path-dependent; sensitivity interventional',
                'unit': 'positive-class log-odds; NOT the probability-score units of G',
                'top_features': top_features,
                'meaning': 'Mean signed per-seed contributions. Correlated descriptors derived from composition. Property means/SD use globally standardized residue lookup values. Mean residue pI is NOT peptide pI; propensity is NOT measured structure. PCA dimensions have no assigned mechanism.'},
            'get_sequence_sensitivity': {'evidence_id': 'S',
                'alanine_scan_n': int(aa.n), 'alanine_mean_absolute_delta': float(aa.mean_absolute_delta_score),
                'alanine_flip_count': int(aa.classification_flips),
                'top_alanine_positions': [{'position_1based': int(r.position_1based),
                    'perturbed_score': float(r.score_mean), 'delta_score': float(r.delta_mean_score),
                    'seed_deltas': [float(r[f'delta_{s}']) for s in SEEDS]} for _, r in a.iterrows()],
                'shuffle_n': int(ss.n), 'shuffle_mean_absolute_delta': float(ss.mean_absolute_delta_score),
                'shuffle_mean_delta': float(ss.mean_delta_score), 'shuffle_minimum_score': float(ss.minimum_score),
                'shuffle_maximum_score': float(ss.maximum_score), 'shuffle_flip_count': int(ss.classification_flips),
                'shuffle_explicit_descriptors_unchanged': True,
                'meaning': 'All encoders and descriptors recomputed after each non-A to A substitution and 10 length/composition-preserving shuffles. Shuffles leave explicit descriptors constant, so score changes arise through sequence-order-sensitive representations and their downstream interactions. Responses are specific to these perturbations, not causal residue importance or experimental activity.'},
        }
        write(HERE / 'evidence' / f'{cid}.json', evidence)
    assert all(sha(ROOT/p)==h for p,h in proto['model_hashes'].items())
    write(HERE / 'COMPUTATION_VERIFICATION.json', {
        'passed': True, 'cases': 12, 'models_unchanged': True,
        'prediction_parity_error': parity, 'original_reembedding_score_error': maxoriginal,
        'original_reembedding_feature_error': maxfeature, 'shuffle_phys_max_error': maxshufflephys,
        'shap_checks': checks, 'coalition_additivity_max_error': max(v[k]['additivity_error'] for v in games.values() for k in ['primary','same_length']),
        'sequence_test_rows': len(variants), 'unique_sequences_embedded': len(unique),
        'alanine_substitutions': int((variants.kind=='alanine').sum()),
        'composition_preserving_shuffles': int((variants.kind=='shuffle').sum()),
        'elapsed_seconds': time.monotonic()-started})
    state('computation complete')

if __name__ == '__main__':
    try:
        with threadpool_limits(limits=4):
            main()
    except Exception:
        write(HERE / 'failure.json', {'traceback': traceback.format_exc()})
        raise
