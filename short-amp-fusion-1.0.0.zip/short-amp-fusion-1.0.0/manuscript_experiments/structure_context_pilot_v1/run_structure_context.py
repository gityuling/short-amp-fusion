"""Predict structures for the 12 previously retained cases, without activity tuning.

Official ESMFold weights are revision-pinned. Existing classification outputs and
case selection are read-only inputs. No structures are fabricated if inference fails.
"""
from pathlib import Path
import os
os.environ.setdefault('HF_HUB_DISABLE_XET', '1')
os.environ.setdefault('HF_HUB_DISABLE_TELEMETRY', '1')
os.environ.setdefault('HF_HUB_DOWNLOAD_TIMEOUT', '45')
os.environ.setdefault('HF_HUB_ETAG_TIMEOUT', '15')
import hashlib
import io
import json
import shutil
import sys
import time
import traceback
import argparse

ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).resolve().parent
SOURCE_DIR = OUT
MODEL_ID = 'facebook/esmfold_v1'
REVISION = '75a3841ee059df2bf4d56688166c8fb459ddd97a'
CACHE = ROOT / 'models' / 'esmfold_v1_hf'
PILOT = ['C01', 'C06', 'C09']


def write_json(path, data):
    tmp = path.with_suffix(path.suffix + '.tmp')
    tmp.write_text(json.dumps(data, indent=2, ensure_ascii=False) + '\n')
    tmp.replace(path)


def status(stage, **extra):
    data = {'stage': stage, 'updated_utc': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()), **extra}
    write_json(OUT / 'status.json', data)
    print(json.dumps(data, ensure_ascii=False), flush=True)


def sha(path):
    h = hashlib.sha256()
    with path.open('rb') as f:
        for b in iter(lambda: f.read(8 * 1024 * 1024), b''):
            h.update(b)
    return h.hexdigest()


def main():
    global OUT
    ap = argparse.ArgumentParser()
    ap.add_argument('--case-ids', nargs='+')
    ap.add_argument('--output-dir', type=Path)
    args = ap.parse_args()
    if args.output_dir:
        OUT = args.output_dir.resolve()
        OUT.mkdir(parents=True, exist_ok=True)
    import numpy as np
    import pandas as pd
    import torch
    import transformers
    from huggingface_hub import hf_hub_download
    from transformers import EsmForProteinFolding
    from transformers.models.esm.openfold_utils import residue_constants
    from Bio.PDB import PDBParser
    from Bio.SeqUtils import seq1

    source = SOURCE_DIR / 'original_case_inputs.csv'
    cases = pd.read_csv(source)
    assert len(cases) == 12 and cases.case_id.is_unique
    assert cases.kind.eq('original').all()
    assert cases.Sequence.str.fullmatch('[ACDEFGHIKLMNPQRSTVWY]+').all()
    assert cases.Sequence.str.len().between(11, 30).all()
    order = PILOT + sorted(set(cases.case_id) - set(PILOT))
    if args.case_ids:
        assert len(args.case_ids) == len(set(args.case_ids))
        assert set(args.case_ids) <= set(order)
        order = [c for c in order if c in args.case_ids]
    cases = cases.set_index('case_id').loc[order]
    n_cases = len(cases)
    torch.set_num_threads(4)
    torch.manual_seed(2026)
    np.random.seed(2026)
    assert torch.cuda.is_available(), 'A local CUDA device is required for this bounded run.'
    CACHE.mkdir(parents=True, exist_ok=True)
    local_weight = CACHE / ('models--' + MODEL_ID.replace('/', '--')) / 'snapshots' / REVISION / 'pytorch_model.bin'
    if not local_weight.exists():
        assert shutil.disk_usage(CACHE).free > 21_000_000_000, 'Insufficient space for model plus a reserve.'
    protocol = {
        'model_id': MODEL_ID, 'revision': REVISION,
        'official_documentation': 'https://huggingface.co/facebook/esmfold_v1',
        'n_cases': n_cases, 'campaign_cases': 12, 'pilot_case_ids': PILOT, 'execution_order': order,
        'case_selection': 'All 12 cases from external_explanations_v2, unchanged. C01/C06/C09 were the prior manuscript examples before structures were computed.',
        'input_sha256': sha(source), 'script_sha256': sha(Path(__file__)),
        'transformers_version': transformers.__version__, 'torch_version': torch.__version__,
        'gpu': torch.cuda.get_device_name(0), 'cuda_visible_devices': os.environ.get('CUDA_VISIBLE_DEVICES'),
        'physical_gpu_index': os.environ.get('AMP_PHYSICAL_GPU'), 'seed': 2026,
        'single_chain': True, 'msa': False, 'relaxation': False,
        'esm_dtype': 'float16', 'folding_trunk_dtype': 'float32',
        'chunk_size': 32, 'additional_recycles': 3, 'total_trunk_passes': 4,
        'plddt_export': 'Transformers 4.46.2 returns categorical LDDT on [0,1]; multiply by 100 for PDB B-factors and tables.',
        'role': 'Exploratory predicted structural context for existing model-input perturbations. Structures are not inputs to the frozen AMP classifier or the previously completed agent runs.',
        'interpretation': 'No claim of experimentally determined structure, membrane-bound conformation, activity mechanism, or measured activity of alanine/shuffled variants. Terminal modifications and solvent/membrane conditions are not modeled.',
        'all_cases_reported': n_cases == 12,
    }
    write_json(OUT / 'PROTOCOL.json', protocol)
    status('resolving_pinned_weights', model_id=MODEL_ID, revision=REVISION)
    files = {}
    for name in ['config.json', 'pytorch_model.bin']:
        files[name] = hf_hub_download(MODEL_ID, name, revision=REVISION, cache_dir=str(CACHE), token=False,
                                     local_files_only=local_weight.exists())
    status('loading_model')
    model = EsmForProteinFolding.from_pretrained(
        str(Path(files['config.json']).parent), local_files_only=True,
        low_cpu_mem_usage=True,
    ).eval()
    model.esm.half()
    model.trunk.set_chunk_size(32)
    model.cuda()
    protocol['weight_sha256'] = sha(Path(files['pytorch_model.bin']))
    protocol['config_sha256'] = sha(Path(files['config.json']))
    protocol['actual_esm_dtype'] = str(next(model.esm.parameters()).dtype)
    protocol['actual_trunk_dtype'] = str(next(model.trunk.parameters()).dtype)
    write_json(OUT / 'PROTOCOL.json', protocol)
    (OUT / 'pdb').mkdir(exist_ok=True)
    (OUT / 'arrays').mkdir(exist_ok=True)
    summary, residue_rows = [], []
    parser = PDBParser(QUIET=True)
    for case_id, row in cases.iterrows():
        status('predicting', case_id=case_id, completed=len(summary), total=n_cases)
        seq = row.Sequence
        aa = torch.tensor([[residue_constants.restype_order[x] for x in seq]], device='cuda')
        start = time.time()
        with torch.inference_mode():
            pred = model(aa, attention_mask=torch.ones_like(aa), num_recycles=3)
        assert torch.isfinite(pred['positions']).all()
        conf = pred['plddt']
        assert float(conf.min()) >= 0 and float(conf.max()) <= 1, 'Unexpected confidence scaling.'
        pred['plddt'] = conf * 100
        pdb = model.output_to_pdb(pred)[0]
        structure = parser.get_structure(case_id, io.StringIO(pdb))
        residues = [r for r in structure.get_residues() if r.has_id('CA')]
        reconstructed = ''.join(seq1(r.resname) for r in residues)
        assert reconstructed == seq, (case_id, reconstructed, seq)
        ca = np.array([r['CA'].coord for r in residues])
        confidence = np.array([r['CA'].bfactor for r in residues])
        distances = np.linalg.norm(ca[:, None] - ca[None, :], axis=-1)
        adjacent = np.diag(distances, 1)
        assert (adjacent > 2.8).all() and (adjacent < 4.8).all(), 'Implausible chain continuity.'
        pdb_path = OUT / 'pdb' / f'{case_id}_esmfold.pdb'
        pdb_path.write_text(pdb)
        np.savez_compressed(OUT / 'arrays' / f'{case_id}_structure.npz',
                            ca_coordinates=ca, ca_distances=distances,
                            plddt_ca=confidence,
                            predicted_aligned_error=pred['predicted_aligned_error'][0].float().cpu().numpy())
        for pos, (res, xyz, pl) in enumerate(zip(seq, ca, confidence), 1):
            residue_rows.append({'case_id': case_id, 'position_1based': pos, 'residue': res,
                                 'ca_x': float(xyz[0]), 'ca_y': float(xyz[1]), 'ca_z': float(xyz[2]),
                                 'plddt_ca': float(pl)})
        summary.append({'case_id': case_id, 'length': len(seq), 'score_mean': row.score_mean,
                        'mean_ca_plddt': float(confidence.mean()),
                        'min_ca_plddt': float(confidence.min()),
                        'fraction_ca_plddt_below_50': float((confidence < 50).mean()),
                        'fraction_ca_plddt_ge_70': float((confidence >= 70).mean()),
                        'ca_radius_of_gyration_angstrom': float(np.sqrt(np.mean(np.sum((ca-ca.mean(0))**2, axis=1)))),
                        'ptm': float(pred['ptm'].reshape(-1)[0]), 'seconds': time.time()-start,
                        'sequence_matches_pdb': True, 'pdb_sha256': sha(pdb_path)})
        pd.DataFrame(summary).to_csv(OUT / 'structure_summary.csv', index=False)
        pd.DataFrame(residue_rows).to_csv(OUT / 'structure_residues.csv', index=False)
        del pred
        torch.cuda.empty_cache()
    status('complete', completed=len(summary), total=n_cases,
           manifest={p.name: sha(p) for p in sorted((OUT/'pdb').glob('*.pdb'))})


if __name__ == '__main__':
    try:
        main()
    except Exception as exc:
        status('failed', error_type=type(exc).__name__, error=str(exc))
        traceback.print_exc()
        sys.exit(1)
