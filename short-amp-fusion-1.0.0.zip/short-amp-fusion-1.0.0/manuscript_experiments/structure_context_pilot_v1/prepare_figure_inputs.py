"""Join archived case/agent results to residues without new activity predictions."""
from pathlib import Path
import hashlib
import json
import numpy as np
import pandas as pd

OUT = Path(__file__).resolve().parent
SOURCE = OUT.parent / 'external_explanations_v2'
tests = pd.read_csv(SOURCE / 'sequence_tests_LOCAL.csv')
summary = pd.read_csv(SOURCE / 'case_summary.csv').set_index('case_id')
evaluation = pd.read_csv(SOURCE / 'agent_evaluation.csv').set_index('case_id')
residue_rows, agent_rows, trace_rows = [], [], []
for case_id, row in summary.iterrows():
    original = tests[(tests.case_id == case_id) & (tests.kind == 'original')]
    assert len(original) == 1
    original = original.iloc[0]
    seq = original.Sequence
    assert abs(original.score_mean - row.model_score) < 1e-10
    variants = tests[(tests.case_id == case_id) & (tests.kind == 'alanine')]
    for pos, aa in enumerate(seq, 1):
        v = variants[variants.position_1based == pos]
        record = {'case_id': case_id, 'position_1based': pos, 'residue': aa,
                  'basic_KR': aa in 'KR', 'acidic_DE': aa in 'DE',
                  'hydrophobic_AVILMFWY': aa in 'AVILMFWY',
                  'original_score': row.model_score,
                  'alanine_tested': aa != 'A', 'alanine_delta_mean': np.nan,
                  'alanine_delta_seed_sd': np.nan}
        if aa == 'A':
            assert len(v) == 0
        else:
            assert len(v) == 1
            v = v.iloc[0]
            assert v.Sequence == seq[:pos-1] + 'A' + seq[pos:]
            assert abs(v.score_mean-original.score_mean-v.delta_mean_score) < 1e-10
            record.update(alanine_delta_mean=v.delta_mean_score,
                          alanine_delta_seed_sd=np.std([v.delta_42,v.delta_43,v.delta_44],ddof=1))
        residue_rows.append(record)
    evidence_dir = SOURCE / 'agent_output' / case_id
    t = json.loads((evidence_dir / 'evidence/T.json').read_text())
    trace = json.loads((evidence_dir / 'tool_trace.json').read_text())
    t_call = next(x for x in trace if x['tool'] == 'test_source_removal')
    g_call = next(x for x in trace if x['tool'] == 'get_source_attribution')
    assert g_call['turn'] < t_call['turn']
    assert t_call['arguments']['predicted_change'] == t['predicted_change']
    replacement = row.model_score + t['observed_delta']
    assert 0 <= replacement <= 1
    agent_rows.append({'case_id':case_id,'cohort':row.cohort,
                       'original_score':row.model_score,'selected_block':t['group'],
                       'expected_direction_before_tool_result':t['predicted_change'],
                       'observed_replacement_score':replacement,
                       'observed_score_delta':t['observed_delta'],
                       'direction_check':t['verdict'],
                       'same_block_as_fixed_rule':evaluation.loc[case_id,'same_group_as_rule'],
                       'semantic_status':evaluation.loc[case_id,'semantic_status'],
                       'published_activity_POSTHOC':row.published_activity_POSTHOC,
                       'structures_available_to_original_agent':False})
    for item in trace:
        trace_rows.append({'case_id':case_id,'turn':item['turn'],
                           'tool':item['tool'],'evidence_id':item['evidence_id'],
                           'arguments_json':json.dumps(item['arguments'],ensure_ascii=False)})

residues = pd.DataFrame(residue_rows)
assert residues.alanine_tested.sum() == 224
residues.to_csv(OUT / 'residue_response_map.csv', index=False)
pd.DataFrame(agent_rows).to_csv(OUT / 'agent_direction_checks.csv', index=False)
pd.DataFrame(trace_rows).to_csv(OUT / 'agent_tool_order.csv', index=False)
top = residues[residues.alanine_tested].copy()
top['absolute_delta'] = top.alanine_delta_mean.abs()
top = top.sort_values(['case_id','absolute_delta','position_1based'],ascending=[True,False,True])
top = top.groupby('case_id',sort=False).head(2)
top.to_csv(OUT / 'two_largest_model_response_positions.csv',index=False)
audit = {
    'passed': True, 'n_original_cases': len(summary), 'n_residues': len(residues),
    'n_existing_nontrivial_alanine_substitutions': int(residues.alanine_tested.sum()),
    'n_agent_tool_records': len(trace_rows),
    'model_scores_recomputed': False,
    'mapping_note': 'Original alanine positions are missing/untested, not measured zero effects. The two largest absolute model responses are selected per case with residue index as tie-breaker; they are not biological activity hotspots.',
    'source_hashes': {n:hashlib.sha256((SOURCE/n).read_bytes()).hexdigest() for n in ['sequence_tests_LOCAL.csv','case_summary.csv','agent_evaluation.csv']},
}
(OUT / 'FIGURE_INPUT_AUDIT.json').write_text(json.dumps(audit,indent=2)+'\n')
print(json.dumps(audit,indent=2))
