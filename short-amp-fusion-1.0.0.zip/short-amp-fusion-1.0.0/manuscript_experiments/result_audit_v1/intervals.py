"""Paired percentile bootstrap of fixed fitted predictors. Never fit/select models."""
from pathlib import Path
import sys,json,hashlib,time
import numpy as np
import pandas as pd
from sklearn import metrics as sm
HERE=Path(__file__).resolve().parent;BASE=HERE.parent;ROOT=BASE.parent
sys.path.insert(0,str(BASE/'scripts'))
import battle_official_eval as official
from common_study import write_json,sha256,ASSETS
import homology

METRICS=['f1','mcc','auroc','average_precision','accuracy','precision','recall','specificity']
REPS=10000;SEEDS=[42,43,44];ROWS=[];COHORTS=[];INPUTS={}
def read(path,**kwargs):
    INPUTS[str(path.relative_to(ROOT))]=sha256(path)
    return pd.read_csv(path,**kwargs)
def divide(a,b):return np.divide(a,b,out=np.zeros_like(a,dtype=float),where=b!=0)

class WeightedScores:
    def __init__(self,y,p,h=None):
        self.y=np.asarray(y,int);self.p=np.atleast_2d(p).astype(float)
        self.h=(self.p>.5).astype(int) if h is None else np.atleast_2d(h).astype(int)
        assert self.p.shape==self.h.shape and self.p.shape[1]==len(y) and np.isfinite(self.p).all()
        self.rank=[]
        for v in self.p:
            order=np.argsort(v,kind='stable');values=v[order]
            starts=np.r_[0,np.flatnonzero(np.diff(values)!=0)+1]
            self.rank.append((order,starts))
    def score(self,w,per_seed=False):
        w=np.atleast_2d(w).astype(float);y=self.y
        pos=w@y;neg=w@(1-y);out=[]
        for h,(order,starts) in zip(self.h,self.rank):
            tp=w@(y*h);fp=w@((1-y)*h);fn=pos-tp;tn=neg-fp
            f1=divide(2*tp,2*tp+fp+fn);mcc=divide(tp*tn-fp*fn,np.sqrt((tp+fp)*(tp+fn)*(tn+fp)*(tn+fn)))
            wp=np.add.reduceat(w[:,order]*y[order],starts,axis=1)
            wn=np.add.reduceat(w[:,order]*(1-y[order]),starts,axis=1)
            neg_before=np.cumsum(wn,axis=1)-wn
            auc=divide(np.sum(wp*(neg_before+.5*wn),axis=1),pos*neg)
            pp=np.cumsum(wp[:,::-1],axis=1);nn=np.cumsum(wn[:,::-1],axis=1)
            ap=divide(np.sum(divide(pp,pp+nn)*wp[:,::-1],axis=1),pos)
            out.append(np.stack([f1,mcc,auc,ap,divide(tp+tn,pos+neg),divide(tp,tp+fp),divide(tp,pos),divide(tn,neg)],axis=1))
        out=np.stack(out,axis=1)
        return out if per_seed else out.mean(axis=1)

def verify_weighted():
    rng=np.random.default_rng(2026110201);err=0.
    for trial in range(30):
        y=np.r_[np.ones(29,int),np.zeros(23,int)];p=np.round(rng.random((3,len(y))),1)
        if trial==0:p[:]=1.
        h=(p>.5).astype(int)
        if trial==1:h[:]=0  # Native hard labels can differ from ranking scores.
        w=rng.multinomial(len(y),np.full(len(y),1/len(y)))
        got=WeightedScores(y,p,h).score(w,True)[0];ix=np.repeat(np.arange(len(y)),w)
        for j in range(3):
            yy=y[ix];hh=h[j,ix];pp=p[j,ix];tn,fp,fn,tp=sm.confusion_matrix(yy,hh,labels=[0,1]).ravel()
            want=[sm.f1_score(yy,hh,zero_division=0),sm.matthews_corrcoef(yy,hh),sm.roc_auc_score(yy,pp),sm.average_precision_score(yy,pp),sm.accuracy_score(yy,hh),sm.precision_score(yy,hh,zero_division=0),sm.recall_score(yy,hh),tn/(tn+fp)]
            err=max(err,float(np.max(np.abs(got[j]-want))))
    assert err<1e-12,err
    write_json(HERE/'bootstrap_implementation_validation.json',{'passed':True,'random_trials':30,'predictors_per_trial':3,'weighted_vs_explicit_resampling_max_error':err,'cases':'ties, constant scores, native hard labels distinct from scores, both classes, variable multiplicities'})

def cohort_groups(seqs):
    # Exhaustive global alignment at >=80% identity, >=80% paired coverage of each sequence.
    path=HERE/'holdout_groups80.csv'
    if path.exists():
        d=read(path);assert d.sequence.tolist()==list(seqs);return d.set_index('sequence').cluster
    homology.init([]);parent=np.arange(len(seqs))
    def root(i):
        while parent[i]!=i:parent[i]=parent[parent[i]];i=parent[i]
        return i
    edges=0
    for i,a in enumerate(seqs):
        for j in range(i):
            if homology.identity(a,seqs[j])>=.8:
                u,v=root(i),root(j);parent[u]=v;edges+=1
    group=np.asarray([root(i) for i in range(len(seqs))]);d=pd.DataFrame({'sequence':seqs,'cluster':group});d.to_csv(path,index=False)
    write_json(HERE/'holdout_clustering.json',{'n':len(seqs),'groups':len(np.unique(group)),'largest':int(d.cluster.value_counts().max()),'edges':edges,'identity':.8,'coverage_both':.8,'alignment':'Global BLOSUM62, gap open -10 / extend -0.5; identity=matches/alignment columns; connected components; exhaustive all pairs; only within holdout, not a train-holdout homology audit.'})
    INPUTS[str(path.relative_to(ROOT))]=sha256(path);return d.set_index('sequence').cluster

def bootstrap(study,contrast,seq,y,left,right,groups,left_h=None,right_h=None,primary='cluster'):
    y=np.asarray(y,int);seq=np.asarray(seq);groups=np.asarray(groups)
    assert len(seq)==len(set(seq)) and len(np.unique(y))==2
    engines=[WeightedScores(y,left,left_h),WeightedScores(y,right,right_h)]
    points=np.stack([e.score(np.ones(len(y)))[0] for e in engines])
    seed_scores=[e.score(np.ones(len(y)),True)[0] for e in engines]
    cohort_id=hashlib.sha256('\n'.join(f'{s}\t{v}' for s,v in zip(seq,y)).encode()).hexdigest()
    uniq,gi=np.unique(groups,return_inverse=True);g=len(uniq)
    COHORTS.append({'study':study,'contrast':contrast,'n':len(y),'positive':int(y.sum()),'negative':int((1-y).sum()),'clusters':g,'largest_cluster':int(np.bincount(gi).max()),'sequence_label_sha256':cohort_id,'primary_resampling':primary})
    for method in ['cluster','label_stratified_sequence']:
        tag=study+'|'+contrast+'|'+method
        seed=int.from_bytes(hashlib.sha256(tag.encode()).digest()[:8],'little')
        rng=np.random.default_rng(seed);chunks=[];valid=attempts=0
        while valid<REPS:
            b=min(96,REPS-valid)
            if method=='cluster':w=rng.multinomial(g,np.full(g,1/g),size=b)[:,gi]
            else:
                w=np.zeros((b,len(y)),dtype=np.int64)
                for label in [0,1]:
                    ix=np.flatnonzero(y==label);w[:,ix]=rng.multinomial(len(ix),np.full(len(ix),1/len(ix)),size=b)
            attempts+=b;ok=((w@y)>0)&((w@(1-y))>0);w=w[ok]
            if not len(w):continue
            a,bscore=[e.score(w) for e in engines]
            chunks.append(np.stack([a,bscore,a-bscore],axis=1));valid+=len(w)
        draws=np.concatenate(chunks);ci=np.quantile(draws,[.025,.975],axis=0)
        safe=(study+'__'+contrast+'__'+method).replace('/','_')
        np.savez_compressed(HERE/'bootstrap_draws'/f'{safe}.npz',draws=draws,metrics=np.array(METRICS))
        for j,metric in enumerate(METRICS):
            ROWS.append({'study':study,'contrast':contrast,'metric':metric,'resampling':method,'is_primary_resampling':method==primary,'n':len(y),'positive':int(y.sum()),'negative':int((1-y).sum()),'clusters':g,
                'ours':points[0,j],'comparator':points[1,j],'delta':points[0,j]-points[1,j],
                'delta_ci_low':ci[0,2,j],'delta_ci_high':ci[1,2,j],'ours_ci_low':ci[0,0,j],'ours_ci_high':ci[1,0,j],'comparator_ci_low':ci[0,1,j],'comparator_ci_high':ci[1,1,j],
                'ours_seed_sd':float(seed_scores[0][:,j].std(ddof=1)) if len(seed_scores[0])>1 else None,'comparator_seed_sd':float(seed_scores[1][:,j].std(ddof=1)) if len(seed_scores[1])>1 else None,
                'bootstrap_valid':valid,'bootstrap_attempts':attempts,'bootstrap_rng_seed':seed,'ci_level':.95,'interval':'paired percentile; pointwise; fixed fitted seeds','sequence_label_sha256':cohort_id})
    pd.DataFrame(ROWS).to_csv(HERE/'confidence_intervals.csv',index=False);pd.DataFrame(COHORTS).to_csv(HERE/'ci_cohorts.csv',index=False)
    print('CI',study,contrast,'n',len(y),'clusters',g,flush=True)

def main():
    start=time.time();(HERE/'bootstrap_draws').mkdir(exist_ok=True)
    protocol={'created_utc':pd.Timestamp.now(tz='UTC').isoformat(),'purpose':'Results verification and key confidence intervals only; not manuscript writing.',
      'analysis_is_posthoc':True,'no_retraining_no_threshold_tuning_no_model_selection':True,'replicates':REPS,'confidence_level':.95,'interval':'paired percentile bootstrap; same sample multiplicities for both methods and all seeds',
      'metrics':METRICS,'estimand':'Mean of metrics over the same three frozen fitted seeds 42/43/44. Not metrics of mean probabilities. Reference archives have one fixed prediction set.',
      'primary_contrasts':['original PPsAMP test: dual64_phys minus PPsAMP','BATTLE retrained test10-100: dual64_phys minus PPsAMP','BATTLE official holdout2026 broad activity: extended dual minus extended PPsAMP'],
      'supplements':['BATTLE retrained length strata','All 8 official holdout tasks vs PPsAMP; overlapping cohorts, not independent datasets','Holdout broad activity vs all 21 author cached variants, matched separately, native hard predictions and MIC grey-zone exclusion retained','Holdout broad activity vs all-positive rule'],
      'primary_resampling':'Whole homology clusters with replacement; existing original global40% clusters, BATTLE split MMseqs detected80% groups, holdout exhaustive global80% connected components.',
      'sensitivity':'Sequence bootstrap stratified by observed class label, preserving class counts. Cluster bootstrap allows class prevalence and sample size to vary.',
      'multiplicity':'Every CI is pointwise 95%, without familywise/multiple-comparison correction. Do not interpret 21 intervals as a statistically established global first place or select positive results.',
      'limits':['Conditional on fitted models; does not encompass full retraining/split/encoder uncertainty. Seed SD is separate and not a CI.','Original test was disclosed during model development; intervals do not correct selection bias.','Holdout within-set clusters do not establish train/holdout or encoder-supervision independence.','AP and F1 depend on prevalence; fixed rule all-positive is included.','P@100 and partial AUROC are audited but not assigned naive bootstrap CIs; these intervals focus on eight prespecified metrics.']}
    path=HERE/'interval_protocol.json'
    if not path.exists():write_json(path,protocol)
    verify_weighted()
    # Original PPsAMP test, fixed three seed heads.
    source=read(ASSETS/'data/test_dedup_split.csv');seq=source.Sequence.values;y=source.Label.values
    left=np.stack([read(BASE/f'results/core/dual64_phys/seed_{s}/test_predictions.csv').probability_amp for s in SEEDS])
    right=np.stack([read(ROOT/f'optimization/stage2_official_evaluation/baseline_seed_{s}_predictions.csv').probability_amp for s in SEEDS])
    group=read(BASE/'results/analysis/test_clusters.csv').set_index('sequence').loc[seq,'cluster'].values
    bootstrap('original_ppsamp','ours_minus_ppsamp',seq,y,left,right,group)
    # Retraining on new BATTLE data.
    source=read(BASE/'battle_amp_v1/data/test.csv');seq=source.Sequence.values;y=source.Label.values
    left=np.stack([read(BASE/f'battle_amp_v1/results/dual64_phys/seed_{s}/test_predictions.csv').probability_amp for s in SEEDS])
    right=np.stack([read(BASE/f'battle_amp_v1/results/ppsamp/seed_{s}/test_predictions.csv').probability_amp for s in SEEDS])
    for lo,hi in [(10,100),(10,30),(31,50),(51,100)]:
        keep=source.Sequence.str.len().between(lo,hi).values
        bootstrap(f'battle_retrained_{lo}_{hi}','ours_minus_ppsamp',seq[keep],y[keep],left[:,keep],right[:,keep],source.group.values[keep])
    # Read only small holdout slices of large frozen prediction tables.
    tasks={k:v for k,v in official.TASKS.items() if k.startswith('holdout2026_')}
    labs={k:read(official.UP/v['labels'],sep='\t') for k,v in tasks.items()}
    seqs=sorted(set(s for d in labs.values() for s in d.sequence if 10<=len(s)<=100 and set(s)<=set('ACDEFGHIKLMNPQRSTVWY')))
    group=cohort_groups(seqs);tables={}
    for kind in ['dual','ppsamp']:
        for seed in SEEDS:
            path=official.OUT/f'predictions/extended_{kind}_{seed}.tsv';INPUTS[str(path.relative_to(ROOT))]=sha256(path)
            parts=[c[c.sequence.isin(seqs)] for c in pd.read_csv(path,sep='\t',chunksize=100000)]
            tables[kind,seed]=pd.concat(parts).set_index('sequence')
    for task,tc in tasks.items():
        lab=labs[task];lab=lab[lab.sequence.isin(seqs)];ss=lab.sequence.values;y=(lab[tc.get('label_column','label')]==tc.get('positive_label','AMP')).astype(int).values
        left=np.stack([tables['dual',s].loc[ss,'Probability_score'] for s in SEEDS]);right=np.stack([tables['ppsamp',s].loc[ss,'Probability_score'] for s in SEEDS])
        bootstrap(task,'ours_minus_ppsamp',ss,y,left,right,group.loc[ss].values)
        if task=='holdout2026_broad_activity':bootstrap(task,'ours_minus_all_positive',ss,y,left,np.ones((1,len(y))),group.loc[ss].values)
    task='holdout2026_broad_activity';tc=tasks[task];lab=labs[task]
    for ref in json.loads((official.OUT/'protocol.json').read_text())['references']:
        pred=read(official.UP/f'results/inference/{ref}/{tc["dataset"]}/predictions.tsv',sep='\t')
        ss,y,h,p=official.evaluated_arrays(pred,lab,tc);keep=pd.Index(ss).isin(seqs);ss=ss[keep];y=y[keep];h=h[keep];p=p[keep]
        left=np.stack([tables['dual',s].loc[ss,'Probability_score'] for s in SEEDS])
        bootstrap(task,'ours_minus_'+ref,ss,y,left,p,group.loc[ss].values,right_h=h)
    write_json(HERE/'ci_input_hashes.json',INPUTS)
    write_json(HERE/'interval_status.json',{'status':'complete','seconds':time.time()-start,'comparisons':len(COHORTS),'interval_rows':len(ROWS),'replicates_each':REPS})
    print('ALL INTERVALS COMPLETE',time.time()-start,flush=True)
if __name__=='__main__':main()
