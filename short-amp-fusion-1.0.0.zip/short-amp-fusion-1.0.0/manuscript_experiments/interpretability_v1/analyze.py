"""Post-hoc frozen-model attribution. No fitting, threshold tuning or sequence design."""
from pathlib import Path
import os,sys,json,re,hashlib,time,itertools,traceback
HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[1]
sys.path.insert(0,str(HERE/'deps'));sys.path.insert(0,str(ROOT/'manuscript_experiments/scripts'))
os.environ.setdefault('OMP_NUM_THREADS','4');os.environ.setdefault('OPENBLAS_NUM_THREADS','4')
from common_study import raw_official,transform,CFG,phys_raw
import numpy as np,pandas as pd,joblib,shap
from sklearn.metrics import f1_score,roc_auc_score,matthews_corrcoef,average_precision_score
from scipy.stats import spearmanr
from threadpoolctl import threadpool_limits
SEEDS=[42,43,44];RNG=20261112
GROUPS={'ESM2':np.arange(64),'ProtBERT':np.arange(64,128),'Composition_physics_length':np.arange(128,189),'Both_language_models':np.arange(128)}
BASEGROUPS=list(GROUPS)[:3]
CFGVAR=next(c for c in CFG['variants'] if c['name']=='dual64_phys')
def write(p,d):
 p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(d,ensure_ascii=False,indent=2,allow_nan=False)+'\n')
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(8<<20),b''):h.update(b)
 return h.hexdigest()
def hasharray(a):return hashlib.sha256(np.ascontiguousarray(a).tobytes()).hexdigest()
def status(s):write(HERE/'status.json',{'stage':s,'updated':time.strftime('%Y-%m-%d %H:%M:%S'),'pid':os.getpid()});print(s,flush=True)
def metrics(y,p):return {'f1':f1_score(y,p>.5),'auroc':roc_auc_score(y,p),'mcc':matthews_corrcoef(y,p>.5),'ap':average_precision_score(y,p)}
def load_battle(split):
 base=ROOT/'manuscript_experiments/battle_amp_v1';f=pd.read_csv(base/f'data/{split}.csv');ix=f.row_id.values
 return f,{k:np.asarray(np.load(base/f'features/{k}.npy',mmap_mode='r')[ix],dtype=np.float32 if k=='phys' else np.float64) for k in ['esm','prot','phys']}
def cohorts():
 b=ROOT/'manuscript_experiments';core=b/'results/core/dual64_phys';tf=joblib.load(core/'transforms.joblib')
 tr,raw=raw_official('train');tx=transform(raw,tf,CFGVAR);background_ids=np.random.default_rng(RNG).choice(len(tr),64,replace=False)
 f,raw=raw_official('test');yield 'original_short',f,transform(raw,tf,CFGVAR),raw['phys'],tx[background_ids],tr.iloc[background_ids].Sequence.tolist(),core,tf
 base=b/'battle_amp_v1/results/dual64_phys';tf=joblib.load(base/'transforms.joblib');tr,raw=load_battle('train');background_ids=np.random.default_rng(RNG).choice(len(tr),64,replace=False)
 bg=transform({k:v[background_ids] for k,v in raw.items()},tf,CFGVAR);bgseq=tr.iloc[background_ids].Sequence.tolist()
 f,raw=load_battle('test');yield 'battle_retrained',f,transform(raw,tf,CFGVAR),raw['phys'],bg,bgseq,base,tf
 off=b/'battle_official_v1';f=pd.read_csv(off/'upstream/datasets/holdout-2026/labels_broad_activity.tsv',sep='\t')
 f=f[f.sequence.map(lambda s:10<=len(s)<=100 and set(s)<=set('ACDEFGHIKLMNPQRSTVWY'))].copy().reset_index(drop=True)
 f=f.rename(columns={'sequence':'Sequence','label':'Label'});f['Label']=f.Label.map({'AMP':1,'non-AMP':0});assert f.Label.notna().all() and not f.Sequence.duplicated().any()
 allf=pd.read_csv(off/'data/sequences.csv');mapping=dict(zip(allf.sequence,range(len(allf))));ix=np.array([mapping[s] for s in f.Sequence]);raw={k:np.asarray(np.load(off/f'features/{k}.npy',mmap_mode='r')[ix],dtype=np.float32 if k=='phys' else np.float64) for k in ['esm','prot','phys']}
 assert len(f)==503
 yield 'holdout2026',f,transform(raw,tf,CFGVAR),raw['phys'],bg,bgseq,base,tf

def main():
 start=time.time();status('prepare protocol')
 labels=re.findall(r'# p\d+: (.*)',(ROOT/'PPsAMP/pipeline/compute_features.py').read_text());assert len(labels)==20
 aas=list('ACDEFGHIKLMNPQRSTVWY');names=[f'ESM2_PC{i+1:02}' for i in range(64)]+[f'ProtBERT_PC{i+1:02}' for i in range(64)]+[f'AAC_{a}' for a in aas]+[f'mean_{i+1:02}_{s}' for i,s in enumerate(labels)]+[f'sd_{i+1:02}_{s}' for i,s in enumerate(labels)]+['length_div30']
 pd.DataFrame({'feature_index':range(189),'feature':names,'source':['ESM2']*64+['ProtBERT']*64+['Composition_physics_length']*61}).to_csv(HERE/'feature_dictionary.csv',index=False)
 proto={'date':'2026-11-12','purpose':'Retrospective model-behavior analysis, no model selection or causal claims','seeds':SEEDS,'analysis_seed':RNG,'cohorts':['original_short','battle_retrained','holdout2026'],
 'shap_primary':{'method':'TreeExplainer tree_path_dependent','output':'raw binary log-odds','rows':'all cohort rows','background':'saved tree path counts; no explicit test background','feature_dependence':'tree path approximation, not conditional causal effect'},
 'shap_sensitivity':{'method':'interventional','output':'raw binary log-odds','background_n':64,'background_source':'uniform random training rows without labels; same rows for all three seeds','evaluation_n_max':256,'evaluation_selection':'uniform random rows without labels; same across seeds'},
 'group_permutation':{'groups':{k:v.tolist() for k,v in GROUPS.items()},'repeats':20,'rule':'one shared row permutation within each entire feature block; same permutation across groups and seeds','warning':'Breaks between-block dependencies and may create unsupported combinations. Measures model reliance, not unique information or a retrained ablation. Repeat SD is Monte Carlo variation, not confidence interval.'},
 'cases':'per TP/TN/FP/FN cell select row closest to median confidence of predicted class; ties by original row index; based on three-seed mean score for explanation only, not replacement of per-seed performance',
 'limitations':['Phys mean/SD are deterministic functions of AAC; not independent biological evidence.','Mean amino-acid pI is not peptide pI; per-residue propensity is not measured peptide structure.','PCA components are latent, not named biological mechanisms.','Summed SHAP by source is post-hoc aggregation, not a coalition-level Shapley computation.','Across-source attribution magnitudes are not fractions of biological causality or guaranteed unique signal.','Original test was already exposed during historical development; all new analyses are exploratory.','BATTLE test/holdout use extended fitted model; cross-cohort differences also include model/transform differences.'],
 'software':{'shap':shap.__version__},'script_sha256':sha(Path(__file__))}
 write(HERE/'protocol.json',proto)
 features=[];sources=[];perms=[];checks=[];sens=[];cases=[];cohortmeta=[]
 for cohort,f,x,physics,bg,bgseq,modelbase,tf in cohorts():
  status('analyzing '+cohort);out=HERE/cohort;out.mkdir(exist_ok=True);y=f.Label.values.astype(int);seq=f.Sequence.tolist();n=len(y)
  np.testing.assert_allclose(physics,phys_raw(seq),atol=1e-6,rtol=1e-6)
  cohortmeta.append({'cohort':cohort,'n':n,'positive':int(y.sum()),'negative':int(n-y.sum()),'x_sha256':hasharray(x),'labels_sha256':hasharray(y),'sequences_sha256':hashlib.sha256('\n'.join(seq).encode()).hexdigest(),'transforms_sha256':sha(modelbase/'transforms.joblib'),'background_sequences_sha256':hashlib.sha256('\n'.join(bgseq).encode()).hexdigest()})
  write(out/'background_sequences.json',bgseq)
  ix=np.sort(np.random.default_rng(RNG+1).choice(n,min(n,256),replace=False));pd.DataFrame({'row_index':ix}).to_csv(out/'sensitivity_rows.csv',index=False)
  phis=[];probs=[];bases=[];ranks=[];sourceprofiles=[]
  for seed in SEEDS:
   status(f'{cohort} seed {seed}: prediction parity and SHAP')
   modelpath=modelbase/f'seed_{seed}/model.joblib';model=joblib.load(modelpath);before=sha(modelpath);p=model.predict_proba(x)[:,1]
   if cohort=='holdout2026':
    old=pd.read_csv(ROOT/f'manuscript_experiments/battle_official_v1/predictions/extended_dual_{seed}.tsv',sep='\t').set_index('sequence').loc[seq];oldp=old.Probability_score.values
   else:
    old=pd.read_csv(modelbase/f'seed_{seed}/test_predictions.csv');assert old.sequence.tolist()==seq;np.testing.assert_array_equal(old.label.values,y);oldp=old.probability_amp.values
   err=float(np.max(np.abs(p-oldp)));assert err<1e-9
   ex=shap.TreeExplainer(model,feature_perturbation='tree_path_dependent',model_output='raw');v=ex.shap_values(x,check_additivity=True);base=float(np.asarray(ex.expected_value).reshape(-1)[0]);margin=model.decision_function(x)
   add=float(np.max(np.abs(v.sum(1)+base-margin)));assert add<1e-7 and v.shape==x.shape
   phis.append(v);probs.append(p);bases.append(base);np.savez_compressed(out/f'shap_seed_{seed}.npz',values=v,base=base,row_index=np.arange(n),probability=p)
   featureimp=np.abs(v).mean(0);ranks.append(featureimp)
   for j,name in enumerate(names):
    corr=spearmanr(x[:,j],v[:,j]).statistic if np.std(x[:,j])>0 and np.std(v[:,j])>0 else np.nan
    features.append({'cohort':cohort,'seed':seed,'feature_index':j,'feature':name,'source':BASEGROUPS[0 if j<64 else 1 if j<128 else 2],'mean_abs_shap_logodds':featureimp[j],'mean_signed_shap_logodds':v[:,j].mean(),'spearman_feature_vs_shap':corr})
   groupv=np.column_stack([v[:,GROUPS[g]].sum(1) for g in BASEGROUPS]);sourceprofiles.append(np.abs(groupv).mean(0))
   for j,g in enumerate(BASEGROUPS):sources.append({'cohort':cohort,'seed':seed,'source':g,'mean_abs_summed_shap_logodds':np.abs(groupv[:,j]).mean(),'mean_sum_abs_feature_shap_logodds':np.abs(v[:,GROUPS[g]]).sum(1).mean(),'mean_signed_summed_shap_logodds':groupv[:,j].mean()})
   ev=shap.TreeExplainer(model,data=bg,feature_perturbation='interventional',model_output='raw');sv=ev.shap_values(x[ix],check_additivity=True);sb=float(np.asarray(ev.expected_value).reshape(-1)[0]);sa=float(np.max(np.abs(sv.sum(1)+sb-margin[ix])));assert sa<1e-4
   np.savez_compressed(out/f'interventional_seed_{seed}.npz',values=sv,base=sb,row_index=ix)
   for g in BASEGROUPS:sens.append({'cohort':cohort,'seed':seed,'source':g,'path_dependent_matched_mean_abs_group':np.abs(v[ix][:,GROUPS[g]].sum(1)).mean(),'interventional_mean_abs_group':np.abs(sv[:,GROUPS[g]].sum(1)).mean(),'feature_rank_spearman':spearmanr(np.abs(v[ix]).mean(0),np.abs(sv).mean(0)).statistic})
   status(f'{cohort} seed {seed}: grouped permutation')
   original=metrics(y,p)
   for repeat in range(20):
    order=np.random.default_rng(RNG+100+repeat).permutation(n)
    for g,cols in GROUPS.items():
     xx=x.copy();xx[:,cols]=x[order][:,cols];mp=metrics(y,model.predict_proba(xx)[:,1])
     for m in original:perms.append({'cohort':cohort,'seed':seed,'repeat':repeat,'source':g,'metric':m,'original':original[m],'permuted':mp[m],'decrease':original[m]-mp[m]})
   assert sha(modelpath)==before
   checks.append({'cohort':cohort,'seed':seed,'n':n,'checkpoint_sha256':before,'checkpoint_unchanged':True,'prediction_max_abs_error':err,'path_additivity_max_abs_error':add,'interventional_additivity_max_abs_error':sa,**original})
   # Flush tables after each seed; long-running job can be inspected without rerunning.
   for name,rows in [('feature_shap',features),('source_shap',sources),('group_permutation',perms),('prediction_checks',checks),('sensitivity',sens)]:pd.DataFrame(rows).to_csv(HERE/f'{name}.csv',index=False)
  meanp=np.mean(probs,0);meanv=np.mean(phis,0);pd.DataFrame({'row_index':range(n),'sequence':seq,'label':y,'mean_probability':meanp}).to_csv(out/'cohort_predictions.csv',index=False)
  stability=[]
  for i,j in itertools.combinations(range(3),2):
   a=set(np.argsort(ranks[i][128:])[-10:]);b=set(np.argsort(ranks[j][128:])[-10:]);stability.append({'seed_a':SEEDS[i],'seed_b':SEEDS[j],'phys_rank_spearman':float(spearmanr(ranks[i][128:],ranks[j][128:]).statistic),'phys_top10_jaccard':len(a&b)/len(a|b)})
  write(out/'seed_stability.json',stability)
  for lab,pred,cell in [(1,1,'TP'),(0,0,'TN'),(0,1,'FP'),(1,0,'FN')]:
   ids=np.flatnonzero((y==lab)&((meanp>.5)==pred))
   if not len(ids):continue
   confidence=meanp[ids] if pred else 1-meanp[ids];chosen=int(ids[np.argmin(np.abs(confidence-np.median(confidence)))])
   row={'cohort':cohort,'cell':cell,'row_index':chosen,'sequence':seq[chosen],'label':lab,'mean_probability':float(meanp[chosen]),'mean_base_logodds':float(np.mean(bases)),'mean_margin':float(meanv[chosen].sum()+np.mean(bases)), 'note':'mean of model logodds explanations is not logit(mean probability)'}
   for g in BASEGROUPS:row[g+'_contribution']=float(meanv[chosen,GROUPS[g]].sum())
   for rank,j in enumerate(128+np.argsort(np.abs(meanv[chosen,128:]))[-5:][::-1]):row[f'phys_{rank+1}']=names[j];row[f'phys_{rank+1}_shap']=float(meanv[chosen,j]);row[f'phys_{rank+1}_raw_value']=float(physics[chosen,j-128])
   cases.append(row)
  corr=pd.DataFrame(physics,columns=names[128:]).corr(method='spearman');corr.to_csv(out/'descriptor_spearman_correlation.csv')
  pd.DataFrame({'cohort':cohort,'feature_index':range(189),'feature':names,'mean_abs_shap_across_seeds':np.mean(ranks,0),'seed_sd_mean_abs_shap':np.std(ranks,0,ddof=1)}).to_csv(out/'feature_summary.csv',index=False)
 write(HERE/'cohorts.json',cohortmeta);pd.DataFrame(cases).to_csv(HERE/'local_cases.csv',index=False)
 for file,groups,col in [('source_shap',['cohort','source'],'mean_abs_summed_shap_logodds'),('group_permutation',['cohort','source','metric'],'decrease')]:
  d=pd.read_csv(HERE/f'{file}.csv')
  if file=='group_permutation':d=d.groupby(groups+['seed'],as_index=False)[col].mean()
  d.groupby(groups)[col].agg(['mean','std','min','max']).reset_index().to_csv(HERE/f'{file}_summary.csv',index=False)
 write(HERE/'validation.json',{'passed':True,'seeds':SEEDS,'evaluations':len(checks),'parity_max_error':max(c['prediction_max_abs_error'] for c in checks),'shap_additivity_checked':True,'retrained':False,'elapsed_seconds':time.time()-start})
 status('complete')
if __name__=='__main__':
 try:
  with threadpool_limits(limits=4):main()
 except Exception:
  write(HERE/'failure.json',{'traceback':traceback.format_exc()});raise
