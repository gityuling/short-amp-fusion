"""Exploratory follow-up prompted by high length attribution; frozen models only."""
from analyze import *
def main():
 write(HERE/'length_audit_protocol.json',{'trigger':'Post-hoc follow-up: length ranked first among explicit descriptors on original/BATTLE test','selection':'No training or model change','repeats':20,'random_seed':RNG+500,'experiments':['all 61 descriptors jointly permuted within exact sequence length','ESM2 block permuted within exact sequence length','ProtBERT block permuted within exact sequence length','length-only global permutation','60 composition/physics columns jointly permuted globally with length fixed'],'limitations':'Conditional permutation preserves exact length only, not general dependencies. Singleton length strata unchanged. Length-only score direction determined from matching training labels; descriptive diagnostic, not a trained baseline.'})
 rows=[];diagnostics=[];distribution=[]
 for c,f,x,physics,bg,bgseq,modelbase,tf in cohorts():
  y=f.Label.values.astype(int);lengths=f.Sequence.str.len().values;n=len(f);strata=[np.flatnonzero(lengths==l) for l in np.unique(lengths)];eligible=sum(len(z) for z in strata if len(z)>1)/n
  if c=='original_short':tr=pd.read_csv(ROOT/'reproduction/assets/upstream/data/train_dedup_split.csv')
  else:tr=pd.read_csv(ROOT/'manuscript_experiments/battle_amp_v1/data/train.csv')
  direction=1 if tr[tr.Label==1].Sequence.str.len().mean()>tr[tr.Label==0].Sequence.str.len().mean() else -1
  diagnostics.append({'cohort':c,'n':n,'positive_mean_length':float(lengths[y==1].mean()),'negative_mean_length':float(lengths[y==0].mean()),'length_only_direction_from_train':direction,'length_only_auroc':roc_auc_score(y,direction*lengths),'within_length_non_singleton_fraction':eligible})
  for l in np.unique(lengths):
   part=y[lengths==l];distribution.append({'cohort':c,'length':int(l),'n':len(part),'positive':int(part.sum()),'positive_fraction':float(part.mean())})
  groups={'descriptors_within_exact_length':np.arange(128,189),'ESM2_within_exact_length':np.arange(64),'ProtBERT_within_exact_length':np.arange(64,128),'length_only_global':np.array([188]),'composition_physics60_global':np.arange(128,188)}
  for seed in SEEDS:
   model=joblib.load(modelbase/f'seed_{seed}/model.joblib');original=metrics(y,model.predict_proba(x)[:,1])
   for repeat in range(20):
    rng=np.random.default_rng(RNG+500+repeat);globalorder=rng.permutation(n);conditional=np.arange(n)
    for indices in strata:conditional[indices]=rng.permutation(indices)
    for name,cols in groups.items():
     order=conditional if 'within' in name else globalorder;xx=x.copy();xx[:,cols]=x[order][:,cols];m=metrics(y,model.predict_proba(xx)[:,1])
     for metric in original:rows.append({'cohort':c,'seed':seed,'repeat':repeat,'experiment':name,'metric':metric,'decrease':original[metric]-m[metric]})
   print(c,seed,'complete',flush=True)
 pd.DataFrame(rows).to_csv(HERE/'length_controlled_permutation.csv',index=False)
 d=pd.DataFrame(rows).groupby(['cohort','seed','experiment','metric'],as_index=False).decrease.mean()
 d.groupby(['cohort','experiment','metric']).decrease.agg(['mean','std']).reset_index().to_csv(HERE/'length_controlled_summary.csv',index=False)
 pd.DataFrame(diagnostics).to_csv(HERE/'length_diagnostics.csv',index=False);pd.DataFrame(distribution).to_csv(HERE/'length_label_distribution.csv',index=False)
if __name__=='__main__':
 with threadpool_limits(limits=4):main()
