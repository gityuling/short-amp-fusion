"""Download pinned public inputs to an explicit work root; SHA256 verification required."""
from pathlib import Path
import argparse,hashlib,json,shutil,urllib.request,time
PACKAGE=Path(__file__).resolve().parents[1]
def digest(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(8<<20),b''):h.update(b)
 return h.hexdigest()
def main():
 ap=argparse.ArgumentParser(description=__doc__)
 ap.add_argument('--group',action='append',required=True,help='Repeat to select groups; --list shows entries without downloading')
 ap.add_argument('--root',type=Path,help='Separate research working directory')
 ap.add_argument('--list',action='store_true');ap.add_argument('--verify-only',action='store_true')
 a=ap.parse_args();allrows=json.loads((PACKAGE/'metadata/download_registry.json').read_text())['assets']
 groups={r['group'] for r in allrows};unknown=set(a.group)-groups
 if unknown:ap.error('Unknown groups '+str(unknown)+'; available: '+', '.join(sorted(groups)))
 rows=[r for r in allrows if r['group'] in a.group]
 if a.list:
  print(json.dumps({'files':len(rows),'total_bytes':sum(r['bytes'] for r in rows),'assets':rows},ensure_ascii=False,indent=2));return
 if a.root is None:ap.error('--root is required for download or verification')
 root=a.root.resolve();fail=[]
 for r in rows:
  dest=(root/r['target']).resolve()
  if not dest.is_relative_to(root):raise ValueError('Unsafe destination')
  if dest.is_file() and dest.stat().st_size==r['bytes'] and digest(dest)==r['sha256']:
   print('VERIFIED',r['target']);continue
  if a.verify_only:fail.append(r['target']);continue
  if dest.exists():raise RuntimeError(f'Existing mismatching file: {dest}; preserve it and select a clean work root')
  dest.parent.mkdir(parents=True,exist_ok=True);part=dest.with_name(dest.name+'.partial')
  for attempt in range(3):
   try:
    req=urllib.request.Request(r['url'],headers={'User-Agent':'AMP-research-reproduction/2'})
    with urllib.request.urlopen(req,timeout=90) as response,part.open('wb') as out:shutil.copyfileobj(response,out,8<<20)
    if part.stat().st_size!=r['bytes'] or digest(part)!=r['sha256']:raise RuntimeError('Size/SHA256 mismatch; upstream input changed')
    part.replace(dest);print('DOWNLOADED AND VERIFIED',r['target']);break
   except Exception:
    if attempt==2:raise
    time.sleep(2)
 if fail:raise SystemExit(json.dumps({'missing_or_mismatched':fail},ensure_ascii=False))
 print(json.dumps({'passed':True,'files_verified':len(rows),'network_used':not a.verify_only}))
if __name__=='__main__':main()
