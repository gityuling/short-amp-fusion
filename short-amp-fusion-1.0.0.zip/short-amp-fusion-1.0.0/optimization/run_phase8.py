"""Frozen ESM-2 versus complementary ESM-2/ProtBERT features, validation only."""
import json
import time
import joblib
import numpy as np
import pandas as pd
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA
from sklearn.ensemble import HistGradientBoostingClassifier
from threadpoolctl import threadpool_limits
from run_phase1 import ROOT, DevelopmentDataset, metrics, setup, sha256, write_json
from run_phase2 import vectors

PATH = ROOT / 'optimization/phase8_protocol.json'
CFG = json.loads(PATH.read_text())
OUT = ROOT / 'optimization/phase8'
CACHE = ROOT / 'optimization/features/esm2_150m'


def main():
    setup()
    train = DevelopmentDataset('train')
    val = DevelopmentDataset('val', train.scaler)
    data = {}
    manifest = json.loads((CACHE / 'manifest.json').read_text())
    for split, ds in [('train', train), ('val', val)]:
        p = CACHE / f'{split}.npz'
        assert sha256(p) == manifest['splits'][split]['cache_sha256']
        archive = np.load(p)
        assert archive['sequences'].tolist() == ds.sequences
        np.testing.assert_array_equal(archive['labels'], ds.labels.numpy())
        data[split] = archive['embeddings'].astype(np.float64)
    rows = []
    with threadpool_limits(limits=4):
        for cfg in CFG['candidates']:
            transforms = {'phys_scaler': train.scaler}
            train_parts, val_parts = [], []
            for name, dimension, raw, rv in [
                ('esm', cfg['esm_components'], data['train'], data['val']),
                ('protbert', cfg['protbert_components'], vectors(train, 'semantic'), vectors(val, 'semantic'))]:
                if not dimension:
                    continue
                scaler = StandardScaler()
                pca = PCA(n_components=dimension, svd_solver='randomized', random_state=42, iterated_power=3)
                train_parts.append(pca.fit_transform(scaler.fit_transform(raw)))
                val_parts.append(pca.transform(scaler.transform(rv)))
                transforms[name] = {'scaler': scaler, 'pca': pca}
            x = np.concatenate(train_parts + [train.global_features.numpy()], axis=1)
            v = np.concatenate(val_parts + [val.global_features.numpy()], axis=1)
            out = OUT / cfg['name']
            out.mkdir(parents=True, exist_ok=True)
            joblib.dump(transforms, out / 'transforms.joblib')
            for seed in CFG['seeds']:
                dest = out / f'seed_{seed}'
                dest.mkdir(parents=True, exist_ok=True)
                if (dest / 'result.json').exists():
                    result = json.loads((dest / 'result.json').read_text())
                    assert result['code_sha256'] == sha256(__file__)
                    assert result['protocol_sha256'] == sha256(PATH)
                    assert result['transform_sha256'] == sha256(out / 'transforms.joblib')
                else:
                    start = time.time()
                    print(f"START {cfg['name']} seed={seed}", flush=True)
                    model = HistGradientBoostingClassifier(**CFG['fixed'], random_state=seed)
                    model.fit(x, train.labels.numpy())
                    probabilities = model.predict_proba(v)[:, 1]
                    score = metrics(val.labels.numpy(), probabilities)
                    joblib.dump(model, dest / 'model.joblib')
                    pd.DataFrame({'sequence': val.sequences, 'label': val.labels.numpy(), 'probability_amp': probabilities}).to_csv(dest / 'validation_predictions.csv', index=False)
                    result = {'config': cfg, 'seed': seed, 'validation': score, 'elapsed_seconds': time.time() - start,
                        'code_sha256': sha256(__file__), 'protocol_sha256': sha256(PATH),
                        'checkpoint_sha256': sha256(dest / 'model.joblib'), 'transform_sha256': sha256(out / 'transforms.joblib'),
                        'encoder_cache_manifest_sha256': sha256(CACHE / 'manifest.json'), 'test_evaluated': False}
                    write_json(dest / 'result.json', result)
                rows.append({'name': cfg['name'], 'seed': seed, **{k: z for k, z in result['validation'].items() if k != 'confusion'}})
                pd.DataFrame(rows).to_csv(OUT / 'validation_results.csv', index=False)
                print(f"DONE {cfg['name']} seed={seed} F1={result['validation']['f1']:.6f}", flush=True)
    summary = pd.DataFrame(rows).groupby('name').agg(f1_mean=('f1', 'mean'), f1_std=('f1', 'std'),
        auc_mean=('auc', 'mean'), mcc_mean=('mcc', 'mean'), average_precision_mean=('average_precision', 'mean'),
        precision_mean=('precision', 'mean'), recall_mean=('recall', 'mean'))
    summary.to_csv(OUT / 'summary.csv')
    print(summary.to_string(), flush=True)


if __name__ == '__main__':
    main()
