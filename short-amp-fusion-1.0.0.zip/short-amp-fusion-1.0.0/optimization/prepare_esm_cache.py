"""Fetch a pinned public encoder and extract train/val pooled representations only."""
import json
import time
import requests
import numpy as np
import pandas as pd
import torch
from transformers import AutoTokenizer, EsmModel
from run_phase1 import ROOT, ASSETS, setup, sha256, write_json

PATH = ROOT / 'optimization/phase8_protocol.json'
CFG = json.loads(PATH.read_text())['encoder']
DEST = ROOT / 'optimization/assets/esm2_150m'
OUT = ROOT / 'optimization/features/esm2_150m'


def download():
    DEST.mkdir(parents=True, exist_ok=True)
    api = f"https://huggingface.co/api/models/{CFG['repo']}/revision/{CFG['revision']}?blobs=true"
    response = requests.get(api, timeout=30)
    response.raise_for_status()
    metadata = response.json()
    assert metadata['sha'] == CFG['revision']
    wanted = ['config.json', 'model.safetensors', 'special_tokens_map.json', 'tokenizer_config.json', 'vocab.txt']
    files = {}
    for name in wanted:
        record = next(x for x in metadata['siblings'] if x['rfilename'] == name)
        target = DEST / name
        expected = record.get('lfs', {}).get('sha256')
        if not target.exists():
            print(f'Downloading {name}', flush=True)
            url = f"https://huggingface.co/{CFG['repo']}/resolve/{CFG['revision']}/{name}"
            temp = target.with_suffix(target.suffix + '.part')
            with requests.get(url, stream=True, timeout=(30, 60)) as result:
                result.raise_for_status()
                with temp.open('wb') as f:
                    for chunk in result.iter_content(4 << 20):
                        f.write(chunk)
            assert temp.stat().st_size == record['size']
            if expected:
                assert sha256(temp) == expected
            temp.replace(target)
        assert target.stat().st_size == record['size']
        digest = sha256(target)
        if expected:
            assert digest == expected
        files[name] = {'sha256': digest, 'bytes': target.stat().st_size, 'upstream_lfs_sha256': expected}
    write_json(DEST / 'manifest.json', {'repo': CFG['repo'], 'revision': CFG['revision'], 'files': files})


@torch.no_grad()
def main():
    setup()
    download()
    OUT.mkdir(parents=True, exist_ok=True)
    tokenizer = AutoTokenizer.from_pretrained(DEST, local_files_only=True)
    model = EsmModel.from_pretrained(DEST, local_files_only=True, add_pooling_layer=False).cuda().eval()
    def embed(sequences):
        inputs = tokenizer(sequences, padding='max_length', max_length=32, truncation=False, return_tensors='pt')
        lengths = torch.tensor([len(s) for s in sequences], device='cuda')
        mask = (torch.arange(32, device='cuda')[None, :] > 0) & (torch.arange(32, device='cuda')[None, :] <= lengths[:, None])
        assert inputs['input_ids'].shape[1] == 32
        assert torch.equal(inputs['attention_mask'].sum(1), lengths.cpu() + 2)
        hidden = model(**{k: v.cuda() for k, v in inputs.items()}).last_hidden_state
        mean = (hidden * mask.unsqueeze(-1)).sum(1) / lengths[:, None]
        maximum = hidden.masked_fill(~mask.unsqueeze(-1), -torch.inf).max(1).values
        return torch.cat([hidden[:, 0], mean, maximum], dim=1).cpu().numpy()
    report = {'encoder': CFG, 'model_files_manifest_sha256': sha256(DEST / 'manifest.json'),
              'code_sha256': sha256(__file__), 'protocol_sha256': sha256(PATH), 'splits': {}, 'test_accessed': False}
    for split in ('train', 'val'):
        frame = pd.read_csv(ASSETS / 'data' / f'{split}_dedup_split.csv')
        assert frame.Sequence.str.len().between(11, 30).all()
        target = OUT / f'{split}.npz'
        if target.exists():
            cached = np.load(target)
            assert cached['sequences'].tolist() == frame.Sequence.tolist()
            previous = json.loads((OUT / 'manifest.json').read_text())
            assert previous['code_sha256'] == sha256(__file__)
            assert previous['protocol_sha256'] == sha256(PATH)
            assert previous['splits'][split]['cache_sha256'] == sha256(target)
            report['splits'][split] = previous['splits'][split]
            continue
        start = time.time()
        chunks = []
        for start_idx in range(0, len(frame), CFG['batch_size']):
            chunks.append(embed(frame.Sequence.iloc[start_idx:start_idx + CFG['batch_size']].tolist()))
            if start_idx % 512 == 0:
                print(f'{split} {start_idx}/{len(frame)}', flush=True)
        embeddings = np.concatenate(chunks)
        assert embeddings.shape == (len(frame), 3 * model.config.hidden_size) and np.isfinite(embeddings).all()
        parity = float(np.max(np.abs(embed(frame.Sequence.iloc[:1].tolist())[0] - embeddings[0])))
        assert parity < 1e-3, parity
        np.savez(target, embeddings=embeddings, labels=frame.Label.values, sequences=frame.Sequence.values.astype(str))
        report['splits'][split] = {'rows': len(frame), 'dimensions': embeddings.shape[1],
            'input_csv_sha256': sha256(ASSETS / 'data' / f'{split}_dedup_split.csv'),
            'cache_sha256': sha256(target), 'single_vs_batch_max_error': parity, 'elapsed_seconds': time.time() - start}
        write_json(OUT / 'manifest.json', report)
    write_json(OUT / 'manifest.json', report)
    print(json.dumps(report, indent=2), flush=True)


if __name__ == '__main__':
    main()
