"""Validation-only, predeclared three-seed study of local physicochemical fusion."""
import json
from pathlib import Path
import sys
import time

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "reproduction/scripts"))
from common import ASSETS, FEATURES, setup, sha256, write_json
import h5py
import numpy as np
import pandas as pd
import torch
from torch import nn
from torch.utils.data import Dataset, DataLoader
from sklearn.metrics import (accuracy_score, precision_score, recall_score, f1_score,
                             matthews_corrcoef, roc_auc_score, average_precision_score, confusion_matrix)
from compute_features import AA_PROPERTIES, AA_TO_IDX

PROTOCOL_PATH = ROOT / "optimization/protocol.json"
PROTOCOL = json.loads(PROTOCOL_PATH.read_text())
PARAM = PROTOCOL["phase_1_training"]


class DevelopmentDataset(Dataset):
    def __init__(self, split, scaler=None):
        if split not in ("train", "val"):
            raise ValueError("Development code cannot load the test split")
        source = pd.read_csv(ASSETS / "data" / f"{split}_dedup_split.csv")
        with h5py.File(FEATURES / f"{split}_tokens.h5") as f:
            assert source.Sequence.tolist() == f["sequences"].asstr()[:].tolist()
            assert np.array_equal(source.Label.values, f["labels"][:])
            # Keep positions 1..30 for residues; CLS is represented separately.
            all_tokens = f["embeddings"][:]
        self.cls = torch.from_numpy(all_tokens[:, 0, :].copy())
        self.tokens = torch.from_numpy(all_tokens[:, 1:31, :].copy())
        self.labels = torch.tensor(source.Label.values, dtype=torch.long)
        self.sequences = source.Sequence.tolist()
        self.lengths = torch.tensor(source.Sequence.str.len().values, dtype=torch.long)
        self.mask = torch.arange(30)[None, :] < self.lengths[:, None]
        self.tokens *= self.mask.unsqueeze(-1)
        # Standardization across the amino-acid alphabet does not depend on any split.
        props = (AA_PROPERTIES - AA_PROPERTIES.mean(1, keepdims=True)) / AA_PROPERTIES.std(1, keepdims=True)
        local = np.zeros((len(source), 30, 20), dtype=np.float32)
        global_features = []
        for i, sequence in enumerate(self.sequences):
            idx = np.array([AA_TO_IDX[a] for a in sequence])
            values = props[:, idx].T
            local[i, :len(idx)] = values
            composition = np.bincount(idx, minlength=20) / len(idx)
            global_features.append(np.concatenate([composition, values.mean(0), values.std(0), [len(idx) / 30]]))
        raw = np.asarray(global_features, dtype=np.float32)
        if scaler is None:
            if split != "train":
                raise ValueError("Global feature scaler must be fitted on train only")
            scaler = (raw.mean(0), np.maximum(raw.std(0), 1e-6))
        self.scaler = scaler
        self.global_features = torch.from_numpy((raw - scaler[0]) / scaler[1])
        self.local = torch.from_numpy(local)

    def __len__(self):
        return len(self.labels)

    def __getitem__(self, i):
        return self.tokens[i], self.cls[i], self.mask[i], self.local[i], self.global_features[i], self.labels[i]


class FusionModel(nn.Module):
    def __init__(self, variant):
        super().__init__()
        self.variant = variant
        d, drop = PARAM["hidden_dim"], PARAM["dropout"]
        self.projection = nn.Sequential(nn.Linear(1024, d), nn.LayerNorm(d), nn.GELU())
        self.attention_score = nn.Sequential(nn.Linear(d, 32), nn.Tanh(), nn.Linear(32, 1))
        if variant != "sequence_pool":
            self.phys_global = nn.Sequential(nn.Linear(61, 64), nn.LayerNorm(64), nn.GELU(), nn.Dropout(drop))
        if variant == "local_phys":
            self.phys_local = nn.Sequential(nn.Conv1d(20, 64, 3, padding=1), nn.GELU(),
                                            nn.Conv1d(64, d, 3, padding=1))
            self.gate = nn.Linear(2 * d, d)
            self.fusion_norm = nn.LayerNorm(d)
        width = 4 * d + (64 if variant != "sequence_pool" else 0)
        self.classifier = nn.Sequential(nn.LayerNorm(width), nn.Dropout(drop), nn.Linear(width, d),
                                        nn.GELU(), nn.Dropout(drop), nn.Linear(d, 2))

    def forward(self, tokens, cls, mask, local, global_features):
        x = self.projection(tokens)
        if self.variant == "local_phys":
            phys = self.phys_local(local.transpose(1, 2)).transpose(1, 2)
            gate = torch.sigmoid(self.gate(torch.cat([x, phys], dim=-1)))
            x = self.fusion_norm(x + gate * phys)
        valid = mask.unsqueeze(-1)
        mean = (x * valid).sum(1) / mask.sum(1, keepdim=True)
        maximum = x.masked_fill(~valid, -torch.inf).max(1).values
        scores = self.attention_score(x).squeeze(-1).masked_fill(~mask, -torch.inf)
        attentive = (x * scores.softmax(1).unsqueeze(-1)).sum(1)
        components = [self.projection(cls), mean, maximum, attentive]
        if self.variant != "sequence_pool":
            components.append(self.phys_global(global_features))
        return self.classifier(torch.cat(components, dim=-1))


def metrics(labels, probabilities):
    prediction = (probabilities > .5).astype(int)
    tn, fp, fn, tp = confusion_matrix(labels, prediction, labels=[0, 1]).ravel()
    return {"f1": float(f1_score(labels, prediction, zero_division=0)),
            "mcc": float(matthews_corrcoef(labels, prediction)),
            "auc": float(roc_auc_score(labels, probabilities)),
            "average_precision": float(average_precision_score(labels, probabilities)),
            "accuracy": float(accuracy_score(labels, prediction)),
            "precision": float(precision_score(labels, prediction, zero_division=0)),
            "recall": float(recall_score(labels, prediction, zero_division=0)),
            "specificity": float(tn / (tn + fp)),
            "confusion": [int(tn), int(fp), int(fn), int(tp)]}


@torch.no_grad()
def evaluate(model, loader, loss_fn):
    model.eval()
    probabilities, labels, losses = [], [], []
    for batch in loader:
        *inputs, y = [t.cuda() for t in batch]
        logits = model(*inputs)
        losses.append(loss_fn(logits, y).item())
        probabilities.extend(logits.softmax(-1)[:, 1].cpu().tolist())
        labels.extend(y.cpu().tolist())
    result = metrics(np.array(labels), np.array(probabilities))
    result["loss"] = float(np.mean(losses))
    return result, probabilities


def train_one(variant, seed, train, validation):
    setup(seed)
    out = ROOT / "optimization/results" / variant / f"seed_{seed}"
    if (out / "result.json").exists():
        old = json.loads((out / "result.json").read_text())
        assert old["protocol_sha256"] == sha256(PROTOCOL_PATH)
        assert old["code_sha256"] == sha256(__file__)
        return old
    out.mkdir(parents=True, exist_ok=True)
    train_loader = DataLoader(train, batch_size=PARAM["batch_size"], shuffle=True)
    val_loader = DataLoader(validation, batch_size=64)
    model = FusionModel(variant).cuda()
    criterion = nn.CrossEntropyLoss(weight=torch.tensor([1.0, 3210 / 1514], device="cuda"))
    optimizer = torch.optim.AdamW(model.parameters(), lr=PARAM["lr"], weight_decay=PARAM["weight_decay"])
    scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(optimizer, mode="max", factor=.5, patience=5)
    history, best, patience, best_epoch = [], -1., 0, 0
    start = time.time()
    print(f"START {variant} seed={seed}", flush=True)
    for epoch in range(1, PARAM["epochs"] + 1):
        model.train()
        train_loss = []
        for batch in train_loader:
            *inputs, y = [t.cuda() for t in batch]
            optimizer.zero_grad()
            logits = model(*inputs)
            loss = criterion(logits, y)
            loss.backward()
            nn.utils.clip_grad_norm_(model.parameters(), 1.0)
            optimizer.step()
            train_loss.append(loss.item())
        result, probabilities = evaluate(model, val_loader, criterion)
        scheduler.step(result["f1"])
        history.append({"epoch": epoch, "train_loss": float(np.mean(train_loss)), "validation": result})
        write_json(out / "history.json", history)
        if result["f1"] > best:
            best, best_epoch, patience = result["f1"], epoch, 0
            torch.save(model.state_dict(), out / "best_model.pt")
            best_result = result
            pd.DataFrame({"sequence": validation.sequences, "label": validation.labels.numpy(),
                          "probability_amp": probabilities}).to_csv(out / "validation_predictions.csv", index=False)
        else:
            patience += 1
        print(f"{variant} s{seed} epoch={epoch} val_f1={result['f1']:.4f} val_auc={result['auc']:.4f} best={best:.4f}", flush=True)
        if patience >= PARAM["patience"]:
            break
    summary = {"variant": variant, "seed": seed, "best_epoch": best_epoch, "epochs": epoch,
               "validation": best_result, "elapsed_seconds": time.time() - start,
               "parameters": sum(p.numel() for p in model.parameters()),
               "protocol_sha256": sha256(PROTOCOL_PATH), "code_sha256": sha256(__file__),
               "checkpoint_sha256": sha256(out / "best_model.pt"), "test_evaluated": False}
    write_json(out / "result.json", summary)
    print(f"DONE {variant} s{seed}: {best_result}", flush=True)
    return summary


def main():
    setup()
    train = DevelopmentDataset("train")
    validation = DevelopmentDataset("val", train.scaler)
    write_json(ROOT / "optimization/train_feature_scaler.json", {"mean": train.scaler[0].tolist(), "std": train.scaler[1].tolist()})
    rows = []
    for variant in PROTOCOL["phase_1_variants"]:
        for seed in PROTOCOL["seeds"]:
            result = train_one(variant, seed, train, validation)
            rows.append({"variant": variant, "seed": seed, "best_epoch": result["best_epoch"],
                         **{k: v for k, v in result["validation"].items() if k != "confusion"}})
            pd.DataFrame(rows).to_csv(ROOT / "optimization/validation_results.csv", index=False)
    summary = pd.DataFrame(rows).groupby("variant").agg(f1_mean=("f1", "mean"), f1_std=("f1", "std"),
        mcc_mean=("mcc", "mean"), auc_mean=("auc", "mean"), average_precision_mean=("average_precision", "mean"))
    summary.to_csv(ROOT / "optimization/validation_summary.csv")
    print(summary.to_string(), flush=True)


if __name__ == "__main__":
    main()
