"""Bounded validation-only regularization and linear-control study."""
import argparse
import json
import time
from pathlib import Path
import numpy as np
import pandas as pd
import torch
from torch import nn
from torch.utils.data import DataLoader
from run_phase1 import (ROOT, PARAM, DevelopmentDataset, FusionModel, evaluate, metrics,
                        setup, sha256, write_json)

PROTOCOL_PATH = ROOT / "optimization/phase2_protocol.json"
PROTOCOL = json.loads(PROTOCOL_PATH.read_text())
OUT = ROOT / "optimization/phase2"


def train_neural(cfg, seed, train, val):
    setup(seed)
    out = OUT / cfg["name"] / f"seed_{seed}"
    if (out / "result.json").exists():
        result = json.loads((out / "result.json").read_text())
        assert result["code_sha256"] == sha256(__file__)
        assert result["protocol_sha256"] == sha256(PROTOCOL_PATH)
        return result
    out.mkdir(parents=True, exist_ok=True)
    PARAM.update(hidden_dim=cfg["hidden_dim"], dropout=cfg["dropout"])
    model = FusionModel("global_phys").cuda()
    train_loader = DataLoader(train, batch_size=32, shuffle=True)
    val_loader = DataLoader(val, batch_size=64)
    weights = torch.tensor([1., cfg["class_weight"]], device="cuda")
    criterion = nn.CrossEntropyLoss(weight=weights, label_smoothing=cfg["label_smoothing"])
    optimizer = torch.optim.AdamW(model.parameters(), lr=cfg["lr"], weight_decay=cfg["weight_decay"])
    scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(optimizer, mode="max", factor=.5, patience=5)
    start = time.time()
    best, stall, best_epoch, history = -1., 0, 0, []
    print(f"START {cfg['name']} seed={seed}", flush=True)
    for epoch in range(1, 101):
        model.train()
        train_loss = []
        for batch in train_loader:
            *x, y = [t.cuda() for t in batch]
            optimizer.zero_grad()
            loss = criterion(model(*x), y)
            loss.backward()
            nn.utils.clip_grad_norm_(model.parameters(), 1.)
            optimizer.step()
            train_loss.append(loss.item())
        score, probabilities = evaluate(model, val_loader, criterion)
        scheduler.step(score["f1"])
        history.append({"epoch": epoch, "train_loss": float(np.mean(train_loss)), "validation": score})
        write_json(out / "history.json", history)
        if score["f1"] > best:
            best, best_epoch, stall, best_score = score["f1"], epoch, 0, score
            torch.save(model.state_dict(), out / "best_model.pt")
            pd.DataFrame({"sequence": val.sequences, "label": val.labels.numpy(),
                          "probability_amp": probabilities}).to_csv(out / "validation_predictions.csv", index=False)
        else:
            stall += 1
        print(f"{cfg['name']} s{seed} epoch={epoch} val_f1={score['f1']:.4f} best={best:.4f}", flush=True)
        if stall >= 15:
            break
    result = {"config": cfg, "seed": seed, "best_epoch": best_epoch, "epochs": epoch,
              "validation": best_score, "elapsed_seconds": time.time() - start,
              "parameters": sum(p.numel() for p in model.parameters()), "code_sha256": sha256(__file__),
              "protocol_sha256": sha256(PROTOCOL_PATH), "phase1_code_sha256": sha256(ROOT / "optimization/run_phase1.py"),
              "checkpoint_sha256": sha256(out / "best_model.pt"), "test_evaluated": False}
    write_json(out / "result.json", result)
    print(f"DONE {cfg['name']} seed={seed}: {best_score}", flush=True)
    return result


def vectors(dataset, view):
    with torch.no_grad():
        mask = dataset.mask.unsqueeze(-1)
        mean = (dataset.tokens * mask).sum(1) / dataset.lengths[:, None]
        maximum = dataset.tokens.masked_fill(~mask, -torch.inf).max(1).values
        components = [dataset.cls, mean, maximum]
        if view == "hybrid":
            components.append(dataset.global_features)
        return torch.cat(components, dim=1).numpy().astype(np.float64)


def run_linear(train, val):
    from sklearn.pipeline import make_pipeline
    from sklearn.preprocessing import StandardScaler
    from sklearn.linear_model import LogisticRegression
    from threadpoolctl import threadpool_limits
    import joblib
    options = PROTOCOL["linear_controls"]
    rows = []
    for view in options["views"]:
        x_train, x_val = vectors(train, view), vectors(val, view)
        for c in options["C"]:
            for weighting in options["class_weight"]:
                name = f"logistic_{view}_C{c}_{weighting}"
                out = OUT / name
                out.mkdir(parents=True, exist_ok=True)
                if (out / "result.json").exists():
                    result = json.loads((out / "result.json").read_text())
                    assert result["code_sha256"] == sha256(__file__)
                else:
                    start = time.time()
                    model = make_pipeline(StandardScaler(), LogisticRegression(C=c, class_weight=weighting,
                        max_iter=options["max_iter"], tol=options["tol"], solver="lbfgs", random_state=42))
                    with threadpool_limits(limits=4):
                        model.fit(x_train, train.labels.numpy())
                        p = model.predict_proba(x_val)[:, 1]
                    score = metrics(val.labels.numpy(), p)
                    joblib.dump(model, out / "model.joblib")
                    pd.DataFrame({"sequence": val.sequences, "label": val.labels.numpy(), "probability_amp": p}).to_csv(out / "validation_predictions.csv", index=False)
                    result = {"name": name, "validation": score, "elapsed_seconds": time.time() - start,
                              "view": view, "C": c, "class_weight": weighting, "seed": 42,
                              "protocol_sha256": sha256(PROTOCOL_PATH), "code_sha256": sha256(__file__),
                              "checkpoint_sha256": sha256(out / "model.joblib"), "test_evaluated": False,
                              "converged": bool(model[-1].n_iter_.max() < options["max_iter"])}
                    write_json(out / "result.json", result)
                rows.append({"name": name, **{k: v for k, v in result["validation"].items() if k != "confusion"}})
                pd.DataFrame(rows).to_csv(OUT / "linear_validation.csv", index=False)
                print(f"DONE {name}: {result['validation']}", flush=True)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--kind", choices=["neural", "linear"], required=True)
    args = parser.parse_args()
    setup()
    OUT.mkdir(parents=True, exist_ok=True)
    train = DevelopmentDataset("train")
    val = DevelopmentDataset("val", train.scaler)
    if args.kind == "linear":
        run_linear(train, val)
    else:
        rows = []
        for cfg in PROTOCOL["neural_candidates"]:
            for seed in PROTOCOL["seeds"]:
                result = train_neural(cfg, seed, train, val)
                rows.append({"name": cfg["name"], "seed": seed, "best_epoch": result["best_epoch"],
                             **{k: v for k, v in result["validation"].items() if k != "confusion"}})
                pd.DataFrame(rows).to_csv(OUT / "neural_validation.csv", index=False)
        summary = pd.DataFrame(rows).groupby("name").agg(f1_mean=("f1", "mean"), f1_std=("f1", "std"),
            auc_mean=("auc", "mean"), mcc_mean=("mcc", "mean"), average_precision_mean=("average_precision", "mean"))
        summary.to_csv(OUT / "neural_summary.csv")
        print(summary.to_string(), flush=True)


if __name__ == "__main__":
    main()
