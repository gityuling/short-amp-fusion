"""Bounded semantic-dimension ablation for the strongest tree control."""
import json
import time
import numpy as np
import pandas as pd
import joblib
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA
from sklearn.ensemble import HistGradientBoostingClassifier
from threadpoolctl import threadpool_limits
from run_phase1 import ROOT, DevelopmentDataset, setup, sha256, write_json, metrics
from run_phase2 import vectors

PATH = ROOT / "optimization/phase5_protocol.json"
CFG = json.loads(PATH.read_text())
OUT = ROOT / "optimization/phase5"


def main():
    setup()
    train = DevelopmentDataset("train")
    val = DevelopmentDataset("val", train.scaler)
    with threadpool_limits(limits=4):
        scaler = StandardScaler()
        raw_train = scaler.fit_transform(vectors(train, "semantic"))
        raw_val = scaler.transform(vectors(val, "semantic"))
    rows = []
    for cfg in CFG["candidates"]:
        out = OUT / cfg["name"]
        out.mkdir(parents=True, exist_ok=True)
        if cfg["pca_components"]:
            pca = PCA(n_components=cfg["pca_components"], svd_solver="randomized", random_state=42, iterated_power=3)
            with threadpool_limits(limits=4):
                x = np.concatenate([pca.fit_transform(raw_train), train.global_features.numpy()], axis=1)
                v = np.concatenate([pca.transform(raw_val), val.global_features.numpy()], axis=1)
        else:
            pca = None
            x, v = train.global_features.numpy(), val.global_features.numpy()
        joblib.dump({"semantic_scaler": scaler, "pca": pca, "phys_scaler": train.scaler}, out / "transforms.joblib")
        transform_hash = sha256(out / "transforms.joblib")
        for seed in CFG["seeds"]:
            dest = out / f"seed_{seed}"
            dest.mkdir(parents=True, exist_ok=True)
            if (dest / "result.json").exists():
                result = json.loads((dest / "result.json").read_text())
                assert result["code_sha256"] == sha256(__file__)
                assert result["protocol_sha256"] == sha256(PATH)
                assert result["transform_sha256"] == transform_hash
            else:
                print(f"START {cfg['name']} seed={seed}", flush=True)
                start = time.time()
                model = HistGradientBoostingClassifier(**CFG["fixed"], random_state=seed)
                with threadpool_limits(limits=4):
                    model.fit(x, train.labels.numpy())
                    probs = model.predict_proba(v)[:, 1]
                score = metrics(val.labels.numpy(), probs)
                joblib.dump(model, dest / "model.joblib")
                pd.DataFrame({"sequence": val.sequences, "label": val.labels.numpy(), "probability_amp": probs}).to_csv(dest / "validation_predictions.csv", index=False)
                result = {"config": cfg, "seed": seed, "validation": score, "elapsed_seconds": time.time() - start,
                          "code_sha256": sha256(__file__), "protocol_sha256": sha256(PATH),
                          "checkpoint_sha256": sha256(dest / "model.joblib"), "transform_sha256": transform_hash,
                          "test_evaluated": False}
                write_json(dest / "result.json", result)
            rows.append({"name": cfg["name"], "seed": seed, **{k: v for k, v in result["validation"].items() if k != "confusion"}})
            pd.DataFrame(rows).to_csv(OUT / "validation_results.csv", index=False)
            print(f"DONE {cfg['name']} seed={seed}: {result['validation']}", flush=True)
    summary = pd.DataFrame(rows).groupby("name").agg(f1_mean=("f1", "mean"), f1_std=("f1", "std"),
        auc_mean=("auc", "mean"), mcc_mean=("mcc", "mean"), average_precision_mean=("average_precision", "mean"))
    summary.to_csv(OUT / "summary.csv")
    print(summary.to_string(), flush=True)


if __name__ == "__main__":
    main()
