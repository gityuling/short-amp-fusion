"""Cache the official test representations with the published inference routine."""
import gc
import numpy as np
import pandas as pd
import torch
from transformers import AutoTokenizer, EsmModel
from run_phase1 import ROOT, ASSETS, setup

ESM = ROOT / "optimization/assets/esm2_150m"

@torch.no_grad()
def extract_esm(sequences):
    tokenizer = AutoTokenizer.from_pretrained(ESM, local_files_only=True)
    model = EsmModel.from_pretrained(ESM, local_files_only=True, add_pooling_layer=False).cuda().eval()
    chunks = []
    for start in range(0, len(sequences), 16):
        batch = sequences[start:start + 16]
        inputs = tokenizer(batch, padding='max_length', max_length=32, truncation=False, return_tensors='pt')
        lengths = torch.tensor([len(s) for s in batch], device='cuda')
        mask = (torch.arange(32, device='cuda')[None, :] > 0) & (torch.arange(32, device='cuda')[None, :] <= lengths[:, None])
        assert inputs['input_ids'].shape[1] == 32
        assert torch.equal(inputs['attention_mask'].sum(1), lengths.cpu() + 2)
        hidden = model(**{k: v.cuda() for k, v in inputs.items()}).last_hidden_state
        mean = (hidden * mask.unsqueeze(-1)).sum(1) / lengths[:, None]
        maximum = hidden.masked_fill(~mask.unsqueeze(-1), -torch.inf).max(1).values
        chunks.append(torch.cat([hidden[:, 0], mean, maximum], dim=1).cpu().numpy())
    del model
    gc.collect()
    torch.cuda.empty_cache()
    return np.concatenate(chunks)



if __name__ == "__main__":
    setup()
    source = pd.read_csv(ASSETS / "data/test_dedup_split.csv")
    output = ROOT / "optimization/stage2_official_evaluation/test_esm_features.npz"
    output.parent.mkdir(parents=True, exist_ok=True)
    np.savez(output, embeddings=extract_esm(source.Sequence.tolist()),
             sequences=source.Sequence.values.astype(str), labels=source.Label.values)
