"""Run the pinned upstream feature implementation without changing its math."""
import sys
from common import ROOT, ASSETS, FEATURES, CONFIG, setup, sha256, write_json


def main():
    setup()
    import compute_features as upstream
    sys.argv = ["compute_features.py", "--data_dir", str(ASSETS / "data"),
                "--protbert_path", str(ASSETS / "models/protbert_finetuned"),
                "--output_dir", str(FEATURES), "--batch_size", str(CONFIG["feature_batch_size"]),
                "--max_length", str(CONFIG["max_length"]), "--device", "cuda"]
    upstream.main()
    write_json(ROOT / "reproduction/reports/feature_manifest.json", {
        "source_commit": CONFIG["source_commit"], "dtype": "float32", "seed": 42,
        "batch_size": CONFIG["feature_batch_size"], "max_length": CONFIG["max_length"],
        "encoder_sha256": sha256(ASSETS / "models/protbert_finetuned/model.safetensors"),
        "files": {p.name: sha256(p) for p in sorted(FEATURES.iterdir()) if p.is_file()}
    })


if __name__ == "__main__":
    main()
