"""Shared paths, provenance checks, and deterministic runtime setup."""
import hashlib
import json
import os
from pathlib import Path
import random
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[2]
SOURCE = ROOT / "PPsAMP"
ASSETS = ROOT / "reproduction/assets/upstream"
FEATURES = ROOT / "reproduction/features/official"
CONFIG = json.loads((ROOT / "reproduction/configs/official.json").read_text())
sys.path.insert(0, str(SOURCE / "pipeline"))


def sha256(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as f:
        for block in iter(lambda: f.read(8 << 20), b""):
            h.update(block)
    return h.hexdigest()


def verify_source():
    commit = subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=SOURCE, text=True).strip()
    if commit != CONFIG["source_commit"]:
        raise RuntimeError(f"Unexpected upstream revision: {commit}")
    changed = subprocess.check_output(["git", "diff", "HEAD", "--"], cwd=SOURCE, text=True)
    if changed:
        raise RuntimeError("Tracked upstream files were modified; restore/review before reproduction")
    return commit


def setup(seed=42):
    os.environ.setdefault("CUBLAS_WORKSPACE_CONFIG", ":4096:8")
    os.environ.setdefault("TOKENIZERS_PARALLELISM", "false")
    import numpy as np
    import torch
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    torch.set_num_threads(4)
    torch.backends.cudnn.benchmark = False
    torch.backends.cudnn.deterministic = True
    torch.backends.cuda.matmul.allow_tf32 = False
    torch.backends.cudnn.allow_tf32 = False
    torch.use_deterministic_algorithms(True)
    verify_source()


def write_json(path, obj):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(obj, indent=2, ensure_ascii=False) + "\n")
    temporary.replace(path)
