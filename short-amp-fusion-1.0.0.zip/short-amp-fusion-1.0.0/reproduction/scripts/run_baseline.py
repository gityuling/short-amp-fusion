"""Execute original training loop with audit hooks and PyTorch API compatibility.

Model, feature math, loss, optimizer, scheduler decisions, data order and
selection logic come directly from the pinned upstream module.
"""
import argparse
import datetime
import functools
from pathlib import Path
import sys
import time

from common import ROOT, ASSETS, FEATURES, CONFIG, setup, sha256, write_json


def compact(result):
    return {k: ([int(x) for x in v] if k == "confusion" else float(v))
            for k, v in result.items() if k not in ("predictions", "probs", "labels")}


def validate_features():
    import h5py
    import numpy as np
    import pandas as pd
    for split in ("train", "val", "test"):
        df = pd.read_csv(ASSETS / "data" / f"{split}_dedup_split.csv")
        pse = pd.read_csv(FEATURES / f"{split}_pseaac.csv")
        with h5py.File(FEATURES / f"{split}_tokens.h5") as f:
            assert f["embeddings"].shape == (len(df), 32, 1024)
            assert list(f["sequences"].asstr()[:]) == df.Sequence.tolist(), split
            assert np.array_equal(f["labels"][:], df.Label.values), split
            assert np.array_equal(pse.label.values, df.Label.values), split
            assert np.array_equal(f["masks"][:].sum(1), df.Sequence.str.len().values + 2), split
            for start in range(0, len(df), 128):
                assert np.isfinite(f["embeddings"][start:start + 128]).all(), split
        assert pse.shape == (len(df), 421), split
        assert np.isfinite(pse.values).all(), split


def save_predictions(out, result):
    import pandas as pd
    from sklearn.metrics import average_precision_score
    df = pd.read_csv(ASSETS / "data/test_dedup_split.csv")
    df["probability_amp"] = result["probs"]
    df["prediction"] = result["predictions"]
    df.to_csv(out / "test_predictions.csv", index=False)
    metrics = compact(result)
    metrics["average_precision"] = float(average_precision_score(result["labels"], result["probs"]))
    metrics["threshold"] = 0.5
    metrics["n_test"] = len(df)
    write_json(out / "test_metrics.json", metrics)


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--mode", choices=["train", "evaluate"], required=True)
    p.add_argument("--seed", type=int, default=42)
    p.add_argument("--checkpoint", type=str)
    p.add_argument("--output", type=str)
    args = p.parse_args()
    setup(args.seed)
    import torch
    from torch.utils.data import DataLoader
    import train_token_attn as upstream
    validate_features()
    out = Path(args.output) if args.output else ROOT / "reproduction/results" / (
        f"official_seed_{args.seed}" if args.mode == "train" else "official_checkpoint")
    out.mkdir(parents=True, exist_ok=True)
    if (out / "test_metrics.json").exists():
        raise FileExistsError(f"Completed run already exists: {out}; use a new output directory")
    provenance = {**CONFIG, "seed": args.seed, "mode": args.mode,
                  "started_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
                  "torch_version": torch.__version__, "gpu": torch.cuda.get_device_name(0),
                  "deterministic_algorithms": True, "tf32": False,
                  "compatibility_changes": ["Remove obsolete ReduceLROnPlateau verbose argument; no algorithm change"],
                  "status": "running"}
    write_json(out / "run.json", provenance)
    start = time.time()
    if args.mode == "evaluate":
        checkpoint = Path(args.checkpoint) if args.checkpoint else ASSETS / "models/token_attention/best_model.pt"
        model = upstream.TokenCrossAttentionModel(**{k: CONFIG[k] for k in (
            "embedding_dim", "num_heads", "num_layers", "dropout")}).cuda()
        state = torch.load(checkpoint, map_location="cpu", weights_only=True)
        model.load_state_dict(state, strict=True)
        ds = upstream.TokenFeatureDataset(FEATURES / "test_tokens.h5", FEATURES / "test_pseaac.csv")
        criterion = torch.nn.CrossEntropyLoss(weight=torch.tensor([1.0, 3210 / 1514], device="cuda"))
        result = upstream.evaluate(model, DataLoader(ds, batch_size=64), "cuda", criterion)
        save_predictions(out, result)
        provenance.update(checkpoint=str(checkpoint), checkpoint_sha256=sha256(checkpoint))
        print(compact(result), flush=True)
    else:
        # Preserve original training loop, including train-loader evaluation RNG consumption.
        scheduler_class = torch.optim.lr_scheduler.ReduceLROnPlateau
        def compatible_scheduler(*a, **kw):
            kw.pop("verbose", None)
            return scheduler_class(*a, **kw)
        torch.optim.lr_scheduler.ReduceLROnPlateau = compatible_scheduler
        original_evaluate = upstream.evaluate
        history = []
        train_metrics = {}
        def audited_evaluate(model, loader, device, criterion):
            nonlocal train_metrics
            result = original_evaluate(model, loader, device, criterion)
            n = len(loader.dataset)
            if n == 4724:
                train_metrics = compact(result)
            elif n == 1398:
                history.append({"epoch": len(history) + 1,
                                "train": train_metrics, "validation": compact(result)})
                write_json(out / "history.json", history)
            elif n == 1400:
                save_predictions(out, result)
            else:
                raise ValueError(f"Unexpected split size {n}")
            return result
        upstream.evaluate = audited_evaluate
        upstream.tqdm = functools.partial(upstream.tqdm, disable=True)
        sys.argv = ["train_token_attn.py", "--feature_dir", str(FEATURES), "--output_dir", str(out)]
        for k in ("embedding_dim", "num_heads", "num_layers", "dropout", "batch_size", "lr",
                  "weight_decay", "epochs", "patience"):
            sys.argv += [f"--{k}", str(CONFIG[k])]
        upstream.main()
        provenance["checkpoint_sha256"] = sha256(out / "best_model.pt")
    provenance.update(status="completed", elapsed_seconds=time.time() - start)
    write_json(out / "run.json", provenance)


if __name__ == "__main__":
    main()
